import{n as e}from"./progress-BN7NQtw-.js";var t=e(`moon`,[[`path`,{d:`M12 3a6 6 0 0 0 9 9 9 9 0 1 1-9-9Z`,key:`a7tn18`}]]),n=e(`sun`,[[`circle`,{cx:`12`,cy:`12`,r:`4`,key:`4exip2`}],[`path`,{d:`M12 2v2`,key:`tus03m`}],[`path`,{d:`M12 20v2`,key:`1lh1kg`}],[`path`,{d:`m4.93 4.93 1.41 1.41`,key:`149t6j`}],[`path`,{d:`m17.66 17.66 1.41 1.41`,key:`ptbguv`}],[`path`,{d:`M2 12h2`,key:`1t8f8n`}],[`path`,{d:`M20 12h2`,key:`1q8mjw`}],[`path`,{d:`m6.34 17.66-1.41 1.41`,key:`1m8zz5`}],[`path`,{d:`m19.07 4.93-1.41 1.41`,key:`1shlcs`}]]),r={built:`12 November 2026`,version:`1.15`,mcq:770,chapters:[{num:1,title:`Geography of Nepal`,nep:`नेपालको भूगोल`,slug:`part-05-chapter-01-geography-of-nepal`,topics:[{id:`1.1`,title:`Location, size and boundaries (अवस्थिति, आकार र सिमाना)`,questions:[{id:`Q 1.1.1`,label:`Expected – Practice`,stem:`<p>What is the present official area of Nepal?</p>
`,options:[`141,718 sq km`,`147,181 sq km`,`147,516 sq km`,`147,641 sq km`],answer:2,explanation:`The map of 2077 BS added 335 sq km (Limpiyadhura, Lipulekh, Kalapani) to the earlier 147,181 sq km.`},{id:`Q 1.1.2`,label:`Expected – Practice`,stem:`<p>Nepal Standard Time is based on the meridian that passes through:</p>
`,options:[`Sagarmatha`,`Gaurishankar`,`Machhapuchhre`,`Dhaulagiri`],answer:1,explanation:`The meridian 86°15′ E passes through Gaurishankar Himal in Dolakha. Nepal's time is 5 hours 45 minutes ahead of Coordinated Universal Time.`},{id:`Q 1.1.3`,label:`Pattern-Based – Reconstructed`,stem:`<p>Read the statements.</p>
<ol>
<li>Nepal touches five states of India.</li>
<li>Karnali Province has no boundary with India.</li>
<li>Madhesh Province has a boundary with China.</li>
<li>Taplejung and Darchula touch both India and China.</li>
</ol>
<p>Which statements are correct?</p>
`,options:[`1, 2 and 3`,`1, 2 and 4`,`2, 3 and 4`,`1, 3 and 4`],answer:1,explanation:`Statement 3 is wrong. Madhesh touches only India. Lumbini also has no boundary with China.`},{id:`Q 1.1.4`,label:`Pattern-Based – Reconstructed`,stem:`<p>Match List I with List II.</p>
<div class="tw"><table>
<thead>
<tr>
<th>List I</th>
<th>List II</th>
</tr>
</thead>
<tbody>
<tr>
<td>A. Southern limit</td>
<td>1. 88°12′ E</td>
</tr>
<tr>
<td>B. Northern limit</td>
<td>2. 26°22′ N</td>
</tr>
<tr>
<td>C. Western limit</td>
<td>3. 80°04′ E</td>
</tr>
<tr>
<td>D. Eastern limit</td>
<td>4. 30°27′ N</td>
</tr>
</tbody>
</table></div>
`,options:[`A-2, B-4, C-3, D-1`,`A-4, B-2, C-1, D-3`,`A-2, B-4, C-1, D-3`,`A-3, B-1, C-2, D-4`],answer:0,explanation:`Latitudes (N) give the south and north limits; longitudes (E) give the west and east limits. The smaller number is always the south or the west.`},{id:`Q 1.1.5`,label:`Expected – Practice`,stem:`<p>The eastern and western ends of Nepal are about 8° of longitude apart. Because the earth turns 1° in 4 minutes, the difference in local sun time between the two ends is about:</p>
`,options:[`8 minutes`,`16 minutes`,`32 minutes`,`45 minutes`],answer:2,explanation:`8° × 4 minutes = 32 minutes. The whole country still uses one standard time.`}]},{id:`1.2`,title:`Physiographic regions (भौगोलिक प्रदेश)`,questions:[{id:`Q 1.2.1`,label:`Expected – Practice`,stem:`<p>In the traditional three-fold division, what share of Nepal's area is hill (Pahad)?</p>
`,options:[`15%`,`17%`,`68%`,`83%`],answer:2,explanation:`Himal 15%, Pahad 68%, Terai 17%.`},{id:`Q 1.2.2`,label:`Pattern-Based – Reconstructed`,stem:`<p>Arrange from south to north.</p>
<ol>
<li>Mahabharat range</li>
<li>Chure hills</li>
<li>Terai</li>
<li>Great Himalaya</li>
</ol>
`,options:[`3 – 2 – 1 – 4`,`3 – 1 – 2 – 4`,`2 – 3 – 1 – 4`,`3 – 2 – 4 – 1`],answer:0,explanation:`The Terai is the southernmost belt. The Chure rises next, then the higher Mahabharat, and last the Great Himalaya.`},{id:`Q 1.2.3`,label:`Pattern-Based – Reconstructed`,stem:`<p>Which one does not belong to the group?</p>
`,options:[`Chitwan`,`Dang`,`Surkhet`,`Pokhara`],answer:3,explanation:`Chitwan, Dang and Surkhet are Inner Terai (Dun) valleys between the Chure and the Mahabharat. Pokhara is a midland valley.`},{id:`Q 1.2.4`,label:`Pattern-Based – Reconstructed`,stem:`<p><strong>Assertion (A):</strong> The Terai holds more than half of Nepal's population.</p>
<p><strong>Reason (R):</strong> The Terai covers more than half of Nepal's area.</p>
`,options:[`Both A and R are true, and R explains A.`,`Both A and R are true, but R does not explain A.`,`A is true, but R is false.`,`A is false, but R is true.`],answer:2,explanation:`In the Census of 2078 the Terai had 53.61% of the people, but it covers only about 17% of the land.`},{id:`Q 1.2.5`,label:`Expected – Practice`,stem:`<p>Which fault separates the Chure hills from the Terai plain?</p>
`,options:[`Main Central Thrust`,`Main Boundary Thrust`,`Main Frontal Thrust`,`None of these`],answer:2,explanation:`From north to south the order is Central, Boundary, Frontal. The Main Frontal Thrust is the southernmost and runs along the foot of the Chure.`}]},{id:`1.3`,title:`Mountains, passes and glaciers (हिमाल, भन्ज्याङ र हिमनदी)`,questions:[{id:`Q 1.3.1`,label:`Expected – Practice`,stem:`<p>How many of the world's fourteen peaks above 8,000 m are in Nepal?</p>
`,options:[`6`,`7`,`8`,`10`],answer:2,explanation:`Sagarmatha, Kanchenjunga, Lhotse, Makalu, Cho Oyu, Dhaulagiri, Manaslu and Annapurna.`},{id:`Q 1.3.2`,label:`Pattern-Based – Reconstructed`,stem:`<p>Arrange the peaks from east to west.</p>
<ol>
<li>Dhaulagiri</li>
<li>Makalu</li>
<li>Manaslu</li>
<li>Kanchenjunga</li>
</ol>
`,options:[`4 – 2 – 3 – 1`,`2 – 4 – 3 – 1`,`4 – 3 – 2 – 1`,`4 – 2 – 1 – 3`],answer:0,explanation:`Kanchenjunga (Taplejung) is the easternmost. Then come Makalu (Sankhuwasabha), Manaslu (Gorkha) and Dhaulagiri (Myagdi).`},{id:`Q 1.3.3`,label:`Pattern-Based – Reconstructed`,stem:`<p>Match the pass with its district.</p>
<div class="tw"><table>
<thead>
<tr>
<th>Pass</th>
<th>District</th>
</tr>
</thead>
<tbody>
<tr>
<td>A. Korala</td>
<td>1. Rasuwa</td>
</tr>
<tr>
<td>B. Kodari</td>
<td>2. Mustang</td>
</tr>
<tr>
<td>C. Rasuwagadhi</td>
<td>3. Darchula</td>
</tr>
<tr>
<td>D. Tinkar</td>
<td>4. Sindhupalchok</td>
</tr>
</tbody>
</table></div>
`,options:[`A-2, B-4, C-1, D-3`,`A-2, B-1, C-4, D-3`,`A-3, B-4, C-1, D-2`,`A-4, B-2, C-3, D-1`],answer:0,explanation:`Korala is in Mustang, Kodari in Sindhupalchok, Rasuwagadhi in Rasuwa and Tinkar in Darchula.`},{id:`Q 1.3.4`,label:`Expected – Practice`,stem:`<p>Which is the highest peak that lies wholly inside Nepal?</p>
`,options:[`Kanchenjunga`,`Dhaulagiri I`,`Makalu`,`Cho Oyu`],answer:1,explanation:`Kanchenjunga stands on the border with India; Makalu and Cho Oyu stand on the border with China. Dhaulagiri I (8,167 m) is wholly in Nepal.`},{id:`Q 1.3.5`,label:`Pattern-Based – Reconstructed`,stem:`<p>Read the statements.</p>
<ol>
<li>Annapurna I was the first peak above 8,000 m to be climbed.</li>
<li>The height of 8,848.86 m for Sagarmatha was announced in 2020.</li>
<li>Cho Oyu lies in Taplejung district.</li>
</ol>
<p>Which statements are correct?</p>
`,options:[`1 only`,`1 and 2 only`,`2 and 3 only`,`1, 2 and 3`],answer:1,explanation:`Cho Oyu lies in Solukhumbu. Kanchenjunga is the eight-thousander of Taplejung.`}]},{id:`1.4`,title:`Rivers and lakes (नदी र ताल)`,questions:[{id:`Q 1.4.1`,label:`Expected – Practice`,stem:`<p>Which is the longest river of Nepal?</p>
`,options:[`Koshi`,`Narayani`,`Bagmati`,`Karnali`],answer:3,explanation:`The Karnali flows for 507 km inside Nepal. The Koshi is the largest river, not the longest.`},{id:`Q 1.4.2`,label:`Pattern-Based – Reconstructed`,stem:`<p>Which one does not belong to the group?</p>
`,options:[`Tamor`,`Likhu`,`Marsyangdi`,`Indrawati`],answer:2,explanation:`Tamor, Likhu and Indrawati are branches of the Koshi. The Marsyangdi is a branch of the Gandaki.`},{id:`Q 1.4.3`,label:`Pattern-Based – Reconstructed`,stem:`<p>Match the river with its name in India.</p>
<div class="tw"><table>
<thead>
<tr>
<th>River in Nepal</th>
<th>Name in India</th>
</tr>
</thead>
<tbody>
<tr>
<td>A. Karnali</td>
<td>1. Sharda</td>
</tr>
<tr>
<td>B. Narayani</td>
<td>2. Ghaghara</td>
</tr>
<tr>
<td>C. Mahakali</td>
<td>3. Gandak</td>
</tr>
</tbody>
</table></div>
`,options:[`A-1, B-2, C-3`,`A-2, B-3, C-1`,`A-3, B-1, C-2`,`A-2, B-1, C-3`],answer:1,explanation:`Karnali becomes the Ghaghara, Narayani becomes the Gandak, and Mahakali becomes the Sharda.`},{id:`Q 1.4.4`,label:`Expected – Practice`,stem:`<p>The Kali Gandaki and the Trishuli meet to form the Narayani at:</p>
`,options:[`Devghat`,`Chatara`,`Ridi`,`Chisapani`],answer:0,explanation:`Devghat lies where Chitwan, Tanahun and Nawalpur meet. Chatara is on the Koshi and Chisapani is on the Karnali.`},{id:`Q 1.4.5`,label:`Pattern-Based – Reconstructed`,stem:`<p>Read the statements.</p>
<ol>
<li>Rara is the largest lake of Nepal and lies in Mugu.</li>
<li>Tilicho lies in Manang.</li>
<li>Phoksundo lies in Jumla.</li>
<li>Phewa lies in Kaski.</li>
</ol>
<p>Which statements are correct?</p>
`,options:[`1 and 3 only`,`2, 3 and 4`,`1, 2 and 3`,`1, 2 and 4`],answer:3,explanation:`Phoksundo lies in Dolpa, not Jumla.`}]},{id:`1.5`,title:`Climate, soil, natural vegetation and forest (हावापानी, माटो, वनस्पति र वन)`,questions:[{id:`Q 1.5.1`,label:`Expected – Practice`,stem:`<p>Which date does the Department of Hydrology and Meteorology use as the normal date of monsoon onset in Nepal?</p>
`,options:[`1 June`,`13 June`,`23 June`,`2 July`],answer:1,explanation:`The normal onset is 13 June and the normal withdrawal is 2 October.`},{id:`Q 1.5.2`,label:`Pattern-Based – Reconstructed`,stem:`<p><strong>Assertion (A):</strong> Mustang and Manang receive very little rain.</p>
<p><strong>Reason (R):</strong> They lie in the rain shadow north of the Annapurna and Dhaulagiri ranges.</p>
`,options:[`Both A and R are true, and R explains A.`,`Both A and R are true, but R does not explain A.`,`A is true, but R is false.`,`A is false, but R is true.`],answer:0,explanation:`The monsoon wind drops its rain on the southern slopes. Little moisture is left when the air crosses to the northern side.`},{id:`Q 1.5.3`,label:`Pattern-Based – Reconstructed`,stem:`<p>Match the soil with the area where it is mainly found.</p>
<div class="tw"><table>
<thead>
<tr>
<th>Soil</th>
<th>Area</th>
</tr>
</thead>
<tbody>
<tr>
<td>A. Alluvial</td>
<td>1. Kathmandu Valley</td>
</tr>
<tr>
<td>B. Lacustrine</td>
<td>2. Himalayan belt</td>
</tr>
<tr>
<td>C. Sandy and gravelly</td>
<td>3. Terai</td>
</tr>
<tr>
<td>D. Glacial</td>
<td>4. Chure and Bhawar</td>
</tr>
</tbody>
</table></div>
`,options:[`A-3, B-4, C-1, D-2`,`A-1, B-3, C-4, D-2`,`A-3, B-1, C-4, D-2`,`A-3, B-1, C-2, D-4`],answer:2,explanation:`Alluvial soil is found in the Terai, lacustrine soil in the Kathmandu Valley, sandy and gravelly soil in the Chure and Bhawar, and glacial soil in the Himalayan belt.`},{id:`Q 1.5.4`,label:`Expected – Practice`,stem:`<p>Sal forest is typical of which belt?</p>
`,options:[`Alpine`,`Cool temperate`,`Tundra`,`Sub-tropical`],answer:3,explanation:`Sal grows in the hot Terai, Inner Terai and Chure, below about 1,200 m.`},{id:`Q 1.5.5`,label:`Pattern-Based – Reconstructed`,stem:`<p>Fill in the blank. According to the land-cover figures published by the Forest Research and Training Centre in 2024, forest and other wooded land together cover about ______ of Nepal.</p>
`,options:[`29.00%`,`39.60%`,`44.74%`,`46.08%`],answer:3,explanation:`Forest 43.38% and other wooded land 2.70% make 46.08%. The figure 44.74% is the 2015 total.`}]},{id:`1.6`,title:`Protected areas and biodiversity (संरक्षित क्षेत्र र जैविक विविधता)`,questions:[{id:`Q 1.6.1`,label:`Expected – Practice`,stem:`<p>Which is the largest national park of Nepal?</p>
`,options:[`Shey Phoksundo`,`Langtang`,`Sagarmatha`,`Makalu Barun`],answer:0,explanation:`Shey Phoksundo covers 3,555 sq km in Dolpa and Mugu. The Annapurna Conservation Area is larger, but it is not a national park.`},{id:`Q 1.6.2`,label:`Pattern-Based – Reconstructed`,stem:`<p>Three of the following are on the World Heritage List. Which one is not?</p>
`,options:[`Chitwan National Park`,`Sagarmatha National Park`,`Bardiya National Park`,`Lumbini`],answer:2,explanation:`Nepal's World Heritage Sites are Sagarmatha National Park, Chitwan National Park, the Kathmandu Valley and Lumbini.`},{id:`Q 1.6.3`,label:`Pattern-Based – Reconstructed`,stem:`<p>Match the protected area with the animal it is best known for.</p>
<div class="tw"><table>
<thead>
<tr>
<th>Protected area</th>
<th>Animal</th>
</tr>
</thead>
<tbody>
<tr>
<td>A. Koshi Tappu</td>
<td>1. Blue sheep</td>
</tr>
<tr>
<td>B. Shuklaphanta</td>
<td>2. One-horned rhinoceros</td>
</tr>
<tr>
<td>C. Dhorpatan</td>
<td>3. Wild water buffalo</td>
</tr>
<tr>
<td>D. Chitwan</td>
<td>4. Swamp deer</td>
</tr>
</tbody>
</table></div>
`,options:[`A-3, B-4, C-2, D-1`,`A-4, B-3, C-1, D-2`,`A-3, B-1, C-4, D-2`,`A-3, B-4, C-1, D-2`],answer:3,explanation:`Koshi Tappu protects the wild water buffalo, Shuklaphanta the swamp deer, Dhorpatan the blue sheep and Chitwan the one-horned rhinoceros.`},{id:`Q 1.6.4`,label:`Pattern-Based – Reconstructed`,stem:`<p>Read the statements.</p>
<ol>
<li>Nepal has 12 national parks.</li>
<li>Nepal has 3 wildlife reserves.</li>
<li>Nepal has 10 Ramsar sites.</li>
<li>Nepal has 6 conservation areas.</li>
</ol>
<p>Which statements are correct?</p>
`,options:[`1, 2 and 3`,`1, 3 and 4`,`2, 3 and 4`,`1, 2 and 4`],answer:1,explanation:`Nepal has one wildlife reserve, Koshi Tappu. Shuklaphanta and Parsa became national parks in 2017.`},{id:`Q 1.6.5`,label:`Expected – Practice`,stem:`<p>Which was the first wetland of Nepal to be listed as a Ramsar site?</p>
`,options:[`Ghodaghodi`,`Rara`,`Koshi Tappu`,`Bishazari`],answer:2,explanation:`Koshi Tappu was listed in 1987. Three more sites followed in 2003.`}]},{id:`1.7`,title:`Administrative geography and superlatives (प्रशासनिक भूगोल र विशेषता)`,questions:[{id:`Q 1.7.1`,label:`Expected – Practice`,stem:`<p>How many rural municipalities (गाउँपालिका) are there in Nepal?</p>
`,options:[`276`,`293`,`460`,`481`],answer:2,explanation:`The 753 local levels are 6 metropolitan cities, 11 sub-metropolitan cities, 276 municipalities and 460 rural municipalities.`},{id:`Q 1.7.2`,label:`Pattern-Based – Reconstructed`,stem:`<p>Arrange the provinces by area, largest first.</p>
<ol>
<li>Koshi</li>
<li>Karnali</li>
<li>Madhesh</li>
<li>Bagmati</li>
</ol>
`,options:[`1 – 2 – 4 – 3`,`2 – 4 – 1 – 3`,`2 – 1 – 3 – 4`,`2 – 1 – 4 – 3`],answer:3,explanation:`Karnali 27,984 sq km, Koshi 25,905 sq km, Bagmati 20,300 sq km, Madhesh 9,661 sq km.`},{id:`Q 1.7.3`,label:`Pattern-Based – Reconstructed`,stem:`<p>Match the province with its capital.</p>
<div class="tw"><table>
<thead>
<tr>
<th>Province</th>
<th>Capital</th>
</tr>
</thead>
<tbody>
<tr>
<td>A. Lumbini</td>
<td>1. Godawari</td>
</tr>
<tr>
<td>B. Sudurpashchim</td>
<td>2. Hetauda</td>
</tr>
<tr>
<td>C. Bagmati</td>
<td>3. Deukhuri</td>
</tr>
<tr>
<td>D. Karnali</td>
<td>4. Birendranagar</td>
</tr>
</tbody>
</table></div>
`,options:[`A-3, B-1, C-2, D-4`,`A-1, B-3, C-2, D-4`,`A-3, B-4, C-2, D-1`,`A-2, B-1, C-3, D-4`],answer:0,explanation:`Lumbini–Deukhuri, Sudurpashchim–Godawari, Bagmati–Hetauda, Karnali–Birendranagar.`},{id:`Q 1.7.4`,label:`Pattern-Based – Reconstructed`,stem:`<p>Read the statements.</p>
<ol>
<li>Bagmati Province has the largest population.</li>
<li>Madhesh Province has the highest population density.</li>
<li>Koshi Province has the largest number of districts.</li>
<li>Karnali Province has the largest number of local levels.</li>
</ol>
<p>Which statements are correct?</p>
`,options:[`1 and 2 only`,`1, 2 and 3`,`2, 3 and 4`,`1, 3 and 4`],answer:1,explanation:`Karnali has the fewest local levels (79). Koshi has the most (137).`},{id:`Q 1.7.5`,label:`Expected – Practice`,stem:`<p>Which two former districts were each divided between two provinces?</p>
`,options:[`Nawalparasi and Rukum`,`Nawalparasi and Dang`,`Rukum and Rolpa`,`Chitwan and Rukum`],answer:0,explanation:`Nawalparasi was divided between Gandaki and Lumbini, and Rukum between Lumbini and Karnali. This raised the number of districts from 75 to 77.`}]},{id:`1.8`,title:`Hydropower and natural resources (जलविद्युत् र प्राकृतिक स्रोत)`,questions:[{id:`Q 1.8.1`,label:`Expected – Practice`,stem:`<p>Which was the first hydropower station of Nepal?</p>
`,options:[`Sundarijal`,`Panauti`,`Trishuli`,`Pharping`],answer:3,explanation:`Pharping (500 kW) opened in 1911 (1968 BS).`},{id:`Q 1.8.2`,label:`Pattern-Based – Reconstructed`,stem:`<p>Arrange by capacity, largest first.</p>
<ol>
<li>Kali Gandaki A</li>
<li>Upper Tamakoshi</li>
<li>Kulekhani I</li>
<li>Arun III</li>
</ol>
`,options:[`2 – 4 – 1 – 3`,`4 – 2 – 1 – 3`,`4 – 1 – 2 – 3`,`4 – 2 – 3 – 1`],answer:1,explanation:`Arun III 900 MW, Upper Tamakoshi 456 MW, Kali Gandaki A 144 MW, Kulekhani I 60 MW. Arun III is still under construction.`},{id:`Q 1.8.3`,label:`Pattern-Based – Reconstructed`,stem:`<p>Match the project with its district.</p>
<div class="tw"><table>
<thead>
<tr>
<th>Project</th>
<th>District</th>
</tr>
</thead>
<tbody>
<tr>
<td>A. Kulekhani</td>
<td>1. Sankhuwasabha</td>
</tr>
<tr>
<td>B. Kali Gandaki A</td>
<td>2. Makawanpur</td>
</tr>
<tr>
<td>C. Upper Tamakoshi</td>
<td>3. Syangja</td>
</tr>
<tr>
<td>D. Arun III</td>
<td>4. Dolakha</td>
</tr>
</tbody>
</table></div>
`,options:[`A-2, B-4, C-3, D-1`,`A-3, B-2, C-4, D-1`,`A-2, B-3, C-4, D-1`,`A-2, B-3, C-1, D-4`],answer:2,explanation:`Kulekhani is in Makawanpur, Kali Gandaki A in Syangja, Upper Tamakoshi in Dolakha and Arun III in Sankhuwasabha.`},{id:`Q 1.8.4`,label:`Expected – Practice`,stem:`<p>Which river basin has the largest theoretical hydropower potential?</p>
`,options:[`Karnali and Mahakali`,`Koshi`,`Gandaki`,`Southern rivers`],answer:0,explanation:`Karnali and Mahakali 36,180 MW; Koshi 22,350 MW; Gandaki 20,650 MW; southern rivers 4,110 MW.`},{id:`Q 1.8.5`,label:`Pattern-Based – Reconstructed`,stem:`<p>Read the statements.</p>
<ol>
<li>Nepal first sent electricity to Bangladesh through India's grid in November 2024.</li>
<li>The Sunkoshi–Marin Diversion is designed to irrigate land in Madhesh Province.</li>
<li>Kharidhunga in Dolakha is known for magnesite.</li>
</ol>
<p>Which statements are correct?</p>
`,options:[`1 only`,`1 and 2 only`,`2 and 3 only`,`1, 2 and 3`],answer:3,explanation:`All three are correct. The first flow to Bangladesh, 40 MW, took place on 15 November 2024.`}]},{id:`1.9`,title:`Map-based General Knowledge (नक्सामा आधारित सामान्य ज्ञान)`,questions:[{id:`Q 1.9.1`,label:`Pattern-Based – Reconstructed`,stem:`<p>Arrange the provincial capitals from east to west.</p>
<ol>
<li>Pokhara</li>
<li>Janakpurdham</li>
<li>Birendranagar</li>
<li>Biratnagar</li>
</ol>
`,options:[`4 – 2 – 1 – 3`,`2 – 4 – 1 – 3`,`4 – 1 – 2 – 3`,`4 – 2 – 3 – 1`],answer:0,explanation:`Biratnagar (Koshi), Janakpurdham (Madhesh), Pokhara (Gandaki), Birendranagar (Karnali).`},{id:`Q 1.9.2`,label:`Pattern-Based – Reconstructed`,stem:`<p>Match the district with its headquarters.</p>
<div class="tw"><table>
<thead>
<tr>
<th>District</th>
<th>Headquarters</th>
</tr>
</thead>
<tbody>
<tr>
<td>A. Khotang</td>
<td>1. Gulariya</td>
</tr>
<tr>
<td>B. Bardiya</td>
<td>2. Manma</td>
</tr>
<tr>
<td>C. Kalikot</td>
<td>3. Malangwa</td>
</tr>
<tr>
<td>D. Sarlahi</td>
<td>4. Diktel</td>
</tr>
</tbody>
</table></div>
`,options:[`A-4, B-2, C-1, D-3`,`A-3, B-1, C-2, D-4`,`A-4, B-1, C-3, D-2`,`A-4, B-1, C-2, D-3`],answer:3,explanation:`Khotang–Diktel, Bardiya–Gulariya, Kalikot–Manma, Sarlahi–Malangwa.`},{id:`Q 1.9.3`,label:`Pattern-Based – Reconstructed`,stem:`<p>A traveller goes from east to west along the Mahendra Highway. In which order are these rivers crossed?</p>
`,options:[`Bagmati → Koshi → Narayani → Karnali`,`Koshi → Narayani → Bagmati → Karnali`,`Koshi → Bagmati → Narayani → Karnali`,`Koshi → Bagmati → Karnali → Narayani`],answer:2,explanation:`The Koshi is in the east, the Bagmati in Madhesh, the Narayani at the edge of Chitwan and the Karnali in the far west.`},{id:`Q 1.9.4`,label:`Pattern-Based – Reconstructed`,stem:`<p>Which one does not belong to the group?</p>
`,options:[`Mustang`,`Humla`,`Jumla`,`Rasuwa`],answer:2,explanation:`Mustang, Humla and Rasuwa touch China. Jumla does not.`},{id:`Q 1.9.5`,label:`Expected – Practice`,stem:`<p>Which national park spreads over three provinces?</p>
`,options:[`Bardiya`,`Chitwan`,`Rara`,`Sagarmatha`],answer:1,explanation:`Chitwan National Park lies in Chitwan and Makawanpur (Bagmati), Nawalpur (Gandaki) and Parsa (Madhesh).`}]},{id:`T`,title:`End-of-chapter test — Top 25`,questions:[{id:`T1`,label:`Expected – Practice`,stem:`<p>How much area did the map of 2077 BS add to the official area of Nepal?</p>
`,options:[`135 sq km`,`235 sq km`,`335 sq km`,`535 sq km`],answer:2,explanation:`147,181 + 335 = 147,516 sq km.`},{id:`T2`,label:`Expected – Practice`,stem:`<p>Which Indian state does not share a boundary with Nepal?</p>
`,options:[`Sikkim`,`Uttarakhand`,`West Bengal`,`Jharkhand`],answer:3,explanation:`The five states are Sikkim, West Bengal, Bihar, Uttar Pradesh and Uttarakhand.`},{id:`T3`,label:`Pattern-Based – Reconstructed`,stem:`<p>Read the statements.</p>
<ol>
<li>27 districts of Nepal touch India.</li>
<li>15 districts of Nepal touch China.</li>
<li>35 districts of Nepal touch no foreign country.</li>
</ol>
<p>Which statements are correct?</p>
`,options:[`1 and 2 only`,`2 and 3 only`,`1 and 3 only`,`1, 2 and 3`],answer:0,explanation:`Two districts touch both neighbours, so 40 districts touch a foreign country and 37, not 35, touch none.`},{id:`T4`,label:`Expected – Practice`,stem:`<p>In the five-fold physiographic division, which region has the largest share of Nepal's area?</p>
`,options:[`Terai`,`Churia`,`High Himal`,`Middle Mountains`],answer:3,explanation:`Middle Mountains 29.2%; High Himal 23.9%; High Mountains 20.4%; Terai 13.7%; Churia 12.8%.`},{id:`T5`,label:`Expected – Practice`,stem:`<p>How many districts does the census classify as Mountain districts?</p>
`,options:[`16`,`20`,`21`,`40`],answer:0,explanation:`Mountain 16, Hill 40, Terai 21.`},{id:`T6`,label:`Pattern-Based – Reconstructed`,stem:`<p>Match the peak with its district.</p>
<div class="tw"><table>
<thead>
<tr>
<th>Peak</th>
<th>District</th>
</tr>
</thead>
<tbody>
<tr>
<td>A. Kanchenjunga</td>
<td>1. Gorkha</td>
</tr>
<tr>
<td>B. Makalu</td>
<td>2. Myagdi</td>
</tr>
<tr>
<td>C. Manaslu</td>
<td>3. Taplejung</td>
</tr>
<tr>
<td>D. Dhaulagiri</td>
<td>4. Sankhuwasabha</td>
</tr>
</tbody>
</table></div>
`,options:[`A-3, B-1, C-4, D-2`,`A-3, B-4, C-1, D-2`,`A-4, B-3, C-1, D-2`,`A-3, B-4, C-2, D-1`],answer:1,explanation:`Kanchenjunga–Taplejung, Makalu–Sankhuwasabha, Manaslu–Gorkha, Dhaulagiri–Myagdi.`},{id:`T7`,label:`Expected – Practice`,stem:`<p>Which peak, known as &quot;Fishtail&quot;, is not open for climbing?</p>
`,options:[`Ama Dablam`,`Machhapuchhre`,`Gaurishankar`,`Saipal`],answer:1,explanation:`Machhapuchhre (6,993 m) stands in Kaski, north of Pokhara.`},{id:`T8`,label:`Expected – Practice`,stem:`<p>Thorong La pass lies between which two districts?</p>
`,options:[`Manang and Mustang`,`Mustang and Dolpa`,`Gorkha and Manang`,`Myagdi and Kaski`],answer:0,explanation:`Thorong La (5,416 m) is an internal pass on the Annapurna circuit. It does not lead to Tibet.`},{id:`T9`,label:`Expected – Practice`,stem:`<p>In which district is the glacial lake Tsho Rolpa?</p>
`,options:[`Solukhumbu`,`Manang`,`Dolakha`,`Rasuwa`],answer:2,explanation:`Tsho Rolpa is in Dolakha. Imja is in Solukhumbu and Thulagi is in Manang.`},{id:`T10`,label:`Pattern-Based – Reconstructed`,stem:`<p>Arrange these branches of the Gandaki from west to east.</p>
<ol>
<li>Trishuli</li>
<li>Kali Gandaki</li>
<li>Marsyangdi</li>
<li>Budhi Gandaki</li>
</ol>
`,options:[`2 – 4 – 3 – 1`,`3 – 2 – 4 – 1`,`2 – 3 – 4 – 1`,`2 – 3 – 1 – 4`],answer:2,explanation:`West to east: Kali Gandaki, Seti, Madi, Marsyangdi, Daraundi, Budhi Gandaki, Trishuli.`},{id:`T11`,label:`Expected – Practice`,stem:`<p>Which river is called the &quot;Sorrow of Bihar&quot;?</p>
`,options:[`Bagmati`,`Koshi`,`Kamala`,`Narayani`],answer:1,explanation:`The Koshi often changes its course and floods the plain of Bihar.`},{id:`T12`,label:`Expected – Practice`,stem:`<p>In which year was the Mahakali Treaty between Nepal and India signed?</p>
`,options:[`1954`,`1959`,`1991`,`1996`],answer:3,explanation:`The Koshi Agreement dates from 1954, the Gandak Agreement from 1959 and the Mahakali Treaty from 12 February 1996.`},{id:`T13`,label:`Pattern-Based – Reconstructed`,stem:`<p>Which one does not belong to the group?</p>
`,options:[`Koshi`,`Karnali`,`Bagmati`,`Narayani`],answer:2,explanation:`Koshi, Karnali and Narayani are snow-fed rivers that rise in the Himalaya. The Bagmati rises in the hills north of Kathmandu.`},{id:`T14`,label:`Expected – Practice`,stem:`<p>Which Ramsar site lies in Kailali district?</p>
`,options:[`Jagadishpur`,`Ghodaghodi`,`Bishazari`,`Mai Pokhari`],answer:1,explanation:`Jagadishpur is in Kapilvastu, Bishazari in Chitwan and Mai Pokhari in Ilam.`},{id:`T15`,label:`Pattern-Based – Reconstructed`,stem:`<p><strong>Assertion (A):</strong> The Chure hills suffer heavily from erosion and landslides.</p>
<p><strong>Reason (R):</strong> The Chure hills are young and are made of loose sand, gravel and soft rock.</p>
`,options:[`Both A and R are true, and R explains A.`,`Both A and R are true, but R does not explain A.`,`A is true, but R is false.`,`A is false, but R is true.`],answer:0,explanation:`Weak rock breaks down quickly, especially where forest is cut and gravel is dug out.`},{id:`T16`,label:`Expected – Practice`,stem:`<p>Lumle, the place that receives the most rain in Nepal, lies in which district?</p>
`,options:[`Kaski`,`Syangja`,`Myagdi`,`Lamjung`],answer:0,explanation:`Lumle lies west of Pokhara on the southern slope of the Annapurna range.`},{id:`T17`,label:`Pattern-Based – Reconstructed`,stem:`<p>Fill in the blank. In the textbook classification, the ______ belt lies between about 3,300 m and 5,000 m.</p>
`,options:[`sub-tropical`,`warm temperate`,`alpine`,`tundra`],answer:2,explanation:`Sub-tropical up to 1,200 m; warm temperate to 2,100 m; cool temperate to 3,300 m; alpine to 5,000 m; tundra above.`},{id:`T18`,label:`Expected – Practice`,stem:`<p>Which is the only hunting reserve of Nepal?</p>
`,options:[`Koshi Tappu`,`Shuklaphanta`,`Khaptad`,`Dhorpatan`],answer:3,explanation:`Dhorpatan lies in Rukum East, Baglung and Myagdi and is known for blue sheep.`},{id:`T19`,label:`Pattern-Based – Reconstructed`,stem:`<p>Match the protected area with its description.</p>
<div class="tw"><table>
<thead>
<tr>
<th>Protected area</th>
<th>Description</th>
</tr>
</thead>
<tbody>
<tr>
<td>A. Annapurna</td>
<td>1. Smallest protected area</td>
</tr>
<tr>
<td>B. Rara</td>
<td>2. Only wildlife reserve</td>
</tr>
<tr>
<td>C. Krishnasar</td>
<td>3. Largest protected area</td>
</tr>
<tr>
<td>D. Koshi Tappu</td>
<td>4. Smallest national park</td>
</tr>
</tbody>
</table></div>
`,options:[`A-3, B-4, C-1, D-2`,`A-3, B-1, C-4, D-2`,`A-4, B-3, C-1, D-2`,`A-3, B-4, C-2, D-1`],answer:0,explanation:`Annapurna is the largest protected area, Rara the smallest national park, Krishnasar the smallest protected area and Koshi Tappu the only wildlife reserve.`},{id:`T20`,label:`Expected – Practice`,stem:`<p>How many wild tigers did the national count announced on 29 July 2026 find in Nepal?</p>
`,options:[`198`,`235`,`355`,`429`],answer:3,explanation:`429. The earlier counts were 121 (2009), 198 (2013), 235 (2018) and 355 (2022).`},{id:`T21`,label:`Expected – Practice`,stem:`<p>Which province has neither a metropolitan city nor a sub-metropolitan city?</p>
`,options:[`Gandaki`,`Karnali`,`Sudurpashchim`,`Lumbini`],answer:1,explanation:`Gandaki has Pokhara Metropolitan City, Sudurpashchim has Dhangadhi Sub-Metropolitan City and Lumbini has four sub-metropolitan cities.`},{id:`T22`,label:`Pattern-Based – Reconstructed`,stem:`<p>Arrange the districts by area, largest first.</p>
<ol>
<li>Bhaktapur</li>
<li>Dolpa</li>
<li>Kathmandu</li>
<li>Humla</li>
</ol>
`,options:[`2 – 3 – 4 – 1`,`2 – 4 – 3 – 1`,`4 – 2 – 3 – 1`,`2 – 4 – 1 – 3`],answer:1,explanation:`Dolpa is the largest district and Humla the second largest. Bhaktapur is the smallest.`},{id:`T23`,label:`Expected – Practice`,stem:`<p>Which province has the largest number of municipalities (नगरपालिका)?</p>
`,options:[`Koshi`,`Bagmati`,`Madhesh`,`Lumbini`],answer:2,explanation:`Madhesh has 73 municipalities. Koshi has the most rural municipalities (88).`},{id:`T24`,label:`Pattern-Based – Reconstructed`,stem:`<p>Read the statements.</p>
<ol>
<li>Kulekhani is a storage-type hydropower project.</li>
<li>Most hydropower stations of Nepal are run-of-river stations.</li>
<li>Run-of-river stations produce the most power in the dry winter.</li>
</ol>
<p>Which statements are correct?</p>
`,options:[`1 and 2 only`,`2 and 3 only`,`1 and 3 only`,`1, 2 and 3`],answer:0,explanation:`Run-of-river stations depend on the river's flow, so they produce the least in the dry winter.`},{id:`T25`,label:`Expected – Practice`,stem:`<p>The Dhalkebar sub-station, the Nepal end of the 400 kV cross-border line to Muzaffarpur, lies in which district?</p>
`,options:[`Siraha`,`Mahottari`,`Dhanusha`,`Sarlahi`],answer:2,explanation:`Dhalkebar is in Dhanusha district of Madhesh Province.`}]}]},{num:2,title:`History of Nepal`,nep:`नेपालको इतिहास`,slug:`part-06-chapter-02-history-of-nepal`,topics:[{id:`2.1`,title:`Sources of history and the ancient period (इतिहासका स्रोत र प्राचीन काल)`,questions:[{id:`Q 2.1.1`,label:`Expected – Practice`,stem:`<p>Who is named as the first king of the Kirat dynasty?</p>
`,options:[`Gasti`,`Yalambar`,`Jitedasti`,`Sthunko`],answer:1,explanation:`Yalambar was the first Kirat king and Gasti the last.`},{id:`Q 2.1.2`,label:`Pattern-Based – Reconstructed`,stem:`<p>Arrange the dynasties in the order in which they ruled the Kathmandu Valley.</p>
<ol>
<li>Kirat</li>
<li>Gopal</li>
<li>Lichhavi</li>
<li>Mahispal</li>
</ol>
`,options:[`2 – 1 – 4 – 3`,`4 – 2 – 1 – 3`,`2 – 4 – 1 – 3`,`2 – 4 – 3 – 1`],answer:2,explanation:`Gopal, Mahispal, Kirat, then (after the short Soma dynasty) Lichhavi.`},{id:`Q 2.1.3`,label:`Pattern-Based – Reconstructed`,stem:`<p>Match List I with List II.</p>
<div class="tw"><table>
<thead>
<tr>
<th>List I</th>
<th>List II</th>
</tr>
</thead>
<tbody>
<tr>
<td>A. Changu Narayan pillar</td>
<td>1. Coin</td>
</tr>
<tr>
<td>B. Lumbini pillar</td>
<td>2. Chronicle</td>
</tr>
<tr>
<td>C. Gopal Raj Vamshavali</td>
<td>3. Inscription of Manadeva</td>
</tr>
<tr>
<td>D. Mananka</td>
<td>4. Inscription of Ashoka</td>
</tr>
</tbody>
</table></div>
`,options:[`A-3, B-4, C-2, D-1`,`A-4, B-3, C-2, D-1`,`A-3, B-4, C-1, D-2`,`A-2, B-4, C-3, D-1`],answer:0,explanation:`The Changu Narayan pillar carries Manadeva's inscription, the Lumbini pillar Ashoka's; the Gopal Raj Vamshavali is a chronicle and the Mananka a coin.`},{id:`Q 2.1.4`,label:`Pattern-Based – Reconstructed`,stem:`<p>Read the statements.</p>
<ol>
<li>Ashoka set up the pillar at Lumbini in 249 BC.</li>
<li>The Lumbini inscription is written in the Brahmi script.</li>
<li>Lumbini was placed on the World Heritage List in 1979.</li>
</ol>
<p>Which statements are correct?</p>
`,options:[`1 only`,`1 and 2 only`,`2 and 3 only`,`1, 2 and 3`],answer:1,explanation:`Lumbini was listed in 1997.`},{id:`Q 2.1.5`,label:`Expected – Practice`,stem:`<p>According to tradition, Gautam Buddha visited the Kathmandu Valley during the reign of which Kirat king?</p>
`,options:[`Yalambar`,`Sthunko`,`Gasti`,`Jitedasti`],answer:3,explanation:`Jitedasti was the 7th Kirat king. Tradition places Ashoka's visit in the time of Sthunko, the 14th.`}]},{id:`2.2`,title:`Lichhavi period (लिच्छविकाल)`,questions:[{id:`Q 2.2.1`,label:`Expected – Practice`,stem:`<p>Which Lichhavi king issued the coin called Mananka?</p>
`,options:[`Manadeva`,`Amshuverma`,`Narendradeva`,`Shivadeva I`],answer:0,explanation:`The Mananka of Manadeva is regarded as the first coin of Nepal.`},{id:`Q 2.2.2`,label:`Pattern-Based – Reconstructed`,stem:`<p>Match the palace with the ruler who is linked with it.</p>
<div class="tw"><table>
<thead>
<tr>
<th>Palace</th>
<th>Ruler</th>
</tr>
</thead>
<tbody>
<tr>
<td>A. Managriha</td>
<td>1. Narendradeva</td>
</tr>
<tr>
<td>B. Kailashkut Bhawan</td>
<td>2. Manadeva</td>
</tr>
<tr>
<td>C. Bhadradhivas</td>
<td>3. Amshuverma</td>
</tr>
</tbody>
</table></div>
`,options:[`A-2, B-1, C-3`,`A-3, B-2, C-1`,`A-2, B-3, C-1`,`A-1, B-3, C-2`],answer:2,explanation:`Managriha–Manadeva, Kailashkut Bhawan–Amshuverma, Bhadradhivas–Narendradeva.`},{id:`Q 2.2.3`,label:`Pattern-Based – Reconstructed`,stem:`<p>Which one does not belong to the group?</p>
`,options:[`Managriha`,`Kailashkut Bhawan`,`Bhadradhivas`,`Hanuman Dhoka`],answer:3,explanation:`The first three are Lichhavi palaces. Hanuman Dhoka is the Malla and Shah palace of Kathmandu.`},{id:`Q 2.2.4`,label:`Pattern-Based – Reconstructed`,stem:`<p>Read the statements.</p>
<ol>
<li>The Lichhavis came to Nepal from Vaishali.</li>
<li>Amshuverma wrote <em>Shabda Vidya</em>.</li>
<li>The Changu Narayan pillar inscription was set up by Amshuverma.</li>
</ol>
<p>Which statements are correct?</p>
`,options:[`1 only`,`2 and 3 only`,`1 and 3 only`,`1 and 2 only`],answer:3,explanation:`The Changu Narayan inscription (464 AD) was set up by Manadeva.`},{id:`Q 2.2.5`,label:`Expected – Practice`,stem:`<p>In the Lichhavi period, the tax on farm produce was called:</p>
`,options:[`Bhoga`,`Bhaga`,`Kara`,`Vishti`],answer:1,explanation:`Bhaga was the tax on farm produce, bhoga on animals and kara on trade. Vishti was unpaid labour.`}]},{id:`2.3`,title:`Medieval period (मध्यकाल)`,questions:[{id:`Q 2.3.1`,label:`Expected – Practice`,stem:`<p>Who built the stone Krishna Mandir of Patan?</p>
`,options:[`Pratap Malla`,`Bhupatindra Malla`,`Siddhi Narsingh Malla`,`Mahendra Malla`],answer:2,explanation:`Siddhi Narsingh Malla of Lalitpur built it in 1637.`},{id:`Q 2.3.2`,label:`Pattern-Based – Reconstructed`,stem:`<p>Match the kingdom with its last Malla king.</p>
<div class="tw"><table>
<thead>
<tr>
<th>Kingdom</th>
<th>Last king</th>
</tr>
</thead>
<tbody>
<tr>
<td>A. Kantipur</td>
<td>1. Ranajit Malla</td>
</tr>
<tr>
<td>B. Lalitpur</td>
<td>2. Jaya Prakash Malla</td>
</tr>
<tr>
<td>C. Bhaktapur</td>
<td>3. Tej Narsingh Malla</td>
</tr>
</tbody>
</table></div>
`,options:[`A-2, B-3, C-1`,`A-3, B-2, C-1`,`A-1, B-3, C-2`,`A-2, B-1, C-3`],answer:0,explanation:`Jaya Prakash Malla (Kantipur), Tej Narsingh Malla (Lalitpur), Ranajit Malla (Bhaktapur).`},{id:`Q 2.3.3`,label:`Pattern-Based – Reconstructed`,stem:`<p>Read the statements about the Khas kingdom.</p>
<ol>
<li>Dullu was its summer capital.</li>
<li>Its capital, Sinja, lies in today's Jumla district.</li>
<li>The name of Ripu Malla is cut on the Ashoka pillar at Lumbini.</li>
</ol>
<p>Which statements are correct?</p>
`,options:[`1 only`,`1 and 2 only`,`2 and 3 only`,`1, 2 and 3`],answer:2,explanation:`Statement 1 is wrong: Dullu, in Dailekh, was the winter capital.`},{id:`Q 2.3.4`,label:`Expected – Practice`,stem:`<p>Simraungadh, the capital of the Karnat dynasty, lies in which present-day district?</p>
`,options:[`Dhanusha`,`Bara`,`Mahottari`,`Rautahat`],answer:1,explanation:`Simraungadh is in Bara district of Madhesh Province. Nanyadeva founded the dynasty in 1097 AD.`},{id:`Q 2.3.5`,label:`Pattern-Based – Reconstructed`,stem:`<p><strong>Assertion (A):</strong> After the death of Yaksha Malla the Kathmandu Valley was divided into separate kingdoms.</p>
<p><strong>Reason (R):</strong> Jayasthiti Malla divided society into classes and castes by occupation.</p>
`,options:[`Both A and R are true, and R explains A.`,`Both A and R are true, but R does not explain A.`,`A is true, but R is false.`,`A is false, but R is true.`],answer:1,explanation:`Both statements are true, but the kingdom was divided among Yaksha Malla's heirs. The social reform of Jayasthiti Malla, a century earlier, was not the cause.`}]},{id:`2.4`,title:`Unification to the Sugauli Treaty (एकीकरणदेखि सुगौली सन्धिसम्म)`,questions:[{id:`Q 2.4.1`,label:`Expected – Practice`,stem:`<p>Which was the first place won by Prithvi Narayan Shah in his unification campaign?</p>
`,options:[`Kirtipur`,`Makwanpur`,`Kantipur`,`Nuwakot`],answer:3,explanation:`Nuwakot was won in 1744 (1801 BS), after a failed attack in 1743.`},{id:`Q 2.4.2`,label:`Pattern-Based – Reconstructed`,stem:`<p>Arrange the events in order of time, earliest first.</p>
<ol>
<li>Conquest of Kantipur</li>
<li>Conquest of Nuwakot</li>
<li>Ratification of the Sugauli Treaty</li>
<li>Death of Prithvi Narayan Shah</li>
</ol>
`,options:[`2 – 1 – 4 – 3`,`1 – 2 – 4 – 3`,`2 – 4 – 1 – 3`,`2 – 1 – 3 – 4`],answer:0,explanation:`Nuwakot 1744, Kantipur 1768, death of the king 1775, Sugauli Treaty ratified 1816.`},{id:`Q 2.4.3`,label:`Pattern-Based – Reconstructed`,stem:`<p>Match the battle with the Nepali commander.</p>
<div class="tw"><table>
<thead>
<tr>
<th>Battle</th>
<th>Commander</th>
</tr>
</thead>
<tbody>
<tr>
<td>A. Nalapani</td>
<td>1. Bhakti Thapa</td>
</tr>
<tr>
<td>B. Deuthal</td>
<td>2. Ujir Singh Thapa</td>
</tr>
<tr>
<td>C. Malaun</td>
<td>3. Balbhadra Kunwar</td>
</tr>
<tr>
<td>D. Jitgadh</td>
<td>4. Amar Singh Thapa</td>
</tr>
</tbody>
</table></div>
`,options:[`A-3, B-4, C-1, D-2`,`A-3, B-1, C-4, D-2`,`A-1, B-3, C-4, D-2`,`A-3, B-1, C-2, D-4`],answer:1,explanation:`Nalapani–Balbhadra Kunwar, Deuthal–Bhakti Thapa, Malaun–Amar Singh Thapa, Jitgadh–Ujir Singh Thapa.`},{id:`Q 2.4.4`,label:`Pattern-Based – Reconstructed`,stem:`<p>Read the statements about the Sugauli Treaty.</p>
<ol>
<li>It was signed in 1815 and ratified in 1816.</li>
<li>It made the Mechi and the Mahakali the boundary rivers of Nepal.</li>
<li>It returned Banke, Bardiya, Kailali and Kanchanpur to Nepal.</li>
</ol>
<p>Which statements are correct?</p>
`,options:[`1 only`,`2 and 3 only`,`1 and 2 only`,`1, 2 and 3`],answer:2,explanation:`The four districts of the Naya Muluk were returned in 1860, not by the Sugauli Treaty.`},{id:`Q 2.4.5`,label:`Expected – Practice`,stem:`<p>In the Dibya Upadesh, Prithvi Narayan Shah compared Nepal to:</p>
`,options:[`a yam between two boulders`,`a bridge between two rivers`,`a lamp between two winds`,`a fort between two armies`],answer:0,explanation:`&quot;दुई ढुङ्गाको तरुल&quot;: a small country between two large neighbours must keep a careful balance.`}]},{id:`2.5`,title:`Rana period (राणाकाल), 1846–1951`,questions:[{id:`Q 2.5.1`,label:`Expected – Practice`,stem:`<p>In which year did the Kot Massacre take place?</p>
`,options:[`1816 AD`,`1837 AD`,`1846 AD`,`1856 AD`],answer:2,explanation:`14 September 1846 (1903 BS). It brought Jung Bahadur to power.`},{id:`Q 2.5.2`,label:`Pattern-Based – Reconstructed`,stem:`<p>Match the Rana Prime Minister with the work linked with him.</p>
<div class="tw"><table>
<thead>
<tr>
<th>Prime Minister</th>
<th>Work</th>
</tr>
</thead>
<tbody>
<tr>
<td>A. Dev Shamsher</td>
<td>1. Nepal Bank Limited</td>
</tr>
<tr>
<td>B. Chandra Shamsher</td>
<td>2. Bir Hospital</td>
</tr>
<tr>
<td>C. Juddha Shamsher</td>
<td>3. Gorkhapatra</td>
</tr>
<tr>
<td>D. Bir Shamsher</td>
<td>4. Abolition of slavery</td>
</tr>
</tbody>
</table></div>
`,options:[`A-3, B-4, C-2, D-1`,`A-4, B-3, C-1, D-2`,`A-3, B-1, C-4, D-2`,`A-3, B-4, C-1, D-2`],answer:3,explanation:`Dev Shamsher–Gorkhapatra, Chandra Shamsher–abolition of slavery, Juddha Shamsher–Nepal Bank Limited, Bir Shamsher–Bir Hospital.`},{id:`Q 2.5.3`,label:`Pattern-Based – Reconstructed`,stem:`<p>Arrange the Rana prime ministers in the order in which they held office.</p>
<ol>
<li>Chandra Shamsher</li>
<li>Bir Shamsher</li>
<li>Juddha Shamsher</li>
<li>Dev Shamsher</li>
</ol>
`,options:[`2 – 1 – 4 – 3`,`2 – 4 – 1 – 3`,`4 – 2 – 1 – 3`,`2 – 4 – 3 – 1`],answer:1,explanation:`Bir (1885–1901), Dev (1901), Chandra (1901–1929), Juddha (1932–1945).`},{id:`Q 2.5.4`,label:`Pattern-Based – Reconstructed`,stem:`<p>Three of these men were executed in Magh 1997 BS. Which one was not?</p>
`,options:[`Tanka Prasad Acharya`,`Shukraraj Shastri`,`Dharma Bhakta Mathema`,`Ganga Lal Shrestha`],answer:0,explanation:`Tanka Prasad Acharya, president of the Nepal Praja Parishad, was sentenced to life in prison. The fourth martyr was Dashrath Chand.`},{id:`Q 2.5.5`,label:`Expected – Practice`,stem:`<p>Which was the first political party of Nepal?</p>
`,options:[`Nepali Congress`,`Nepal Praja Parishad`,`Communist Party of Nepal`,`Prachanda Gorkha`],answer:1,explanation:`The Nepal Praja Parishad was founded on 20 Jestha 1993 BS (2 June 1936). Prachanda Gorkha was a secret group, not a party.`}]},{id:`2.6`,title:`The revolution of 2007 BS and the decade to 2017 BS (२००७ सालको क्रान्ति र त्यसपछिको दशक)`,questions:[{id:`Q 2.6.1`,label:`Expected – Practice`,stem:`<p>On which date is Democracy Day (प्रजातन्त्र दिवस) observed?</p>
`,options:[`Falgun 7`,`Baisakh 11`,`Jestha 15`,`Ashoj 3`],answer:0,explanation:`King Tribhuvan proclaimed democracy on 7 Falgun 2007 (18 February 1951).`},{id:`Q 2.6.2`,label:`Pattern-Based – Reconstructed`,stem:`<p>Arrange the events in order of time, earliest first.</p>
<ol>
<li>First general election</li>
<li>Proclamation of democracy</li>
<li>Dismissal of the B.P. Koirala government</li>
<li>King Tribhuvan takes refuge in the Indian Embassy</li>
</ol>
`,options:[`4 – 2 – 1 – 3`,`2 – 4 – 1 – 3`,`4 – 1 – 2 – 3`,`4 – 2 – 3 – 1`],answer:0,explanation:`Kartik 2007, Falgun 2007, Falgun 2015, Poush 2017.`},{id:`Q 2.6.3`,label:`Pattern-Based – Reconstructed`,stem:`<p>Read the statements about the general election of 2015 BS.</p>
<ol>
<li>The House of Representatives had 109 seats.</li>
<li>Tanka Prasad Acharya became the first elected Prime Minister.</li>
<li>The Nepali Congress won 74 seats.</li>
</ol>
<p>Which statements are correct?</p>
`,options:[`1 only`,`1 and 3 only`,`2 and 3 only`,`1, 2 and 3`],answer:1,explanation:`Statement 2 is wrong: the first elected Prime Minister was B.P. Koirala.`},{id:`Q 2.6.4`,label:`Expected – Practice`,stem:`<p>Who was the first Prime Minister of Nepal from among the people, after the end of Rana rule?</p>
`,options:[`B.P. Koirala`,`Tanka Prasad Acharya`,`Dr K.I. Singh`,`Matrika Prasad Koirala`],answer:3,explanation:`Matrika Prasad Koirala took office on 1 Mangsir 2008 (16 November 1951).`},{id:`Q 2.6.5`,label:`Pattern-Based – Reconstructed`,stem:`<p>Match the event with its year.</p>
<div class="tw"><table>
<thead>
<tr>
<th>Event</th>
<th>Year (BS)</th>
</tr>
</thead>
<tbody>
<tr>
<td>A. Delhi Agreement</td>
<td>1. 2016</td>
</tr>
<tr>
<td>B. United Nations membership</td>
<td>2. 2013</td>
</tr>
<tr>
<td>C. Nepal Rastra Bank</td>
<td>3. 2007</td>
</tr>
<tr>
<td>D. B.P. Koirala becomes Prime Minister</td>
<td>4. 2012</td>
</tr>
</tbody>
</table></div>
`,options:[`A-3, B-2, C-4, D-1`,`A-4, B-3, C-2, D-1`,`A-3, B-4, C-2, D-1`,`A-3, B-4, C-1, D-2`],answer:2,explanation:`Delhi Agreement 2007, United Nations 2012, Nepal Rastra Bank 2013, B.P. Koirala 2016.`}]},{id:`2.7`,title:`Panchayat period (पञ्चायतकाल), 2017–2046 BS`,questions:[{id:`Q 2.7.1`,label:`Expected – Practice`,stem:`<p>In which year was the national referendum held?</p>
`,options:[`2036 BS`,`2037 BS`,`2038 BS`,`2046 BS`],answer:1,explanation:`It was announced on 10 Jestha 2036 and held on 20 Baisakh 2037 (2 May 1980).`},{id:`Q 2.7.2`,label:`Pattern-Based – Reconstructed`,stem:`<p>Read the statements.</p>
<ol>
<li>The Constitution of 2019 set up a party-less Panchayat system.</li>
<li>In the referendum of 2037 BS the multi-party side won.</li>
<li>The Back-to-the-Village campaign belongs to the Panchayat period.</li>
</ol>
<p>Which statements are correct?</p>
`,options:[`1 and 2 only`,`2 and 3 only`,`1, 2 and 3`,`1 and 3 only`],answer:3,explanation:`The reformed Panchayat side won the referendum with about 54.8% of the votes.`},{id:`Q 2.7.3`,label:`Pattern-Based – Reconstructed`,stem:`<p>Fill in the blank. King Birendra proposed that Nepal be declared a Zone of Peace in ______ BS.</p>
`,options:[`2028`,`2031`,`2036`,`2042`],answer:1,explanation:`He made the proposal at the time of his coronation in Falgun 2031 (February 1975).`},{id:`Q 2.7.4`,label:`Pattern-Based – Reconstructed`,stem:`<p>Match the measure with its year.</p>
<div class="tw"><table>
<thead>
<tr>
<th>Measure</th>
<th>Year (BS)</th>
</tr>
</thead>
<tbody>
<tr>
<td>A. Muluki Ain</td>
<td>1. 2028</td>
</tr>
<tr>
<td>B. Land Reform Act</td>
<td>2. 2037</td>
</tr>
<tr>
<td>C. New Education System Plan</td>
<td>3. 2020</td>
</tr>
<tr>
<td>D. Third amendment of the 2019 Constitution</td>
<td>4. 2021</td>
</tr>
</tbody>
</table></div>
`,options:[`A-3, B-4, C-1, D-2`,`A-4, B-3, C-1, D-2`,`A-3, B-4, C-2, D-1`,`A-3, B-1, C-4, D-2`],answer:0,explanation:`Muluki Ain 2020, Land Reform Act 2021, New Education System Plan 2028, third amendment 2037.`},{id:`Q 2.7.5`,label:`Expected – Practice`,stem:`<p>In which year was Nepal divided into 14 zones and 75 districts?</p>
`,options:[`2017 BS`,`2019 BS`,`2018 BS`,`2020 BS`],answer:2,explanation:`On 1 Baisakh 2018 (13 April 1961).`}]},{id:`2.8`,title:`From the People's Movement of 2046 to the peace of 2063 (२०४६ देखि २०६३ सम्म)`,questions:[{id:`Q 2.8.1`,label:`Expected – Practice`,stem:`<p>On which date was the Comprehensive Peace Accord signed?</p>
`,options:[`11 Baisakh 2063`,`7 Mangsir 2062`,`1 Magh 2063`,`5 Mangsir 2063`],answer:3,explanation:`5 Mangsir 2063 (21 November 2006). 7 Mangsir 2062 is the date of the 12-point understanding.`},{id:`Q 2.8.2`,label:`Pattern-Based – Reconstructed`,stem:`<p>Arrange the events in order of time, earliest first.</p>
<ol>
<li>Palace massacre</li>
<li>Start of the Maoist armed conflict</li>
<li>12-point understanding</li>
<li>Constitution of the Kingdom of Nepal, 2047</li>
</ol>
`,options:[`4 – 1 – 2 – 3`,`2 – 4 – 1 – 3`,`4 – 2 – 1 – 3`,`4 – 2 – 3 – 1`],answer:2,explanation:`2047, 2052, 2058, 2062.`},{id:`Q 2.8.3`,label:`Pattern-Based – Reconstructed`,stem:`<p>Match the person with the role.</p>
<div class="tw"><table>
<thead>
<tr>
<th>Person</th>
<th>Role</th>
</tr>
</thead>
<tbody>
<tr>
<td>A. Ganesh Man Singh</td>
<td>1. First communist Prime Minister</td>
</tr>
<tr>
<td>B. Krishna Prasad Bhattarai</td>
<td>2. Chair of the commission that drafted the 2047 Constitution</td>
</tr>
<tr>
<td>C. Bishwanath Upadhyaya</td>
<td>3. Supreme leader of the People's Movement of 2046</td>
</tr>
<tr>
<td>D. Man Mohan Adhikari</td>
<td>4. Prime Minister of the interim government of 2047</td>
</tr>
</tbody>
</table></div>
`,options:[`A-3, B-2, C-4, D-1`,`A-3, B-4, C-2, D-1`,`A-4, B-3, C-2, D-1`,`A-3, B-4, C-1, D-2`],answer:1,explanation:`Ganesh Man Singh led the movement, K.P. Bhattarai headed the interim government, Bishwanath Upadhyaya chaired the drafting commission, and Man Mohan Adhikari was the first communist Prime Minister.`},{id:`Q 2.8.4`,label:`Pattern-Based – Reconstructed`,stem:`<p><strong>Assertion (A):</strong> The People's Movement of 2062/63 ended on 11 Baisakh 2063.</p>
<p><strong>Reason (R):</strong> On that day the King restored the dissolved House of Representatives.</p>
`,options:[`Both A and R are true, and R explains A.`,`Both A and R are true, but R does not explain A.`,`A is true, but R is false.`,`A is false, but R is true.`],answer:0,explanation:`The restoration of the House met the main demand of the Seven-Party Alliance, so the movement was called off.`},{id:`Q 2.8.5`,label:`Expected – Practice`,stem:`<p>On which date did the Maoist armed conflict begin?</p>
`,options:[`1 Falgun 2052`,`7 Falgun 2046`,`19 Jestha 2058`,`19 Magh 2061`],answer:0,explanation:`1 Falgun 2052 (13 February 1996).`}]},{id:`2.9`,title:`Republic, Constitution and events to the present (गणतन्त्र, संविधान र हालसम्मका घटना)`,questions:[{id:`Q 2.9.1`,label:`Expected – Practice`,stem:`<p>On which date was Nepal declared a republic?</p>
`,options:[`11 Baisakh 2063`,`28 Chaitra 2064`,`15 Jestha 2065`,`3 Ashoj 2072`],answer:2,explanation:`The first meeting of the Constituent Assembly declared the republic on 15 Jestha 2065 (28 May 2008).`},{id:`Q 2.9.2`,label:`Pattern-Based – Reconstructed`,stem:`<p>Match the person with the &quot;first&quot;.</p>
<div class="tw"><table>
<thead>
<tr>
<th>Person</th>
<th>First</th>
</tr>
</thead>
<tbody>
<tr>
<td>A. Ram Baran Yadav</td>
<td>1. First woman Prime Minister</td>
</tr>
<tr>
<td>B. Bidya Devi Bhandari</td>
<td>2. First Prime Minister of the republic</td>
</tr>
<tr>
<td>C. Sushila Karki</td>
<td>3. First President</td>
</tr>
<tr>
<td>D. Pushpa Kamal Dahal</td>
<td>4. First woman President</td>
</tr>
</tbody>
</table></div>
`,options:[`A-3, B-4, C-1, D-2`,`A-3, B-1, C-4, D-2`,`A-2, B-4, C-1, D-3`,`A-3, B-4, C-2, D-1`],answer:0,explanation:`Ram Baran Yadav was the first President, Bidya Devi Bhandari the first woman President, Sushila Karki the first woman Prime Minister, and Pushpa Kamal Dahal the first Prime Minister of the republic.`},{id:`Q 2.9.3`,label:`Pattern-Based – Reconstructed`,stem:`<p>Read the statements.</p>
<ol>
<li>The Constitution of Nepal was proclaimed on 3 Ashoj 2072.</li>
<li>It was proclaimed by President Bidya Devi Bhandari.</li>
<li>It was made by the second Constituent Assembly.</li>
</ol>
<p>Which statements are correct?</p>
`,options:[`1 and 2 only`,`1 and 3 only`,`2 and 3 only`,`1, 2 and 3`],answer:1,explanation:`President Ram Baran Yadav proclaimed the Constitution. Bidya Devi Bhandari was elected President on 11 Kartik 2072.`},{id:`Q 2.9.4`,label:`Pattern-Based – Reconstructed`,stem:`<p>Arrange the events in order of time, earliest first.</p>
<ol>
<li>Second Constituent Assembly election</li>
<li>Declaration of the republic</li>
<li>Proclamation of the Constitution of Nepal</li>
<li>First Constituent Assembly election</li>
</ol>
`,options:[`4 – 1 – 2 – 3`,`2 – 4 – 1 – 3`,`4 – 2 – 3 – 1`,`4 – 2 – 1 – 3`],answer:3,explanation:`2064, 2065, 2070, 2072.`},{id:`Q 2.9.5`,label:`Expected – Practice`,stem:`<p>Which party won a majority in the House of Representatives election of 21 Falgun 2082?</p>
`,options:[`Nepali Congress`,`Rastriya Swatantra Party`,`CPN (UML)`,`Rastriya Prajatantra Party`],answer:1,explanation:`The Rastriya Swatantra Party won 182 of 275 seats. 🔄 Recent fact; confirm it before your examination.`}]},{id:`2.10`,title:`Timeline: treaties, wars, constitutions and firsts (सन्धि, युद्ध, संविधान र पहिला घटना)`,questions:[{id:`Q 2.10.1`,label:`Expected – Practice`,stem:`<p>With which country did Nepal first set up diplomatic relations?</p>
`,options:[`India`,`China`,`Britain`,`United States`],answer:2,explanation:`Relations with Britain date from 1816. The United States (1947) was second.`},{id:`Q 2.10.2`,label:`Pattern-Based – Reconstructed`,stem:`<p>Match the treaty with its year.</p>
<div class="tw"><table>
<thead>
<tr>
<th>Treaty</th>
<th>Year (AD)</th>
</tr>
</thead>
<tbody>
<tr>
<td>A. Betrawati</td>
<td>1. 1923</td>
</tr>
<tr>
<td>B. Sugauli (ratified)</td>
<td>2. 1856</td>
</tr>
<tr>
<td>C. Thapathali</td>
<td>3. 1792</td>
</tr>
<tr>
<td>D. Friendship treaty with Britain</td>
<td>4. 1816</td>
</tr>
</tbody>
</table></div>
`,options:[`A-3, B-4, C-1, D-2`,`A-4, B-3, C-2, D-1`,`A-3, B-2, C-4, D-1`,`A-3, B-4, C-2, D-1`],answer:3,explanation:`Betrawati 1792, Sugauli 1816, Thapathali 1856, treaty with Britain 1923.`},{id:`Q 2.10.3`,label:`Pattern-Based – Reconstructed`,stem:`<p>Arrange the constitutions in order of time, earliest first.</p>
<ol>
<li>Interim Constitution of Nepal</li>
<li>Government of Nepal Act</li>
<li>Constitution of the Kingdom of Nepal given by King Birendra</li>
<li>Constitution of the Kingdom of Nepal given by King Mahendra</li>
</ol>
`,options:[`2 – 4 – 3 – 1`,`2 – 3 – 4 – 1`,`4 – 2 – 3 – 1`,`2 – 4 – 1 – 3`],answer:0,explanation:`2004, 2015, 2047, 2063.`},{id:`Q 2.10.4`,label:`Pattern-Based – Reconstructed`,stem:`<p>Which one does not belong to the group?</p>
`,options:[`Treaty of Kerung`,`Sugauli Treaty`,`Treaty of Betrawati`,`Treaty of Thapathali`],answer:1,explanation:`The Sugauli Treaty was made with the British East India Company. The other three followed wars with Tibet or China.`},{id:`Q 2.10.5`,label:`Expected – Practice`,stem:`<p>In which year did Nepal become a member of the United Nations?</p>
`,options:[`1947 AD`,`1950 AD`,`1961 AD`,`1955 AD`],answer:3,explanation:`14 December 1955 (29 Mangsir 2012 BS).`}]},{id:`T`,title:`End-of-chapter test — Top 25`,questions:[{id:`T1`,label:`Expected – Practice`,stem:`<p>Who was the last king of the Kirat dynasty?</p>
`,options:[`Yalambar`,`Patuka`,`Gasti`,`Sthunko`],answer:2,explanation:`Gasti was the last Kirat king; Yalambar was the first.`},{id:`T2`,label:`Expected – Practice`,stem:`<p>The Ashoka pillar at Lumbini was rediscovered in 1896 by Dr Alois Führer and:</p>
`,options:[`Khadga Shamsher`,`Chandra Shamsher`,`Bir Shamsher`,`Dev Shamsher`],answer:0,explanation:`Khadga Shamsher was then the governor of Palpa.`},{id:`T3`,label:`Expected – Practice`,stem:`<p>Who built the palace called Kailashkut Bhawan?</p>
`,options:[`Manadeva`,`Amshuverma`,`Narendradeva`,`Jayasthiti Malla`],answer:1,explanation:`Amshuverma ruled from Kailashkut Bhawan; Manadeva's palace was Managriha.`},{id:`T4`,label:`Pattern-Based – Reconstructed`,stem:`<p>Read the statements about Nepal Sambat.</p>
<ol>
<li>It began in 879 AD.</li>
<li>Tradition links it with Shankhadhar Sakhwa.</li>
<li>It began in the reign of Manadeva.</li>
</ol>
<p>Which statements are correct?</p>
`,options:[`1 only`,`2 and 3 only`,`1, 2 and 3`,`1 and 2 only`],answer:3,explanation:`Nepal Sambat began in the reign of Raghavadeva, about four centuries after Manadeva.`},{id:`T5`,label:`Expected – Practice`,stem:`<p>In which city did Araniko build the White Stupa?</p>
`,options:[`Lhasa`,`Beijing`,`Kathmandu`,`Nanjing`],answer:1,explanation:`Araniko worked at the court of Kublai Khan and built the White Stupa in Beijing.`},{id:`T6`,label:`Expected – Practice`,stem:`<p>Who built the five-storey Nyatapola temple of Bhaktapur?</p>
`,options:[`Ranajit Malla`,`Yaksha Malla`,`Jitamitra Malla`,`Bhupatindra Malla`],answer:3,explanation:`Bhupatindra Malla built it in 1702.`},{id:`T7`,label:`Pattern-Based – Reconstructed`,stem:`<p>Match the monument with the king linked with it.</p>
<div class="tw"><table>
<thead>
<tr>
<th>Monument</th>
<th>King</th>
</tr>
</thead>
<tbody>
<tr>
<td>A. Rani Pokhari</td>
<td>1. Jaya Prakash Malla</td>
</tr>
<tr>
<td>B. Taleju temple of Kathmandu</td>
<td>2. Ranajit Malla</td>
</tr>
<tr>
<td>C. Golden Gate of Bhaktapur</td>
<td>3. Pratap Malla</td>
</tr>
<tr>
<td>D. Kumari House</td>
<td>4. Mahendra Malla</td>
</tr>
</tbody>
</table></div>
`,options:[`A-3, B-4, C-2, D-1`,`A-4, B-3, C-2, D-1`,`A-3, B-4, C-1, D-2`,`A-3, B-2, C-4, D-1`],answer:0,explanation:`Rani Pokhari–Pratap Malla, Taleju temple–Mahendra Malla, Golden Gate–Ranajit Malla, Kumari House–Jaya Prakash Malla.`},{id:`T8`,label:`Expected – Practice`,stem:`<p>Who founded the Shah kingdom of Gorkha in 1559 AD?</p>
`,options:[`Ram Shah`,`Nara Bhupal Shah`,`Drabya Shah`,`Prithvipati Shah`],answer:2,explanation:`Drabya Shah, a prince of Lamjung, became king of Gorkha in 1616 BS.`},{id:`T9`,label:`Expected – Practice`,stem:`<p>The saying &quot;If you do not get justice, go to Gorkha&quot; is linked with which king?</p>
`,options:[`Ram Shah`,`Drabya Shah`,`Prithvi Narayan Shah`,`Rana Bahadur Shah`],answer:0,explanation:`Ram Shah was famous for his just rule and for fixing weights and measures.`},{id:`T10`,label:`Expected – Practice`,stem:`<p>In which battle was Kalu Pande killed?</p>
`,options:[`Nuwakot`,`Kirtipur`,`Makwanpur`,`Sindhuligadhi`],answer:1,explanation:`He fell in the first attack on Kirtipur in 1757.`},{id:`T11`,label:`Expected – Practice`,stem:`<p>Where did Prithvi Narayan Shah die?</p>
`,options:[`Gorkha`,`Kathmandu`,`Bhaktapur`,`Devighat, Nuwakot`],answer:3,explanation:`He died at Devighat on 1 Magh 1831 BS (11 January 1775).`},{id:`T12`,label:`Pattern-Based – Reconstructed`,stem:`<p>Arrange the events in order of time, earliest first.</p>
<ol>
<li>Treaty of Betrawati</li>
<li>Kot Massacre</li>
<li>Start of the Anglo-Nepal War</li>
<li>Treaty of Thapathali</li>
</ol>
`,options:[`1 – 2 – 3 – 4`,`3 – 1 – 2 – 4`,`1 – 3 – 2 – 4`,`1 – 3 – 4 – 2`],answer:2,explanation:`1792, 1814, 1846, 1856.`},{id:`T13`,label:`Expected – Practice`,stem:`<p>Who was the Mukhtiyar (chief minister) of Nepal during the Anglo-Nepal War?</p>
`,options:[`Bhimsen Thapa`,`Mathbar Singh Thapa`,`Jung Bahadur`,`Kalu Pande`],answer:0,explanation:`Bhimsen Thapa held the post from 1806 to 1837.`},{id:`T14`,label:`Expected – Practice`,stem:`<p>The first Muluki Ain (national legal code) of 1910 BS was issued in the time of which Prime Minister?</p>
`,options:[`Bhimsen Thapa`,`Chandra Shamsher`,`Jung Bahadur`,`Bir Shamsher`],answer:2,explanation:`Jung Bahadur had it prepared after his visit to Europe.`},{id:`T15`,label:`Expected – Practice`,stem:`<p>Which Rana Prime Minister held office for only 114 days?</p>
`,options:[`Bhim Shamsher`,`Dev Shamsher`,`Padma Shamsher`,`Ranodip Singh`],answer:1,explanation:`Dev Shamsher ruled for 114 days in 1901 and was removed by Chandra Shamsher.`},{id:`T16`,label:`Pattern-Based – Reconstructed`,stem:`<p><strong>Assertion (A):</strong> The British returned Banke, Bardiya, Kailali and Kanchanpur to Nepal in 1860.</p>
<p><strong>Reason (R):</strong> Nepal had helped the British to put down the uprising of 1857 in India.</p>
`,options:[`Both A and R are true, and R explains A.`,`Both A and R are true, but R does not explain A.`,`A is true, but R is false.`,`A is false, but R is true.`],answer:0,explanation:`The land, called the Naya Muluk, was returned as a reward for Jung Bahadur's help.`},{id:`T17`,label:`Expected – Practice`,stem:`<p>Who is honoured as the first martyr of Nepal?</p>
`,options:[`Shukraraj Shastri`,`Dashrath Chand`,`Bhimdatta Panta`,`Lakhan Thapa Magar`],answer:3,explanation:`Lakhan Thapa Magar was hanged in 1933 BS (1877) for rising against Jung Bahadur.`},{id:`T18`,label:`Expected – Practice`,stem:`<p>In which year was Tri-Chandra College founded?</p>
`,options:[`1958 BS`,`1968 BS`,`1975 BS`,`1994 BS`],answer:2,explanation:`1975 BS (1918), in the time of Chandra Shamsher.`},{id:`T19`,label:`Pattern-Based – Reconstructed`,stem:`<p>Fill in the blank. The Government of Nepal Act, 2004 — the first constitution of Nepal — was announced by Prime Minister ______.</p>
`,options:[`Juddha Shamsher`,`Mohan Shamsher`,`Chandra Shamsher`,`Padma Shamsher`],answer:3,explanation:`Padma Shamsher announced it on 13 Magh 2004 (26 January 1948).`},{id:`T20`,label:`Expected – Practice`,stem:`<p>Which article of the Constitution of 2015 did King Mahendra use for the takeover of 1 Poush 2017?</p>
`,options:[`Article 55`,`Article 127`,`Article 35`,`Article 115`],answer:0,explanation:`Article 55 gave the King emergency powers.`},{id:`T21`,label:`Pattern-Based – Reconstructed`,stem:`<p>Read the statements about the referendum.</p>
<ol>
<li>King Birendra announced it in 2036 BS.</li>
<li>The reformed Panchayat side received about 54.8% of the votes.</li>
<li>After it, the third amendment brought direct election of the Rastriya Panchayat by adult franchise.</li>
</ol>
<p>Which statements are correct?</p>
`,options:[`1 and 2 only`,`2 and 3 only`,`1 and 3 only`,`1, 2 and 3`],answer:3,explanation:`All three statements are correct.`},{id:`T22`,label:`Expected – Practice`,stem:`<p>Who chaired the interim council of ministers formed in Chaitra 2069 to hold the second Constituent Assembly election?</p>
`,options:[`Baburam Bhattarai`,`Khil Raj Regmi`,`Sushil Koirala`,`Ram Baran Yadav`],answer:1,explanation:`Khil Raj Regmi was Chief Justice at the time.`},{id:`T23`,label:`Pattern-Based – Reconstructed`,stem:`<p>Match the election with the party that won the most seats.</p>
<div class="tw"><table>
<thead>
<tr>
<th>Election (BS)</th>
<th>Largest party</th>
</tr>
</thead>
<tbody>
<tr>
<td>A. 2015</td>
<td>1. CPN (UML)</td>
</tr>
<tr>
<td>B. 2051</td>
<td>2. Rastriya Swatantra Party</td>
</tr>
<tr>
<td>C. 2064</td>
<td>3. Nepali Congress</td>
</tr>
<tr>
<td>D. 2082</td>
<td>4. Communist Party of Nepal (Maoist)</td>
</tr>
</tbody>
</table></div>
`,options:[`A-3, B-4, C-1, D-2`,`A-1, B-3, C-4, D-2`,`A-3, B-1, C-4, D-2`,`A-3, B-1, C-2, D-4`],answer:2,explanation:`Nepali Congress in 2015, CPN (UML) in 2051, CPN (Maoist) in 2064 and the Rastriya Swatantra Party in 2082.`},{id:`T24`,label:`Expected – Practice`,stem:`<p>How many members voted in favour when the Constituent Assembly passed the Constitution of Nepal on 30 Bhadra 2072?</p>
`,options:[`601`,`560`,`532`,`507`],answer:3,explanation:`507 voted for and 25 against. The figure 560 belongs to the vote for the republic in 2065.`},{id:`T25`,label:`Pattern-Based – Reconstructed`,stem:`<p>Arrange the institutions in the order in which they were founded, earliest first.</p>
<ol>
<li>Gorkhapatra</li>
<li>Nepal Bank Limited</li>
<li>Tri-Chandra College</li>
<li>Tribhuvan University</li>
</ol>
`,options:[`1 – 3 – 2 – 4`,`1 – 2 – 3 – 4`,`3 – 1 – 2 – 4`,`1 – 3 – 4 – 2`],answer:0,explanation:`1958, 1975, 1994 and 2016 BS.`}]}]},{num:3,title:`Constitution of Nepal`,nep:`नेपालको संविधान`,slug:`part-07-chapter-03-constitution-of-nepal`,topics:[{id:`3.1`,title:`Constitutional history: the seven constitutions (संवैधानिक इतिहास: सात संविधान)`,questions:[{id:`Q 3.1.1`,label:`Expected – Practice`,stem:`<p>How many Parts, Articles and Schedules does the Constitution of Nepal have?</p>
`,options:[`23 Parts, 133 Articles, 3 Schedules`,`25 Parts, 167 Articles, 4 Schedules`,`35 Parts, 308 Articles, 9 Schedules`,`33 Parts, 305 Articles, 7 Schedules`],answer:2,explanation:`35 – 308 – 9. Option (a) is the Constitution of 2047 and option (b) is the Interim Constitution of 2063.`},{id:`Q 3.1.2`,label:`Pattern-Based – Reconstructed`,stem:`<p>Match the constitution with the person who headed its drafting body.</p>
<div class="tw"><table>
<thead>
<tr>
<th>Constitution</th>
<th>Head of the drafting body</th>
</tr>
</thead>
<tbody>
<tr>
<td>A. Constitution of 2015</td>
<td>1. Bishwanath Upadhyaya</td>
</tr>
<tr>
<td>B. Constitution of 2019</td>
<td>2. Laxman Prasad Aryal</td>
</tr>
<tr>
<td>C. Constitution of 2047</td>
<td>3. Bhagawati Prasad Singh</td>
</tr>
<tr>
<td>D. Interim Constitution of 2063</td>
<td>4. Rishikesh Shah</td>
</tr>
</tbody>
</table></div>
`,options:[`A-3, B-4, C-1, D-2`,`A-4, B-3, C-1, D-2`,`A-3, B-4, C-2, D-1`,`A-1, B-4, C-3, D-2`],answer:0,explanation:`Bhagawati Prasad Singh (2015), Rishikesh Shah (2019), Bishwanath Upadhyaya (2047), Laxman Prasad Aryal (2063).`},{id:`Q 3.1.3`,label:`Expected – Practice`,stem:`<p>Which constitution was the first to place sovereignty in the Nepali people?</p>
`,options:[`Constitution of the Kingdom of Nepal, 2015`,`Constitution of the Kingdom of Nepal, 2047`,`Interim Constitution of Nepal, 2063`,`Constitution of Nepal (2072)`],answer:1,explanation:`The Constitution of 2047, made after the People's Movement of 2046, was the first to say that sovereignty lies in the people.`},{id:`Q 3.1.4`,label:`Pattern-Based – Reconstructed`,stem:`<p>Read the statements.</p>
<ol>
<li>The Government of Nepal Act, 2004 was never put into practice.</li>
<li>The Constitution of the Kingdom of Nepal, 2047 was amended three times.</li>
<li>The Interim Constitution of Nepal, 2063 had 167 Articles.</li>
</ol>
<p>Which statements are correct?</p>
`,options:[`1 and 2 only`,`1 and 3 only`,`2 and 3 only`,`1, 2 and 3`],answer:1,explanation:`The Constitution of 2047 was never amended. Three amendments were made to the Constitution of 2019.`},{id:`Q 3.1.5`,label:`Pattern-Based – Reconstructed`,stem:`<p>Three of these constitutions were given by a king. Which one was not?</p>
`,options:[`Interim Government of Nepal Act, 2007`,`Constitution of the Kingdom of Nepal, 2015`,`Constitution of Nepal, 2019`,`Interim Constitution of Nepal, 2063`],answer:3,explanation:`The Interim Constitution of 2063 was proclaimed by Parliament. King Tribhuvan gave the Act of 2007; King Mahendra gave the constitutions of 2015 and 2019.`}]},{id:`3.2`,title:`Salient features, Preamble, Parts and Schedules (विशेषता, प्रस्तावना, भाग र अनुसूची)`,questions:[{id:`Q 3.2.1`,label:`Expected – Practice`,stem:`<p>Which Schedule of the Constitution lists the powers of the local level?</p>
`,options:[`Schedule 5`,`Schedule 6`,`Schedule 8`,`Schedule 9`],answer:2,explanation:`Schedule 8 has the 22 powers of the local level. Schedule 9 has the powers shared by all three levels.`},{id:`Q 3.2.2`,label:`Pattern-Based – Reconstructed`,stem:`<p>Read the statements.</p>
<ol>
<li>Article 6 makes Nepali in the Devanagari script the only language of the nation.</li>
<li>Article 4 describes Nepal as a &quot;socialism-oriented&quot; state.</li>
<li>Article 2 places sovereignty and state authority in the Nepali people.</li>
</ol>
<p>Which statements are correct?</p>
`,options:[`1 only`,`1 and 2 only`,`1 and 3 only`,`2 and 3 only`],answer:3,explanation:`Article 6 says that all mother tongues spoken in Nepal are languages of the nation. Nepali in the Devanagari script is the official language under Article 7.`},{id:`Q 3.2.3`,label:`Pattern-Based – Reconstructed`,stem:`<p>Match the Schedule with its subject.</p>
<div class="tw"><table>
<thead>
<tr>
<th>Schedule</th>
<th>Subject</th>
</tr>
</thead>
<tbody>
<tr>
<td>A. Schedule 1</td>
<td>1. Coat of arms</td>
</tr>
<tr>
<td>B. Schedule 2</td>
<td>2. Provinces and their districts</td>
</tr>
<tr>
<td>C. Schedule 3</td>
<td>3. National flag</td>
</tr>
<tr>
<td>D. Schedule 4</td>
<td>4. National anthem</td>
</tr>
</tbody>
</table></div>
`,options:[`A-3, B-4, C-1, D-2`,`A-4, B-3, C-1, D-2`,`A-3, B-1, C-4, D-2`,`A-3, B-4, C-2, D-1`],answer:0,explanation:`Flag, anthem, coat of arms, then the provinces with their districts.`},{id:`Q 3.2.4`,label:`Expected – Practice`,stem:`<p>According to Article 8, how many rays has the sun in the national flag of Nepal?</p>
`,options:[`Eight`,`Twelve`,`Sixteen`,`Ten`],answer:1,explanation:`The sun in the lower triangle has twelve rays. The crescent moon is in the upper triangle.`},{id:`Q 3.2.5`,label:`Expected – Practice`,stem:`<p>Which Part of the Constitution deals with amendment of the Constitution?</p>
`,options:[`Part 29`,`Part 30`,`Part 31`,`Part 35`],answer:2,explanation:`Part 31 has one Article, Article 274. Part 30 (Article 273) is on emergency power.`}]},{id:`3.3`,title:`Citizenship (नागरिकता)`,questions:[{id:`Q 3.3.1`,label:`Expected – Practice`,stem:`<p>Which Part of the Constitution of Nepal deals with citizenship?</p>
`,options:[`Part 2`,`Part 3`,`Part 4`,`Part 5`],answer:0,explanation:`Part 2, Articles 10 to 15. Part 3 is on fundamental rights and duties.`},{id:`Q 3.3.2`,label:`Expected – Practice`,stem:`<p>Which rights does non-resident Nepali citizenship carry under Article 14?</p>
`,options:[`Political and civil rights`,`All the rights of a citizen by descent`,`Only the right to vote`,`Economic, social and cultural rights`],answer:3,explanation:`Article 14 names economic, social and cultural rights, as federal law provides. Political rights are not included.`},{id:`Q 3.3.3`,label:`Pattern-Based – Reconstructed`,stem:`<p>Three of these offices can be held only by a citizen by descent under Article 289. Which one is not on that list?</p>
`,options:[`Chief Justice`,`Chief Minister of a province`,`Chief Election Commissioner`,`Province Chief`],answer:2,explanation:`Posts in constitutional bodies are open also to naturalised citizens (after ten years' residence) and citizens by birth (after five years).`},{id:`Q 3.3.4`,label:`Pattern-Based – Reconstructed`,stem:`<p>Read the statements.</p>
<ol>
<li>Nepal has single federal citizenship with provincial identity.</li>
<li>A foreign woman married to a Nepali citizen may take naturalised citizenship as federal law provides.</li>
<li>A non-resident Nepali citizen may vote in the election of the House of Representatives.</li>
</ol>
<p>Which statements are correct?</p>
`,options:[`1 and 2 only`,`1 and 3 only`,`2 and 3 only`,`1, 2 and 3`],answer:0,explanation:`Non-resident Nepali citizenship gives economic, social and cultural rights only.`},{id:`Q 3.3.5`,label:`Pattern-Based – Reconstructed`,stem:`<p><strong>Assertion (A):</strong> A person of Nepali origin who has become a citizen of Australia and lives there can be given non-resident Nepali citizenship.</p>
<p><strong>Reason (R):</strong> Article 14 allows such citizenship for persons of Nepali origin who hold foreign citizenship and live outside the SAARC region.</p>
`,options:[`Both A and R are true, and R explains A.`,`Both A and R are true, but R does not explain A.`,`A is true, but R is false.`,`A is false, but R is true.`],answer:0,explanation:`Australia is not a SAARC country, so the conditions of Article 14 are met.`}]},{id:`3.4`,title:`Fundamental rights and duties (मौलिक हक र कर्तव्य)`,questions:[{id:`Q 3.4.1`,label:`Expected – Practice`,stem:`<p>How many fundamental rights does the Constitution of Nepal give in Articles 16 to 46?</p>
`,options:[`21`,`27`,`33`,`31`],answer:3,explanation:`Thirty-one. The Interim Constitution of 2063 had 21. Part 3 has 33 Articles because it also holds Articles 47 and 48.`},{id:`Q 3.4.2`,label:`Pattern-Based – Reconstructed`,stem:`<p>Match the Article with the right.</p>
<div class="tw"><table>
<thead>
<tr>
<th>Article</th>
<th>Right</th>
</tr>
</thead>
<tbody>
<tr>
<td>A. Article 16</td>
<td>1. Right to information</td>
</tr>
<tr>
<td>B. Article 27</td>
<td>2. Right against exile</td>
</tr>
<tr>
<td>C. Article 31</td>
<td>3. Right to live with dignity</td>
</tr>
<tr>
<td>D. Article 45</td>
<td>4. Right relating to education</td>
</tr>
</tbody>
</table></div>
`,options:[`A-3, B-4, C-1, D-2`,`A-3, B-1, C-4, D-2`,`A-1, B-3, C-4, D-2`,`A-3, B-1, C-2, D-4`],answer:1,explanation:`Article 16 dignity, Article 27 information, Article 31 education, Article 45 exile.`},{id:`Q 3.4.3`,label:`Expected – Practice`,stem:`<p>Within what time must an arrested person be brought before a judicial authority under Article 20?</p>
`,options:[`24 hours, not counting the time of travel`,`24 hours, including the time of travel`,`48 hours`,`Three days`],answer:0,explanation:`Twenty-four hours from the arrest, leaving out the time needed for the journey.`},{id:`Q 3.4.4`,label:`Pattern-Based – Reconstructed`,stem:`<p>Three of these are duties of citizens under Article 48. Which one is not listed there?</p>
`,options:[`To obey the Constitution and the law`,`To protect and preserve public property`,`To take part in every election`,`To give compulsory service when the State requires it`],answer:2,explanation:`Article 48 lists four duties. The fourth is to protect the nationality, sovereignty and integrity of Nepal. Voting is a right, not a listed duty.`},{id:`Q 3.4.5`,label:`Pattern-Based – Reconstructed`,stem:`<p>Read the statements.</p>
<ol>
<li>No law may provide for the death penalty.</li>
<li>The right against exile may be suspended during a state of emergency.</li>
<li>Every citizen has the right to free education up to the secondary level.</li>
</ol>
<p>Which statements are correct?</p>
`,options:[`1 and 2 only`,`1 and 3 only`,`2 and 3 only`,`1, 2 and 3`],answer:1,explanation:`Article 45 (right against exile) is on the list of rights that cannot be suspended under Article 273.`}]},{id:`3.5`,title:`Directive principles, policies and obligations of the State (राज्यका निर्देशक सिद्धान्त, नीति तथा दायित्व)`,questions:[{id:`Q 3.5.1`,label:`Expected – Practice`,stem:`<p>Which Part of the Constitution contains the directive principles, policies and obligations of the State?</p>
`,options:[`Part 3`,`Part 4`,`Part 5`,`Part 6`],answer:1,explanation:`Part 4, Articles 49 to 55.`},{id:`Q 3.5.2`,label:`Expected – Practice`,stem:`<p>What does Article 55 of the Constitution of Nepal provide?</p>
`,options:[`The President may declare a state of emergency.`,`The Government must submit an annual report to the President.`,`No court may be asked whether a matter in Part 4 has been carried out.`,`A committee of Parliament monitors the directive principles.`],answer:2,explanation:`Article 55 keeps Part 4 out of the courts. The annual report is in Article 53 and the committee in Article 54.`},{id:`Q 3.5.3`,label:`Pattern-Based – Reconstructed`,stem:`<p><strong>Assertion (A):</strong> A citizen cannot file a case to compel the State to carry out a directive principle.</p>
<p><strong>Reason (R):</strong> Article 55 says that no question may be raised in any court on whether a matter in Part 4 has been carried out.</p>
`,options:[`Both A and R are true, and R explains A.`,`Both A and R are true, but R does not explain A.`,`A is true, but R is false.`,`A is false, but R is true.`],answer:0,explanation:`Article 55 is the reason why Part 4 cannot be enforced through a court.`},{id:`Q 3.5.4`,label:`Pattern-Based – Reconstructed`,stem:`<p>Fill in the blank. Under Article 51, the foreign policy of Nepal rests on the Charter of the United Nations, non-alignment, the principles of ______, international law and the norms of world peace.</p>
`,options:[`Federalism`,`Socialism`,`Neutrality`,`Panchsheel`],answer:3,explanation:`Panchsheel, the five principles of peaceful coexistence, is named in head (m) of Article 51.`},{id:`Q 3.5.5`,label:`Pattern-Based – Reconstructed`,stem:`<p>Read the statements.</p>
<ol>
<li>Article 51 groups the policies of the State under thirteen heads.</li>
<li>The Government of Nepal submits an annual report on Part 4 to the President.</li>
<li>The economic objective in Article 50 names the public, private and cooperative sectors.</li>
</ol>
<p>Which statements are correct?</p>
`,options:[`1 and 2 only`,`1 and 3 only`,`2 and 3 only`,`1, 2 and 3`],answer:3,explanation:`All three are correct: heads (a) to (m); Article 53; Article 50 (3).`}]},{id:`3.6`,title:`Executive: President, Vice-President and Council of Ministers (कार्यपालिका: राष्ट्रपति, उपराष्ट्रपति र मन्त्रिपरिषद्)`,questions:[{id:`Q 3.6.1`,label:`Expected – Practice`,stem:`<p>What is the minimum age to become President of Nepal?</p>
`,options:[`25 years`,`35 years`,`45 years`,`50 years`],answer:2,explanation:`Article 64 requires at least 45 years. The same applies to the Vice-President.`},{id:`Q 3.6.2`,label:`Expected – Practice`,stem:`<p>To whom does the President of Nepal address a resignation?</p>
`,options:[`The Vice-President`,`The Prime Minister`,`The Chief Justice`,`The Speaker of the House of Representatives`],answer:0,explanation:`Article 65. The Vice-President, in turn, resigns to the President.`},{id:`Q 3.6.3`,label:`Pattern-Based – Reconstructed`,stem:`<p>Match the clause of Article 76 with the person who is appointed Prime Minister under it.</p>
<div class="tw"><table>
<thead>
<tr>
<th>Clause</th>
<th>Person appointed</th>
</tr>
</thead>
<tbody>
<tr>
<td>A. Clause (1)</td>
<td>1. Leader of the party with the most members in the House</td>
</tr>
<tr>
<td>B. Clause (2)</td>
<td>2. Any member who shows a ground for winning a vote of confidence</td>
</tr>
<tr>
<td>C. Clause (3)</td>
<td>3. Leader of the party that has a majority in the House</td>
</tr>
<tr>
<td>D. Clause (5)</td>
<td>4. Member who commands a majority with the support of two or more parties</td>
</tr>
</tbody>
</table></div>
`,options:[`A-3, B-1, C-4, D-2`,`A-4, B-3, C-1, D-2`,`A-3, B-4, C-2, D-1`,`A-3, B-4, C-1, D-2`],answer:3,explanation:`Majority party, then coalition, then largest party, then any member who can show support.`},{id:`Q 3.6.4`,label:`Pattern-Based – Reconstructed`,stem:`<p>Read the statements.</p>
<ol>
<li>A person who is not a member of the Federal Parliament can never be appointed a minister.</li>
<li>The Council of Ministers may have at most 25 members, including the Prime Minister.</li>
<li>The executive power of Nepal lies in the Council of Ministers.</li>
</ol>
<p>Which statements are correct?</p>
`,options:[`1 and 2 only`,`1 and 3 only`,`2 and 3 only`,`1, 2 and 3`],answer:2,explanation:`Under Article 78 a non-member may be appointed, but must become a member of the Federal Parliament within six months.`},{id:`Q 3.6.5`,label:`Pattern-Based – Reconstructed`,stem:`<p>Arrange these Presidents of Nepal in order of time, earliest first.</p>
<ol>
<li>Bidya Devi Bhandari</li>
<li>Ram Chandra Paudel</li>
<li>Ram Baran Yadav</li>
</ol>
`,options:[`1 – 3 – 2`,`3 – 1 – 2`,`3 – 2 – 1`,`2 – 1 – 3`],answer:1,explanation:`Ram Baran Yadav (2065), Bidya Devi Bhandari (2072), Ram Chandra Paudel (2079).`}]},{id:`3.7`,title:`Federal Parliament and law-making (संघीय संसद र कानून निर्माण)`,questions:[{id:`Q 3.7.1`,label:`Expected – Practice`,stem:`<p>How many members does the Federal Parliament of Nepal have in all?</p>
`,options:[`275`,`330`,`601`,`334`],answer:3,explanation:`275 in the House of Representatives and 59 in the National Assembly.`},{id:`Q 3.7.2`,label:`Expected – Practice`,stem:`<p>What is the term of office of a member of the National Assembly?</p>
`,options:[`Five years`,`Six years`,`Four years`,`Two years`],answer:1,explanation:`Six years. One-third of the members retire every two years, so the House itself is permanent.`},{id:`Q 3.7.3`,label:`Pattern-Based – Reconstructed`,stem:`<p>Match the event with its time limit.</p>
<div class="tw"><table>
<thead>
<tr>
<th>Event</th>
<th>Time limit</th>
</tr>
</thead>
<tbody>
<tr>
<td>A. National Assembly returns a Money Bill</td>
<td>1. Six months</td>
</tr>
<tr>
<td>B. National Assembly returns any other Bill</td>
<td>2. Sixty days</td>
</tr>
<tr>
<td>C. An Ordinance lapses after both Houses meet</td>
<td>3. Fifteen days</td>
</tr>
<tr>
<td>D. Longest gap between two sessions</td>
<td>4. Two months</td>
</tr>
</tbody>
</table></div>
`,options:[`A-3, B-4, C-2, D-1`,`A-4, B-3, C-2, D-1`,`A-3, B-2, C-4, D-1`,`A-3, B-4, C-1, D-2`],answer:0,explanation:`Fifteen days, two months, sixty days, six months.`},{id:`Q 3.7.4`,label:`Pattern-Based – Reconstructed`,stem:`<p>Read the statements.</p>
<ol>
<li>The quorum of each House is one-fourth of its total members.</li>
<li>The yearly budget estimate is presented on Jestha 15.</li>
<li>A Money Bill may be introduced in either House.</li>
</ol>
<p>Which statements are correct?</p>
`,options:[`1 and 2 only`,`1 and 3 only`,`2 and 3 only`,`1, 2 and 3`],answer:0,explanation:`A Money Bill may be introduced only in the House of Representatives (Article 110).`},{id:`Q 3.7.5`,label:`Pattern-Based – Reconstructed`,stem:`<p>Arrange the steps by which a Bill becomes an Act, first step first.</p>
<ol>
<li>The President authenticates the Bill.</li>
<li>The Bill is introduced in one House.</li>
<li>The second House passes the Bill.</li>
<li>The first House passes the Bill.</li>
</ol>
`,options:[`2 – 3 – 4 – 1`,`4 – 2 – 3 – 1`,`2 – 4 – 3 – 1`,`2 – 4 – 1 – 3`],answer:2,explanation:`Introduction, passage by the first House, passage by the second House, authentication.`}]},{id:`3.8`,title:`Judiciary (न्यायपालिका)`,questions:[{id:`Q 3.8.1`,label:`Expected – Practice`,stem:`<p>Besides the Chief Justice, what is the largest number of judges the Supreme Court may have?</p>
`,options:[`14`,`20`,`21`,`25`],answer:1,explanation:`Article 129: at most twenty judges in addition to the Chief Justice.`},{id:`Q 3.8.2`,label:`Expected – Practice`,stem:`<p>Who appoints the Chief Judge and the judges of a High Court?</p>
`,options:[`The President, on the recommendation of the Constitutional Council`,`The Province Chief, on the recommendation of the Chief Minister`,`The President, on the recommendation of the Judicial Council`,`The Chief Justice, on the recommendation of the Judicial Council`],answer:3,explanation:`Article 140. The same rule applies to District Judges (Article 149).`},{id:`Q 3.8.3`,label:`Pattern-Based – Reconstructed`,stem:`<p>Match the writ with its purpose.</p>
<div class="tw"><table>
<thead>
<tr>
<th>Writ</th>
<th>Purpose</th>
</tr>
</thead>
<tbody>
<tr>
<td>A. Habeas corpus</td>
<td>1. To ask by what authority a person holds a public office</td>
</tr>
<tr>
<td>B. Mandamus</td>
<td>2. To cancel an unlawful decision</td>
</tr>
<tr>
<td>C. Certiorari</td>
<td>3. To free a person held unlawfully</td>
</tr>
<tr>
<td>D. Quo warranto</td>
<td>4. To order an authority to do its legal duty</td>
</tr>
</tbody>
</table></div>
`,options:[`A-3, B-2, C-4, D-1`,`A-4, B-3, C-2, D-1`,`A-3, B-4, C-2, D-1`,`A-3, B-4, C-1, D-2`],answer:2,explanation:`Habeas corpus frees a person; mandamus commands a duty; certiorari cancels a decision; quo warranto questions the right to an office.`},{id:`Q 3.8.4`,label:`Pattern-Based – Reconstructed`,stem:`<p>Three of these are members of the Judicial Council. Which one is not?</p>
`,options:[`The Chief Justice`,`The Federal Minister for Law and Justice`,`The Attorney General`,`The senior-most judge of the Supreme Court`],answer:2,explanation:`The Attorney General is a member of the Judicial Service Commission (Article 154), not of the Judicial Council (Article 153).`},{id:`Q 3.8.5`,label:`Pattern-Based – Reconstructed`,stem:`<p>Read the statements.</p>
<ol>
<li>A judge of the Supreme Court retires at the age of 65.</li>
<li>A judge of a High Court retires at the age of 65.</li>
<li>The Constitutional Bench consists of the Chief Justice and four other judges.</li>
</ol>
<p>Which statements are correct?</p>
`,options:[`1 and 2 only`,`1 and 3 only`,`2 and 3 only`,`1, 2 and 3`],answer:1,explanation:`Judges of High Courts and District Courts retire at 63.`}]},{id:`3.9`,title:`Constitutional bodies (संवैधानिक निकाय)`,questions:[{id:`Q 3.9.1`,label:`Expected – Practice`,stem:`<p>How many bodies does Article 306 of the Constitution name as &quot;constitutional bodies&quot;?</p>
`,options:[`5`,`7`,`11`,`13`],answer:3,explanation:`Thirteen: six in Parts 21 to 26 and seven commissions in Part 27.`},{id:`Q 3.9.2`,label:`Expected – Practice`,stem:`<p>Who chairs the Constitutional Council?</p>
`,options:[`The Prime Minister`,`The President`,`The Chief Justice`,`The Speaker of the House of Representatives`],answer:0,explanation:`Article 284. The Chief Justice and the Speaker are members.`},{id:`Q 3.9.3`,label:`Pattern-Based – Reconstructed`,stem:`<p>Match the constitutional body with the Part of the Constitution that sets it up.</p>
<div class="tw"><table>
<thead>
<tr>
<th>Body</th>
<th>Part</th>
</tr>
</thead>
<tbody>
<tr>
<td>A. Commission for the Investigation of Abuse of Authority</td>
<td>1. Part 24</td>
</tr>
<tr>
<td>B. Auditor General</td>
<td>2. Part 23</td>
</tr>
<tr>
<td>C. Public Service Commission</td>
<td>3. Part 21</td>
</tr>
<tr>
<td>D. Election Commission</td>
<td>4. Part 22</td>
</tr>
</tbody>
</table></div>
`,options:[`A-3, B-2, C-4, D-1`,`A-3, B-4, C-2, D-1`,`A-4, B-3, C-2, D-1`,`A-3, B-4, C-1, D-2`],answer:1,explanation:`Parts 21, 22, 23 and 24, in that order.`},{id:`Q 3.9.4`,label:`Pattern-Based – Reconstructed`,stem:`<p>Three of these are constitutional bodies under Article 306. Which one is not?</p>
`,options:[`National Inclusion Commission`,`Tharu Commission`,`National Natural Resources and Fiscal Commission`,`Language Commission`],answer:3,explanation:`The Language Commission is formed by the Government of Nepal under Article 287 and is not on the Article 306 list.`},{id:`Q 3.9.5`,label:`Pattern-Based – Reconstructed`,stem:`<p>Read the statements.</p>
<ol>
<li>The term of office in the constitutional bodies is five years.</li>
<li>A member of the Public Service Commission must hold at least a master's degree.</li>
<li>The Commission for the Investigation of Abuse of Authority has a Chief Commissioner and four other Commissioners.</li>
</ol>
<p>Which statements are correct?</p>
`,options:[`1 and 2 only`,`1 and 3 only`,`2 and 3 only`,`1, 2 and 3`],answer:2,explanation:`The term is six years from the date of appointment.`}]},{id:`3.10`,title:`Emergency powers, amendment procedure and amendments so far (संकटकालीन अधिकार, संविधान संशोधन र हालसम्मका संशोधन)`,questions:[{id:`Q 3.10.1`,label:`Expected – Practice`,stem:`<p>Which Article of the Constitution lays down the procedure for amending it?</p>
`,options:[`Article 274`,`Article 273`,`Article 275`,`Article 306`],answer:0,explanation:`Article 274, the only Article of Part 31. Article 273 is on emergency power and Article 275 on referendum.`},{id:`Q 3.10.2`,label:`Expected – Practice`,stem:`<p>Once both Houses approve it, for how long does a declaration of emergency stay in force, counted from the date it was issued?</p>
`,options:[`One month`,`Three months`,`Six months`,`One year`],answer:1,explanation:`Three months. It may be extended once, for up to three months more.`},{id:`Q 3.10.3`,label:`Pattern-Based – Reconstructed`,stem:`<p>Read the statements.</p>
<ol>
<li>The first amendment changed Articles 42, 84 and 286.</li>
<li>The second amendment changed the coat of arms in Schedule 3.</li>
<li>The second amendment was made in 2072 BS.</li>
</ol>
<p>Which statements are correct?</p>
`,options:[`1 and 2 only`,`1 and 3 only`,`2 and 3 only`,`1, 2 and 3`],answer:0,explanation:`The second amendment was made in 2077 BS. The first amendment was made in 2072 BS.`},{id:`Q 3.10.4`,label:`Pattern-Based – Reconstructed`,stem:`<p><strong>Assertion (A):</strong> A Bill to amend the Constitution must be passed by at least two-thirds of all members of both Houses of the Federal Parliament.</p>
<p><strong>Reason (R):</strong> Clause (1) of Article 274 cannot itself be amended.</p>
`,options:[`Both A and R are true, and R explains A.`,`Both A and R are true, but R does not explain A.`,`A is true, but R is false.`,`A is false, but R is true.`],answer:1,explanation:`Both are rules of Article 274, but they are separate. One sets the majority; the other protects sovereignty and territorial integrity from amendment.`},{id:`Q 3.10.5`,label:`Pattern-Based – Reconstructed`,stem:`<p>Three of these are grounds for a state of emergency under Article 273. Which one is not?</p>
`,options:[`External aggression`,`Epidemic`,`Extreme economic disarray`,`Defeat of the government in a vote of confidence`],answer:3,explanation:`The six grounds are war, external aggression, armed rebellion, extreme economic disarray, natural calamity and epidemic. Losing a vote of confidence leads to a change of government under Articles 76 and 100.`}]},{id:`T`,title:`End-of-chapter test — Top 25`,questions:[{id:`T1`,label:`Expected – Practice`,stem:`<p>Which Article declares the Constitution to be the fundamental law of Nepal?</p>
`,options:[`Article 1`,`Article 2`,`Article 4`,`Article 307`],answer:0,explanation:`Article 1. Article 2 is on sovereignty, Article 4 on the State of Nepal, and Article 307 on the short title and commencement.`},{id:`T2`,label:`Expected – Practice`,stem:`<p>Which Article makes Nepali in the Devanagari script the official language of Nepal?</p>
`,options:[`Article 5`,`Article 6`,`Article 7`,`Article 9`],answer:2,explanation:`Article 7. Article 6 says that all mother tongues spoken in Nepal are languages of the nation.`},{id:`T3`,label:`Expected – Practice`,stem:`<p>Who chaired the Constituent Assembly that passed the Constitution of Nepal?</p>
`,options:[`Krishna Prasad Sitaula`,`Subas Chandra Nembang`,`Ram Baran Yadav`,`Laxman Prasad Aryal`],answer:1,explanation:`Subas Chandra Nembang. Krishna Prasad Sitaula chaired the Drafting Committee; Ram Baran Yadav, as President, proclaimed the Constitution.`},{id:`T4`,label:`Pattern-Based – Reconstructed`,stem:`<p>Arrange these constitutions by the number of their Articles, fewest first.</p>
<ol>
<li>Interim Constitution of Nepal, 2063</li>
<li>Constitution of the Kingdom of Nepal, 2047</li>
<li>Constitution of Nepal (2072)</li>
<li>Constitution of Nepal, 2019</li>
</ol>
`,options:[`2 – 4 – 1 – 3`,`4 – 1 – 2 – 3`,`4 – 2 – 3 – 1`,`4 – 2 – 1 – 3`],answer:3,explanation:`97, 133, 167 and 308 Articles.`},{id:`T5`,label:`Expected – Practice`,stem:`<p>Which Article fixes Kathmandu as the capital of Nepal?</p>
`,options:[`Article 4`,`Article 9`,`Article 288`,`Article 307`],answer:2,explanation:`Article 288. The same Article lets a Provincial Assembly choose the provincial capital by a two-thirds majority.`},{id:`T6`,label:`Expected – Practice`,stem:`<p>How many items are there in Schedule 5, the list of federal powers?</p>
`,options:[`15`,`21`,`25`,`35`],answer:3,explanation:`Thirty-five. Schedule 6 has 21, Schedule 7 has 25, Schedule 8 has 22 and Schedule 9 has 15.`},{id:`T7`,label:`Expected – Practice`,stem:`<p>Under Article 58, which level of government holds the residual powers?</p>
`,options:[`The federation`,`The provinces`,`The local levels`,`The federation and the provinces jointly`],answer:0,explanation:`Any matter not placed in a list belongs to the federation.`},{id:`T8`,label:`Pattern-Based – Reconstructed`,stem:`<p>Match the right with its Article.</p>
<div class="tw"><table>
<thead>
<tr>
<th>Right</th>
<th>Article</th>
</tr>
</thead>
<tbody>
<tr>
<td>A. Right to equality</td>
<td>1. Article 44</td>
</tr>
<tr>
<td>B. Right to privacy</td>
<td>2. Article 38</td>
</tr>
<tr>
<td>C. Rights of women</td>
<td>3. Article 18</td>
</tr>
<tr>
<td>D. Rights of the consumer</td>
<td>4. Article 28</td>
</tr>
</tbody>
</table></div>
`,options:[`A-3, B-2, C-4, D-1`,`A-3, B-4, C-2, D-1`,`A-4, B-3, C-2, D-1`,`A-3, B-4, C-1, D-2`],answer:1,explanation:`Equality 18, privacy 28, women 38, consumer 44.`},{id:`T9`,label:`Expected – Practice`,stem:`<p>Which Article gives the right to constitutional remedy?</p>
`,options:[`Article 16`,`Article 32`,`Article 45`,`Article 46`],answer:3,explanation:`Article 46, used through Article 133 (Supreme Court) or Article 144 (High Court).`},{id:`T10`,label:`Expected – Practice`,stem:`<p>Up to which level does Article 31 make education both compulsory and free?</p>
`,options:[`Primary level`,`Basic level`,`Secondary level`,`Higher level`],answer:1,explanation:`Compulsory and free up to the basic level; free up to the secondary level.`},{id:`T11`,label:`Pattern-Based – Reconstructed`,stem:`<p>Fill in the blanks. The President of Nepal holds office for ______ years, and a person may be elected President at most ______ times.</p>
`,options:[`four; two`,`five; three`,`five; two`,`six; two`],answer:2,explanation:`Articles 63 and 64.`},{id:`T12`,label:`Expected – Practice`,stem:`<p>Who performs the functions of the President if the offices of both President and Vice-President fall vacant?</p>
`,options:[`The Chief Justice`,`The Prime Minister`,`The Chairperson of the National Assembly`,`The Speaker of the House of Representatives`],answer:3,explanation:`Article 280.`},{id:`T13`,label:`Expected – Practice`,stem:`<p>Before whom does the President of Nepal take the oath of office?</p>
`,options:[`The Chief Justice`,`The Vice-President`,`The Speaker of the House of Representatives`,`The Prime Minister`],answer:0,explanation:`Article 71. The Vice-President takes the oath before the President.`},{id:`T14`,label:`Pattern-Based – Reconstructed`,stem:`<p>Read the statements about a motion of no-confidence against the Prime Minister.</p>
<ol>
<li>It is tabled by one-fourth of the members of the House of Representatives.</li>
<li>It may be tabled in the first year after the Prime Minister's appointment.</li>
<li>It must name the member proposed as the next Prime Minister.</li>
</ol>
<p>Which statements are correct?</p>
`,options:[`1 and 2 only`,`1 and 3 only`,`2 and 3 only`,`1, 2 and 3`],answer:1,explanation:`Under Article 100 the motion cannot be tabled in the first two years after the appointment.`},{id:`T15`,label:`Expected – Practice`,stem:`<p>What is the minimum age for membership of the National Assembly?</p>
`,options:[`25 years`,`30 years`,`35 years`,`45 years`],answer:2,explanation:`Thirty-five. For the House of Representatives it is 25.`},{id:`T16`,label:`Expected – Practice`,stem:`<p>How many members of the National Assembly are nominated by the President?</p>
`,options:[`3`,`5`,`8`,`10`],answer:0,explanation:`Three, on the recommendation of the Government of Nepal; at least one must be a woman.`},{id:`T17`,label:`Expected – Practice`,stem:`<p>Within how many days must the President authenticate a Bill presented under Article 113?</p>
`,options:[`7 days`,`15 days`,`30 days`,`60 days`],answer:1,explanation:`Fifteen days. Within that time the President may instead return a Bill once, but not a Money Bill.`},{id:`T18`,label:`Pattern-Based – Reconstructed`,stem:`<p>Three of these courts are named in Article 127 of the Constitution. Which one is not?</p>
`,options:[`Supreme Court`,`High Court`,`Appellate Court`,`District Court`],answer:2,explanation:`The Appellate Courts were replaced by the High Courts under this Constitution.`},{id:`T19`,label:`Expected – Practice`,stem:`<p>On whose recommendation does the President appoint the Attorney General?</p>
`,options:[`The Constitutional Council`,`The Judicial Council`,`The Chief Justice`,`The Prime Minister`],answer:3,explanation:`Article 157. The Attorney General holds office as long as the Prime Minister wishes.`},{id:`T20`,label:`Expected – Practice`,stem:`<p>What is the term of office of the Chief Justice of Nepal?</p>
`,options:[`Six years`,`Five years`,`Four years`,`Three years`],answer:0,explanation:`Article 129. The Chief Justice must still retire on reaching 65.`},{id:`T21`,label:`Pattern-Based – Reconstructed`,stem:`<p><strong>Assertion (A):</strong> A Money Bill can be introduced only in the House of Representatives.</p>
<p><strong>Reason (R):</strong> The National Assembly has no power to discuss a Money Bill.</p>
`,options:[`Both A and R are true, and R explains A.`,`Both A and R are true, but R does not explain A.`,`A is true, but R is false.`,`A is false, but R is true.`],answer:2,explanation:`The National Assembly does discuss a Money Bill and returns it within fifteen days, with suggestions if any.`},{id:`T22`,label:`Expected – Practice`,stem:`<p>Which body holds a referendum under the Constitution?</p>
`,options:[`The Federal Parliament`,`The Ministry of Home Affairs`,`The Supreme Court`,`The Election Commission`],answer:3,explanation:`Article 246. The decision to hold one is taken by two-thirds of the Federal Parliament (Article 275).`},{id:`T23`,label:`Expected – Practice`,stem:`<p>How many members, including the chairperson, has the National Security Council?</p>
`,options:[`5`,`7`,`9`,`11`],answer:1,explanation:`The Prime Minister, four ministers (Defence, Home, Foreign Affairs, Finance), the Chief Secretary and the Chief of the Army Staff.`},{id:`T24`,label:`Pattern-Based – Reconstructed`,stem:`<p>Arrange the events in order of time, earliest first.</p>
<ol>
<li>Second amendment of the Constitution</li>
<li>Proclamation of the Constitution</li>
<li>First amendment of the Constitution</li>
<li>First election of the House of Representatives under the Constitution</li>
</ol>
`,options:[`2 – 3 – 4 – 1`,`2 – 4 – 3 – 1`,`3 – 2 – 4 – 1`,`2 – 3 – 1 – 4`],answer:0,explanation:`Ashoj 2072, Magh 2072, Mangsir 2074, Ashad 2077.`},{id:`T25`,label:`Expected – Practice`,stem:`<p>🔄 Under which clause of Article 76 was Balendra Shah appointed Prime Minister on 13 Chaitra 2082?</p>
`,options:[`Clause (1)`,`Clause (2)`,`Clause (3)`,`Clause (5)`],answer:0,explanation:`Clause (1): leader of a parliamentary party with a majority in the House of Representatives.`}]}]},{num:4,title:`Federalism and Governance`,nep:`संघीयता र शासन प्रणाली`,slug:`part-08-chapter-04-federalism-and-governance`,topics:[{id:`4.1`,title:`Three tiers of government and Schedules 5 to 9 (तीन तहको सरकार र अनुसूची ५ देखि ९)`,questions:[{id:`Q 4.1.1`,label:`Expected – Practice`,stem:`<p>Which Article of the Constitution says that the State has three levels — Federation, Province and Local level?</p>
`,options:[`Article 50`,`Article 56`,`Article 74`,`Article 232`],answer:1,explanation:`Article 56 (1), in Part 5, sets out the three-level structure. Article 232 deals with relations among the levels.`},{id:`Q 4.1.2`,label:`Pattern-Based – Reconstructed`,stem:`<p>Match the Schedule with its list.</p>
<ol>
<li>Schedule 5 — A. Local level powers</li>
<li>Schedule 6 — B. Concurrent powers of the Federation and the Province</li>
<li>Schedule 7 — C. Federal powers</li>
<li>Schedule 8 — D. Provincial powers</li>
</ol>
`,options:[`1-C, 2-D, 3-A, 4-B`,`1-D, 2-C, 3-B, 4-A`,`1-C, 2-B, 3-D, 4-A`,`1-C, 2-D, 3-B, 4-A`],answer:3,explanation:`Schedule 5 is federal, 6 provincial, 7 shared by the Federation and the Province, and 8 local. Schedule 9 is shared by all three.`},{id:`Q 4.1.3`,label:`Expected – Practice`,stem:`<p>A new subject — for example, the regulation of artificial intelligence — is not named in any of the five lists in Schedules 5 to 9. Under the Constitution, which level may make law on it?</p>
`,options:[`The Federation`,`The Province in which the matter arises`,`The Local level`,`The Federation and the Province jointly`],answer:0,explanation:`A subject that no list names is a residual power, and Article 58 gives residual power to the Federation.`},{id:`Q 4.1.4`,label:`Pattern-Based – Reconstructed`,stem:`<p>Consider these statements.</p>
<ol>
<li>The District Assembly is part of the local level.</li>
<li>Schedule 9 has 15 items.</li>
<li>Basic and secondary education is in the federal list.</li>
</ol>
<p>Which of them are correct?</p>
`,options:[`1 only`,`2 and 3 only`,`1 and 2 only`,`1, 2 and 3`],answer:2,explanation:`Statements 1 and 2 are correct (Article 56 (4); Schedule 9). Basic and secondary education is in Schedule 8, the local list.`},{id:`Q 4.1.5`,label:`Pattern-Based – Reconstructed`,stem:`<p>Three of these are in the federal list (Schedule 5). Which one is <strong>not</strong>?</p>
`,options:[`Central bank and monetary policy`,`Management of trusts (गुठी)`,`Civil aviation and international airports`,`Customs and excise duty`],answer:1,explanation:`Management of trusts is item 21 of the provincial list (Schedule 6).`}]},{id:`4.2`,title:`Provincial executive, Provincial Assembly and provincial institutions (प्रदेश कार्यपालिका, प्रदेश सभा र प्रदेशका संस्था)`,questions:[{id:`Q 4.2.1`,label:`Expected – Practice`,stem:`<p>Who appoints the Province Chief?</p>
`,options:[`The Prime Minister`,`The Chief Minister`,`The President`,`The Provincial Assembly`],answer:2,explanation:`Article 163 (2): the President appoints one Province Chief for each province.`},{id:`Q 4.2.2`,label:`Expected – Practice`,stem:`<p>What is the largest size allowed for a Provincial Council of Ministers?</p>
`,options:[`Twenty percent of the total members of the Provincial Assembly, including the Chief Minister`,`Twenty-five members, including the Chief Minister`,`Ten percent of the total members of the Provincial Assembly`,`Fifteen percent of the members, not counting the Chief Minister`],answer:0,explanation:`Article 168 (9). The limit of 25 applies to the federal Council of Ministers.`},{id:`Q 4.2.3`,label:`Pattern-Based – Reconstructed`,stem:`<p>Consider these statements.</p>
<ol>
<li>A Provincial Assembly has one house.</li>
<li>A member of a Provincial Assembly must be at least 25 years old.</li>
<li>A Province Chief must be at least 35 years old.</li>
</ol>
<p>Which of them are correct?</p>
`,options:[`1 and 2 only`,`2 and 3 only`,`1 and 3 only`,`1, 2 and 3`],answer:3,explanation:`All three are correct (Articles 175, 178 and 164).`},{id:`Q 4.2.4`,label:`Pattern-Based – Reconstructed`,stem:`<p>Fill in the blank. A Chief Minister appointed under Article 168 (2) must obtain a vote of confidence from the Provincial Assembly within ______ days of appointment.</p>
`,options:[`15`,`30`,`35`,`60`],answer:1,explanation:`Article 168 (4) gives 30 days. Thirty-five days is the limit for the whole process of appointing a Chief Minister.`},{id:`Q 4.2.5`,label:`Pattern-Based – Reconstructed`,stem:`<p>Match the office with its role.</p>
<ol>
<li>Province Chief — A. Chief legal adviser of the Provincial Government</li>
<li>Chief Minister — B. Representative of the Government of Nepal in the province</li>
<li>Chief Attorney — C. Head of the Provincial Council of Ministers</li>
<li>Speaker — D. Presides over the Provincial Assembly</li>
</ol>
`,options:[`1-B, 2-C, 3-A, 4-D`,`1-C, 2-B, 3-A, 4-D`,`1-B, 2-C, 3-D, 4-A`,`1-A, 2-C, 3-B, 4-D`],answer:0,explanation:`Articles 163, 168, 160 and 182.`}]},{id:`4.3`,title:`Local government: structure, powers and the Local Government Operation Act (स्थानीय सरकार: संरचना, अधिकार र स्थानीय सरकार सञ्चालन ऐन, २०७४)`,questions:[{id:`Q 4.3.1`,label:`Expected – Practice`,stem:`<p>Who coordinates the Judicial Committee of a municipality?</p>
`,options:[`The Mayor`,`The Chief Administrative Officer`,`The senior-most ward chairperson`,`The Deputy Mayor`],answer:3,explanation:`Article 217: the Deputy Mayor in a municipality and the Vice-Chairperson in a rural municipality.`},{id:`Q 4.3.2`,label:`Expected – Practice`,stem:`<p>What is the largest number of members a District Coordination Committee may have?</p>
`,options:[`7`,`9`,`11`,`15`],answer:1,explanation:`Article 220 (3): at most nine, including the Chief and the Deputy Chief.`},{id:`Q 4.3.3`,label:`Pattern-Based – Reconstructed`,stem:`<p>Which of these statements is <strong>not</strong> correct?</p>
`,options:[`A Ward Committee has a chairperson and four members.`,`The term of a Village Assembly and a Municipal Assembly is five years.`,`A Municipal Executive includes four women members elected by the Municipal Assembly.`,`A candidate for a local post must be at least 21 years old.`],answer:2,explanation:`A Municipal Executive includes <strong>five</strong> women members (Article 216). Four is the number for a Village Executive.`},{id:`Q 4.3.4`,label:`Pattern-Based – Reconstructed`,stem:`<p>Arrange the types of local level from the most numerous to the least numerous.</p>
<ol>
<li>Metropolitan cities</li>
<li>Rural municipalities</li>
<li>Sub-metropolitan cities</li>
<li>Municipalities</li>
</ol>
`,options:[`2 – 4 – 3 – 1`,`4 – 2 – 3 – 1`,`2 – 4 – 1 – 3`,`2 – 3 – 4 – 1`],answer:0,explanation:`Rural municipalities 460, municipalities 276, sub-metropolitan cities 11, metropolitan cities 6.`},{id:`Q 4.3.5`,label:`Expected – Practice`,stem:`<p>Under the Local Government Operation Act, 2074, how many permanent residents must a town have, at the least, to become a sub-metropolitan city?</p>
`,options:[`100,000`,`150,000`,`200,000`,`500,000`],answer:2,explanation:`Two hundred thousand (2 lakh). Five hundred thousand is the figure for a metropolitan city.`}]},{id:`4.4`,title:`Inter-governmental relations and fiscal federalism (अन्तर-सरकारी सम्बन्ध र वित्तीय संघीयता)`,questions:[{id:`Q 4.4.1`,label:`Expected – Practice`,stem:`<p>Who chairs the Inter-Province Council under Article 234?</p>
`,options:[`The Prime Minister`,`The President`,`The Home Minister`,`The Chairperson of the National Assembly`],answer:0,explanation:`The Prime Minister chairs it; the Home Minister, the Finance Minister and the Chief Ministers concerned are members.`},{id:`Q 4.4.2`,label:`Pattern-Based – Reconstructed`,stem:`<p>Fill in the blank. Value-added tax and excise on domestic products are shared among the Federation, the provinces and the local levels in the ratio ______.</p>
`,options:[`50 : 25 : 25`,`60 : 20 : 20`,`70 : 15 : 15`,`80 : 10 : 10`],answer:2,explanation:`70 : 15 : 15 under the Inter-Governmental Fiscal Arrangement Act, 2074. The ratio 50 : 25 : 25 is for royalty from natural resources.`},{id:`Q 4.4.3`,label:`Pattern-Based – Reconstructed`,stem:`<p>Match the grant with its description.</p>
<ol>
<li>Fiscal equalisation grant — A. Matching money for infrastructure projects</li>
<li>Conditional grant — B. Based on the need for spending and the capacity to raise revenue</li>
<li>Complementary grant — C. Tied to a named programme or standard</li>
<li>Special grant — D. For a specific purpose such as basic services or the uplift of disadvantaged groups</li>
</ol>
`,options:[`1-A, 2-C, 3-B, 4-D`,`1-B, 2-C, 3-A, 4-D`,`1-B, 2-A, 3-C, 4-D`,`1-D, 2-C, 3-A, 4-B`],answer:1,explanation:`Equalisation follows need and capacity; conditional is tied; complementary is matching money; special is for a specific purpose.`},{id:`Q 4.4.4`,label:`Expected – Practice`,stem:`<p>Which body recommends the fiscal equalisation grants to be given to the provinces and local levels?</p>
`,options:[`The National Planning Commission`,`Nepal Rastra Bank`,`The Auditor General`,`The National Natural Resources and Fiscal Commission`],answer:3,explanation:`Articles 60 (3) and 251 (1)(b).`},{id:`Q 4.4.5`,label:`Pattern-Based – Reconstructed`,stem:`<p>Consider these statements.</p>
<ol>
<li>Only the Government of Nepal may take foreign loans.</li>
<li>Royalty from natural resources is shared 50 : 25 : 25.</li>
<li>Local levels present their budget by 10 Ashad.</li>
</ol>
<p>Which of them are correct?</p>
`,options:[`1 only`,`1 and 2 only`,`2 and 3 only`,`1, 2 and 3`],answer:3,explanation:`All three are correct (Article 59 (6) and the Inter-Governmental Fiscal Arrangement Act, 2074).`}]},{id:`4.5`,title:`Elections and the political system (निर्वाचन र राजनीतिक प्रणाली)`,questions:[{id:`Q 4.5.1`,label:`Expected – Practice`,stem:`<p>How is the Election Commission of Nepal composed?</p>
`,options:[`A Chief Election Commissioner and two Commissioners`,`A Chief Election Commissioner and four Commissioners`,`A Chief Election Commissioner and five Commissioners`,`A Chief Election Commissioner and six Commissioners`],answer:1,explanation:`Article 245 (1): five members in all.`},{id:`Q 4.5.2`,label:`Expected – Practice`,stem:`<p>What share of the valid proportional votes must a party win to receive proportional seats in the House of Representatives?</p>
`,options:[`3 percent`,`1.5 percent`,`5 percent`,`10 percent`],answer:0,explanation:`Three percent. The figure of 1.5 percent applies to Provincial Assemblies.`},{id:`Q 4.5.3`,label:`Pattern-Based – Reconstructed`,stem:`<p>Arrange these elections in order of time, earliest first.</p>
<ol>
<li>First phase of the first local elections under the present Constitution</li>
<li>Election to the House of Representatives after the Gen Z movement</li>
<li>Second local elections under the present Constitution</li>
<li>First elections to the Provincial Assemblies</li>
</ol>
`,options:[`1 – 3 – 4 – 2`,`4 – 1 – 3 – 2`,`1 – 4 – 2 – 3`,`1 – 4 – 3 – 2`],answer:3,explanation:`Baisakh 2074, Mangsir 2074, Baisakh 2079, Falgun 2082.`},{id:`Q 4.5.4`,label:`Pattern-Based – Reconstructed`,stem:`<p>Consider these statements.</p>
<ol>
<li>Local elections use only the first-past-the-post system.</li>
<li>A national party needs 3 percent of the proportional votes and at least one first-past-the-post seat in the House of Representatives.</li>
<li>All members of a Provincial Assembly are elected by proportional representation.</li>
</ol>
<p>Which of them are correct?</p>
`,options:[`1 only`,`2 only`,`1 and 2 only`,`1, 2 and 3`],answer:2,explanation:`Statement 3 is wrong: 60 percent of a Provincial Assembly is elected by first-past-the-post and 40 percent by proportional representation.`},{id:`Q 4.5.5`,label:`Pattern-Based – Reconstructed`,stem:`<p>Three of these elections are conducted by the Election Commission. Which one is <strong>not</strong>?</p>
`,options:[`Election of the Speaker of the House of Representatives`,`Election of the President`,`Election of members of a Provincial Assembly`,`Election of a ward chairperson`],answer:0,explanation:`The House elects its own Speaker. Article 246 gives the Commission the elections of the President, Vice-President, Parliament, Provincial Assemblies and local levels.`}]},{id:`4.6`,title:`Civil service and the Public Service Commissions (निजामती सेवा र लोक सेवा आयोग)`,questions:[{id:`Q 4.6.1`,label:`Expected – Practice`,stem:`<p>Which Article of the Constitution provides for a Province Public Service Commission?</p>
`,options:[`Article 242`,`Article 243`,`Article 244`,`Article 285`],answer:2,explanation:`Article 244. Articles 242 and 243 deal with the federal Commission; Article 285 with forming government services.`},{id:`Q 4.6.2`,label:`Expected – Practice`,stem:`<p>Of the posts set aside for inclusion in the civil service, what share goes to women?</p>
`,options:[`22 percent`,`27 percent`,`45 percent`,`33 percent`],answer:3,explanation:`Thirty-three percent of the reserved share. Forty-five percent is the reserved share itself.`},{id:`Q 4.6.3`,label:`Pattern-Based – Reconstructed`,stem:`<p>Match the head of administrative staff with the level.</p>
<ol>
<li>Chief Secretary — A. Local level</li>
<li>Principal Secretary — B. Federation</li>
<li>Chief Administrative Officer — C. Province</li>
</ol>
`,options:[`1-A, 2-B, 3-C`,`1-B, 2-C, 3-A`,`1-C, 2-B, 3-A`,`1-B, 2-A, 3-C`],answer:1,explanation:`Chief Secretary: Federation; Principal Secretary: province; Chief Administrative Officer: local level.`},{id:`Q 4.6.4`,label:`Pattern-Based – Reconstructed`,stem:`<p>Consider these statements about the federal Public Service Commission.</p>
<ol>
<li>It has a Chairperson and four members.</li>
<li>The term of office is six years.</li>
<li>It conducts the written examination for appointment to the Nepal Police.</li>
</ol>
<p>Which of them are correct?</p>
`,options:[`1, 2 and 3`,`1 and 2 only`,`2 and 3 only`,`1 only`],answer:0,explanation:`All three are correct (Articles 242 and 243).`},{id:`Q 4.6.5`,label:`Pattern-Based – Reconstructed`,stem:`<p>Assertion (A): Every province of Nepal has its own Public Service Commission.
Reason (R): Article 244 provides for a Province Public Service Commission in each province, on standards fixed by federal law.</p>
`,options:[`Both A and R are true, but R does not explain A.`,`Both A and R are true, and R explains A.`,`A is true, but R is false.`,`A is false, but R is true.`],answer:1,explanation:`The seven Commissions exist because Article 244 requires one in each province.`}]},{id:`4.7`,title:`Good governance, right to information and control of corruption (सुशासन, सूचनाको हक र भ्रष्टाचार नियन्त्रण)`,questions:[{id:`Q 4.7.1`,label:`Expected – Practice`,stem:`<p>Which Article of the Constitution guarantees the right to information?</p>
`,options:[`Article 17`,`Article 19`,`Article 25`,`Article 27`],answer:3,explanation:`Article 27. Article 17 is the right to freedom, Article 19 the right to communication and Article 25 the right to property.`},{id:`Q 4.7.2`,label:`Expected – Practice`,stem:`<p>Under the Right to Information Act, 2064, if information cannot be given at once, within how many days must it be given?</p>
`,options:[`3 days`,`7 days`,`15 days`,`35 days`],answer:2,explanation:`Fifteen days. Seven days is for the complaint to the head of the office, and 35 days for the appeal to the Commission.`},{id:`Q 4.7.3`,label:`Pattern-Based – Reconstructed`,stem:`<p>Match the body with its work.</p>
<ol>
<li>Commission for the Investigation of Abuse of Authority — A. Tries corruption cases</li>
<li>Special Court — B. Preventive body under the Prime Minister's supervision</li>
<li>National Vigilance Centre — C. Investigates corruption and files cases</li>
<li>National Information Commission — D. Hears appeals when information is refused</li>
</ol>
`,options:[`1-C, 2-A, 3-B, 4-D`,`1-A, 2-C, 3-B, 4-D`,`1-C, 2-B, 3-A, 4-D`,`1-B, 2-A, 3-C, 4-D`],answer:0,explanation:`The Commission investigates, the Special Court tries, the Vigilance Centre prevents and the Information Commission hears appeals.`},{id:`Q 4.7.4`,label:`Pattern-Based – Reconstructed`,stem:`<p>Consider these statements.</p>
<ol>
<li>The Good Governance (Management and Operation) Act, 2064 requires offices serving the public to display a citizen charter.</li>
<li>The National Information Commission has a Chief Information Commissioner and four Commissioners.</li>
<li>Nepal scored 34 in the Corruption Perceptions Index 2025.</li>
</ol>
<p>Which of them are correct?</p>
`,options:[`1 only`,`1 and 3 only`,`2 and 3 only`,`1, 2 and 3`],answer:1,explanation:`Statement 2 is wrong: the Commission has a Chief Information Commissioner and two Commissioners.`},{id:`Q 4.7.5`,label:`Pattern-Based – Reconstructed`,stem:`<p>Three of these are accepted signs of good governance. Which one is <strong>not</strong>?</p>
`,options:[`Transparency`,`Accountability`,`Secrecy in all decisions`,`Rule of law`],answer:2,explanation:`Good governance calls for openness. Only information that the law protects may be kept secret.`}]},{id:`4.8`,title:`Electronic governance and public service delivery (विद्युतीय सुशासन र सार्वजनिक सेवा प्रवाह)`,questions:[{id:`Q 4.8.1`,label:`Expected – Practice`,stem:`<p>Which law gives legal recognition to electronic records and digital signatures in Nepal?</p>
`,options:[`Electronic Transactions Act, 2063`,`Right to Information Act, 2064`,`Good Governance (Management and Operation) Act, 2064`,`Local Government Operation Act, 2074`],answer:0,explanation:`The Electronic Transactions Act, 2063.`},{id:`Q 4.8.2`,label:`Expected – Practice`,stem:`<p>How many sectors and initiatives does the Digital Nepal Framework, 2076 contain?</p>
`,options:[`5 sectors and 50 initiatives`,`8 sectors and 80 initiatives`,`10 sectors and 100 initiatives`,`7 sectors and 77 initiatives`],answer:1,explanation:`Eight sectors and eighty initiatives.`},{id:`Q 4.8.3`,label:`Pattern-Based – Reconstructed`,stem:`<p>Match the kind of e-governance link with the example.</p>
<ol>
<li>G2C — A. One ministry shares its records with another</li>
<li>G2B — B. A citizen applies for a driving licence online</li>
<li>G2G — C. A firm submits a bid through the electronic procurement portal</li>
<li>G2E — D. An employee checks a pay record online</li>
</ol>
`,options:[`1-B, 2-A, 3-C, 4-D`,`1-C, 2-B, 3-A, 4-D`,`1-B, 2-C, 3-D, 4-A`,`1-B, 2-C, 3-A, 4-D`],answer:3,explanation:`Citizen, business, government and employee in that order.`},{id:`Q 4.8.4`,label:`Pattern-Based – Reconstructed`,stem:`<p>Consider these statements.</p>
<ol>
<li>Distribution of the National Identity Card began in Panchthar district.</li>
<li>The toll-free number of Hello Sarkar is 1111.</li>
<li>The Nagarik App was launched before the Electronic Transactions Act was made.</li>
</ol>
<p>Which of them are correct?</p>
`,options:[`1 only`,`2 only`,`1 and 2 only`,`1, 2 and 3`],answer:2,explanation:`Statement 3 is wrong: the Act is of 2063 BS and the App was launched in 2077 BS.`},{id:`Q 4.8.5`,label:`Pattern-Based – Reconstructed`,stem:`<p>Three of these are expected benefits of e-governance. Which one is <strong>not</strong>?</p>
`,options:[`Faster service`,`More transparency`,`Lower cost of service`,`More dealings through middlemen`],answer:3,explanation:`E-governance is meant to remove middlemen, not add them.`}]},{id:`T`,title:`End-of-chapter test — Top 25`,questions:[{id:`T1`,label:`Expected – Practice`,stem:`<p>Which Part of the Constitution deals with the structure of the State and the distribution of State power?</p>
`,options:[`Part 3`,`Part 4`,`Part 5`,`Part 20`],answer:2,explanation:`Part 5, Articles 56 to 60. Part 20 deals with relations among the three levels.`},{id:`T2`,label:`Expected – Practice`,stem:`<p>How many items are there in the provincial list (Schedule 6)?</p>
`,options:[`21`,`35`,`25`,`22`],answer:0,explanation:`Twenty-one. The other figures belong to Schedules 5, 7 and 8.`},{id:`T3`,label:`Pattern-Based – Reconstructed`,stem:`<p>Match the subject with the Schedule in which it appears.</p>
<ol>
<li>Town police — A. Schedule 5</li>
<li>Provincial highways — B. Schedule 6</li>
<li>Casino and lottery — C. Schedule 7</li>
<li>Foreign and diplomatic affairs — D. Schedule 8</li>
</ol>
`,options:[`1-D, 2-C, 3-B, 4-A`,`1-B, 2-D, 3-C, 4-A`,`1-D, 2-B, 3-A, 4-C`,`1-D, 2-B, 3-C, 4-A`],answer:3,explanation:`Town police is local, provincial highways provincial, casino and lottery shared by the Federation and the Province, and foreign affairs federal.`},{id:`T4`,label:`Expected – Practice`,stem:`<p>How many governments are there in Nepal when all three levels are counted?</p>
`,options:[`753`,`761`,`760`,`77`],answer:1,explanation:`One federal, seven provincial and 753 local governments.`},{id:`T5`,label:`Pattern-Based – Reconstructed`,stem:`<p>Consider these statements about the Province Chief.</p>
<ol>
<li>The term of office is five years.</li>
<li>A person cannot be Province Chief twice in the same province.</li>
<li>The Province Chief is elected by the Provincial Assembly.</li>
</ol>
<p>Which of them are correct?</p>
`,options:[`1 only`,`2 and 3 only`,`1 and 2 only`,`1, 2 and 3`],answer:2,explanation:`The Province Chief is appointed by the President, not elected (Article 163).`},{id:`T6`,label:`Expected – Practice`,stem:`<p>Within how many days must the Province Chief give assent to a Bill passed by the Provincial Assembly?</p>
`,options:[`15 days`,`30 days`,`35 days`,`60 days`],answer:0,explanation:`Article 201 (2): fifteen days.`},{id:`T7`,label:`Expected – Practice`,stem:`<p>Who appoints the Chief Attorney of a province?</p>
`,options:[`The President, on the recommendation of the Attorney General`,`The Province Chief, on the recommendation of the Chief Minister`,`The Attorney General`,`The Judicial Council`],answer:1,explanation:`Article 160 (2).`},{id:`T8`,label:`Pattern-Based – Reconstructed`,stem:`<p>Fill in the blank. The number of first-past-the-post seats in a Provincial Assembly is ______ the number of House of Representatives constituencies in that province.</p>
`,options:[`equal to`,`one and a half times`,`three times`,`twice`],answer:3,explanation:`Article 176 (1)(a). Koshi, for example, has 28 House constituencies and 56 such seats.`},{id:`T9`,label:`Expected – Practice`,stem:`<p>Which members does the Village Assembly add to a Village Executive?</p>
`,options:[`Five women and three members from Dalit or minority communities`,`Three women and two members from Dalit or minority communities`,`Four women and two members from Dalit or minority communities`,`Two women and one member from Dalit or minority communities`],answer:2,explanation:`Article 215 (4). Five and three is the rule for a Municipal Executive.`},{id:`T10`,label:`Expected – Practice`,stem:`<p>In which year BS was the Local Government Operation Act made?</p>
`,options:[`2074`,`2055`,`2072`,`2077`],answer:0,explanation:`It was authenticated on 29 Ashoj 2074.`},{id:`T11`,label:`Expected – Practice`,stem:`<p>Who are the members of a District Assembly?</p>
`,options:[`All ward chairpersons of the district`,`Members of the Provincial Assembly elected from the district`,`The Chief District Officer and the heads of government offices`,`The Chairpersons and Vice-Chairpersons of the rural municipalities and the Mayors and Deputy Mayors of the municipalities in the district`],answer:3,explanation:`Article 220 (2).`},{id:`T12`,label:`Pattern-Based – Reconstructed`,stem:`<p>Consider these statements about Article 232.</p>
<ol>
<li>Relations among the three levels rest on cooperation, coexistence and coordination.</li>
<li>In certain grave situations the President may suspend or dissolve a Provincial Council of Ministers and Provincial Assembly for up to six months.</li>
<li>Such a suspension or dissolution needs no approval from the Federal Parliament.</li>
</ol>
<p>Which of them are correct?</p>
`,options:[`1 only`,`1 and 2 only`,`2 and 3 only`,`1, 2 and 3`],answer:1,explanation:`The action must be ratified by the Federal Parliament within 35 days; otherwise it lapses.`},{id:`T13`,label:`Expected – Practice`,stem:`<p>In what ratio is royalty from natural resources shared among the Federation, the province concerned and the local level concerned?</p>
`,options:[`70 : 15 : 15`,`60 : 20 : 20`,`50 : 25 : 25`,`40 : 30 : 30`],answer:2,explanation:`50 : 25 : 25.`},{id:`T14`,label:`Expected – Practice`,stem:`<p>What is the largest number of members, including the Chairperson, of the National Natural Resources and Fiscal Commission?</p>
`,options:[`5`,`3`,`7`,`9`],answer:0,explanation:`Article 250 (1).`},{id:`T15`,label:`Pattern-Based – Reconstructed`,stem:`<p>Match the level of government with the day by which its yearly budget is presented.</p>
<ol>
<li>Federation — A. 10 Ashad</li>
<li>Province — B. 15 Jestha</li>
<li>Local level — C. 1 Ashad</li>
</ol>
`,options:[`1-A, 2-B, 3-C`,`1-B, 2-C, 3-A`,`1-C, 2-B, 3-A`,`1-B, 2-A, 3-C`],answer:1,explanation:`Federation 15 Jestha, province 1 Ashad, local level 10 Ashad.`},{id:`T16`,label:`Expected – Practice`,stem:`<p>In what ratio is vehicle tax shared between a province and its local levels?</p>
`,options:[`50 : 50`,`40 : 60`,`70 : 30`,`60 : 40`],answer:3,explanation:`The province collects it and keeps 60 percent; 40 percent goes to the local levels.`},{id:`T17`,label:`Expected – Practice`,stem:`<p>On which date AD was the election to the House of Representatives of 21 Falgun 2082 held?</p>
`,options:[`20 November 2022`,`13 May 2022`,`5 March 2026`,`27 March 2026`],answer:2,explanation:`5 March 2026. The other dates are the elections of 2079 and the swearing-in of the Prime Minister.`},{id:`T18`,label:`Expected – Practice`,stem:`<p>How many parties gained the status of national party from the House of Representatives election of 2082 BS?</p>
`,options:[`6`,`5`,`7`,`4`],answer:0,explanation:`Six. There were five after 2074 and seven after 2079.`},{id:`T19`,label:`Expected – Practice`,stem:`<p>Within what period after the end of the term of the local Assemblies must the next local election be held?</p>
`,options:[`One month`,`Three months`,`One year`,`Six months`],answer:3,explanation:`Article 225.`},{id:`T20`,label:`Expected – Practice`,stem:`<p>When was the Public Service Commission of Nepal founded?</p>
`,options:[`2004 BS`,`1 Ashad 2008 BS`,`22 Bhadra 2013 BS`,`2049 BS`],answer:1,explanation:`1 Ashad 2008 (15 June 1951).`},{id:`T21`,label:`Pattern-Based – Reconstructed`,stem:`<p>Arrange these groups by their share of the reserved posts in the civil service, largest first.</p>
<ol>
<li>Dalit</li>
<li>Women</li>
<li>Madhesi</li>
<li>Adivasi Janajati</li>
</ol>
`,options:[`2 – 3 – 4 – 1`,`4 – 2 – 3 – 1`,`2 – 4 – 3 – 1`,`2 – 4 – 1 – 3`],answer:2,explanation:`Women 33, Adivasi Janajati 27, Madhesi 22, Dalit 9.`},{id:`T22`,label:`Expected – Practice`,stem:`<p>Which Article requires a federal Act for forming and running the federal civil service?</p>
`,options:[`Article 285`,`Article 244`,`Article 302`,`Article 232`],answer:0,explanation:`Article 285 (1).`},{id:`T23`,label:`Expected – Practice`,stem:`<p>Who chairs the committee that recommends the Chief Information Commissioner?</p>
`,options:[`The Prime Minister`,`The Speaker of the House of Representatives`,`The Chief Justice`,`The Minister for Communication`],answer:1,explanation:`The Speaker chairs it; the Minister and the head of the Federation of Nepali Journalists are members.`},{id:`T24`,label:`Pattern-Based – Reconstructed`,stem:`<p>Assertion (A): A citizen charter supports good governance.
Reason (R): It tells the service-seeker the service, the time, the fee and the responsible officer, so that the office can be held to account.</p>
`,options:[`A is true, but R is false.`,`A is false, but R is true.`,`Both A and R are true, but R does not explain A.`,`Both A and R are true, and R explains A.`],answer:3,explanation:`The charter makes the standard public, which is the basis of accountability.`},{id:`T25`,label:`Expected – Practice`,stem:`<p>The &quot;Koshi Declaration, 2083&quot; was issued by which gathering?</p>
`,options:[`A meeting of the seven Province Chiefs`,`The federal Council of Ministers`,`The Inter-Province Chief Ministers' Conference at Biratnagar`,`The Election Commission`],answer:2,explanation:`It was issued in Ashoj 2083 and dealt with fiscal federalism, the Federal Civil Service Bill and provincial police. 🔄`}]}]},{num:5,title:`Economy and Public Finance`,nep:`अर्थतन्त्र र सार्वजनिक वित्त`,slug:`part-09-chapter-05-economy-and-public-finance`,topics:[{id:`5.1`,title:`Main economic indicators (मुख्य आर्थिक सूचक)`,questions:[{id:`Q 5.1.1`,label:`Expected – Practice`,stem:`<p>According to the Economic Survey 2082/83, what economic growth rate was estimated for fiscal year 2082/83?</p>
`,options:[`3.85 percent`,`4.43 percent`,`6.00 percent`,`7.00 percent`],answer:0,explanation:`3.85 percent is the preliminary estimate. 4.43 percent is the revised figure for 2081/82; 6 percent was the aim of the budget for 2082/83 and 7 percent is the aim for 2083/84. 🔄`},{id:`Q 5.1.2`,label:`Pattern-Based – Reconstructed`,stem:`<p>Match the term with its meaning.</p>
<ol>
<li>Gross Domestic Product — A. GDP plus net income received from abroad</li>
<li>Gross National Income — B. A general and continuing rise in prices</li>
<li>Inflation — C. Value of the final goods and services produced inside the country in a year</li>
<li>Per capita income — D. National income divided by the population</li>
</ol>
`,options:[`1-A, 2-C, 3-B, 4-D`,`1-C, 2-D, 3-B, 4-A`,`1-C, 2-A, 3-B, 4-D`,`1-D, 2-A, 3-C, 4-B`],answer:2,explanation:`GDP is production inside the country; GNI adds net income from abroad; inflation is a rise in prices; per capita means per person.`},{id:`Q 5.1.3`,label:`Pattern-Based – Reconstructed`,stem:`<p>Consider these statements about the make-up of Nepal's GDP in 2082/83.</p>
<ol>
<li>Services give the largest share of GDP.</li>
<li>Agriculture, forestry and fishing give about 24 percent.</li>
<li>Industry gives more than half of GDP.</li>
</ol>
<p>Which of them are correct?</p>
`,options:[`1 only`,`1 and 2 only`,`2 and 3 only`,`1, 2 and 3`],answer:1,explanation:`Services give about 62 percent and agriculture about 24 percent. Industry gives only about 14 percent. 🔄`},{id:`Q 5.1.4`,label:`Expected – Practice`,stem:`<p>Which body prepares Nepal's national accounts, including the estimate of GDP?</p>
`,options:[`Nepal Rastra Bank`,`The National Planning Commission`,`The Ministry of Finance`,`The National Statistics Office`],answer:3,explanation:`The National Statistics Office, formerly the Central Bureau of Statistics. The Ministry of Finance uses its figures in the Economic Survey.`},{id:`Q 5.1.5`,label:`Expected – Practice`,stem:`<p>By the estimates for 2082/83, which province has the lowest GDP per person?</p>
`,options:[`Karnali`,`Sudurpashchim`,`Madhesh`,`Lumbini`],answer:2,explanation:`Madhesh, USD 934. Karnali has the smallest economy in total, but its GDP per person (USD 1,108) is higher than that of Madhesh. 🔄`}]},{id:`5.2`,title:`Agriculture and land (कृषि र भूमि)`,questions:[{id:`Q 5.2.1`,label:`Expected – Practice`,stem:`<p>Under the Land Act, 2021 as it now stands, what is the basic ceiling on land-holding in the Terai and Inner Madhesh?</p>
`,options:[`4 bigha`,`10 bigha`,`17 bigha`,`25 bigha`],answer:1,explanation:`10 bigha. The ceilings are 25 ropani in the Kathmandu Valley and 70 ropani in other hill areas. The original Act of 2021 had allowed 25 bigha.`},{id:`Q 5.2.2`,label:`Pattern-Based – Reconstructed`,stem:`<p>Match the crop with a district commonly named for it.</p>
<ol>
<li>Tea — A. Jumla</li>
<li>Coffee — B. Ilam</li>
<li>Apple — C. Gulmi</li>
<li>Jute — D. Morang</li>
</ol>
`,options:[`1-B, 2-A, 3-C, 4-D`,`1-C, 2-B, 3-A, 4-D`,`1-D, 2-C, 3-A, 4-B`,`1-B, 2-C, 3-A, 4-D`],answer:3,explanation:`Tea–Ilam, coffee–Gulmi, apple–Jumla, jute–Morang.`},{id:`Q 5.2.3`,label:`Pattern-Based – Reconstructed`,stem:`<p>Fill in the blank. In the land measures of the Terai, one bigha equals ______ kattha.</p>
`,options:[`20`,`16`,`12`,`10`],answer:0,explanation:`One bigha is 20 kattha and one kattha is 20 dhur. Sixteen is the number of aana in one ropani.`},{id:`Q 5.2.4`,label:`Expected – Practice`,stem:`<p>According to the National Agricultural Census, 2078, what is the average land operated by a farm family?</p>
`,options:[`0.96 hectare`,`0.68 hectare`,`0.55 hectare`,`0.37 hectare`],answer:2,explanation:`0.55 hectare. It was 0.68 hectare in the census of 2068, so holdings are getting smaller.`},{id:`Q 5.2.5`,label:`Pattern-Based – Reconstructed`,stem:`<p>Consider these statements.</p>
<ol>
<li>In the census of 2078, 57.3 percent of employed people worked in agriculture, forestry and fishing.</li>
<li>Agriculture, forestry and fishing gave about 24 percent of GDP in 2082/83.</li>
<li>The Agriculture Development Strategy covers the years 2015 to 2035.</li>
</ol>
<p>Which of them are correct?</p>
`,options:[`1 only`,`1 and 2 only`,`2 and 3 only`,`1, 2 and 3`],answer:3,explanation:`All three are correct. Together, statements 1 and 2 show how low the output per farm worker is.`}]},{id:`5.3`,title:`Industry, trade and investment (उद्योग, व्यापार र लगानी)`,questions:[{id:`Q 5.3.1`,label:`Expected – Practice`,stem:`<p>Under the Industrial Enterprises Act, 2076, an industry is &quot;large&quot; when its fixed capital is more than:</p>
`,options:[`Rs 2 crore`,`Rs 15 crore`,`Rs 25 crore`,`Rs 50 crore`],answer:3,explanation:`Above Rs 50 crore is large. Rs 15 crore is the upper limit of a small industry.`},{id:`Q 5.3.2`,label:`Pattern-Based – Reconstructed`,stem:`<p>Consider these statements about Nepal's foreign trade in 2082/83.</p>
<ol>
<li>Imports were more than Rs 2,000 billion.</li>
<li>Exports were larger than imports.</li>
<li>Soybean oil was the largest export item.</li>
</ol>
<p>Which of them are correct?</p>
`,options:[`1 only`,`1 and 3 only`,`2 and 3 only`,`1, 2 and 3`],answer:1,explanation:`Imports were Rs 2,096.38 billion and exports only Rs 315.29 billion, so statement 2 is wrong. Soybean oil made up 40.8 percent of exports. 🔄`},{id:`Q 5.3.3`,label:`Expected – Practice`,stem:`<p>Which is the oldest industrial estate (औद्योगिक क्षेत्र) of Nepal?</p>
`,options:[`Balaju`,`Hetauda`,`Patan`,`Dharan`],answer:0,explanation:`Balaju, set up in 2016 BS (1960). Hetauda and Patan followed in 2020 BS.`},{id:`Q 5.3.4`,label:`Pattern-Based – Reconstructed`,stem:`<p>Match the body or law with what it does.</p>
<ol>
<li>Investment Board Nepal — A. Approves foreign investment in smaller projects</li>
<li>Department of Industry — B. Records exports and imports at the border</li>
<li>Department of Customs — C. Handles investment projects of more than Rs 6 billion</li>
<li>Special Economic Zone Act, 2073 — D. Gives export industries a zone with special facilities</li>
</ol>
`,options:[`1-A, 2-C, 3-B, 4-D`,`1-C, 2-B, 3-A, 4-D`,`1-C, 2-A, 3-B, 4-D`,`1-D, 2-A, 3-B, 4-C`],answer:2,explanation:`The Board takes the large projects, the Department of Industry the smaller ones, Customs keeps the trade figures, and the Act of 2073 creates the zones.`},{id:`Q 5.3.5`,label:`Pattern-Based – Reconstructed`,stem:`<p>Three of these are counted in the balance of trade in goods. Which one is <strong>not</strong>?</p>
`,options:[`Export of carpets`,`Remittance sent home by workers abroad`,`Import of diesel`,`Export of cardamom`],answer:1,explanation:`Remittance is a transfer of money, not trade in goods. It enters the balance of payments.`}]},{id:`5.4`,title:`Tourism (पर्यटन)`,questions:[{id:`Q 5.4.1`,label:`Expected – Practice`,stem:`<p>Which country sent the largest number of tourists to Nepal in 2025?</p>
`,options:[`India`,`China`,`The United States`,`The United Kingdom`],answer:0,explanation:`India sent 292,438 of the 1,158,459 tourists, about a quarter. The United States was second and China third. 🔄`},{id:`Q 5.4.2`,label:`Pattern-Based – Reconstructed`,stem:`<p>Fill in the blank. The Government has declared the years ______ as the Nepal Tourism Decade.</p>
`,options:[`2011–2020`,`2020–2029`,`2023–2032`,`2026–2035`],answer:2,explanation:`2023 to 2032, with a target of 3.5 million tourists a year by 2032.`},{id:`Q 5.4.3`,label:`Pattern-Based – Reconstructed`,stem:`<p>Arrange these in order of time, the earliest first.</p>
<ol>
<li>Nepal Tourism Year, with a target of one million tourists</li>
<li>The first Visit Nepal Year</li>
<li>The start of the Nepal Tourism Decade</li>
<li>Visit Nepal 2020, which was postponed</li>
</ol>
`,options:[`1, 2, 4, 3`,`2, 4, 1, 3`,`2, 1, 3, 4`,`2, 1, 4, 3`],answer:3,explanation:`Visit Nepal Year 1998, Nepal Tourism Year 2011, Visit Nepal 2020, and the Decade from 2023.`},{id:`Q 5.4.4`,label:`Expected – Practice`,stem:`<p>Which body, set up in 1998 as a partnership of the Government and the private tourism industry, promotes Nepal as a destination?</p>
`,options:[`Department of Tourism`,`Nepal Tourism Board`,`Nepal Mountaineering Association`,`Civil Aviation Authority of Nepal`],answer:1,explanation:`The Nepal Tourism Board. The Department of Tourism issues expedition permits.`},{id:`Q 5.4.5`,label:`Pattern-Based – Reconstructed`,stem:`<p>Consider these statements.</p>
<ol>
<li>Nepal received 1,158,459 foreign tourists in 2025.</li>
<li>India was the largest source of tourists in 2025.</li>
<li>The Tourism Decade aims at ten million tourists a year by 2032.</li>
</ol>
<p>Which of them are correct?</p>
`,options:[`1 only`,`1 and 2 only`,`2 and 3 only`,`1, 2 and 3`],answer:1,explanation:`The target of the Decade is 3.5 million a year, not ten million. 🔄`}]},{id:`5.5`,title:`Development infrastructure (विकास पूर्वाधार)`,questions:[{id:`Q 5.5.1`,label:`Expected – Practice`,stem:`<p>How many international airports are in operation in Nepal?</p>
`,options:[`One`,`Two`,`Three`,`Four`],answer:2,explanation:`Tribhuvan (Kathmandu), Gautam Buddha (Bhairahawa) and Pokhara. Nijgadh is a proposed airport. 🔄`},{id:`Q 5.5.2`,label:`Pattern-Based – Reconstructed`,stem:`<p>Match the airport with its place.</p>
<ol>
<li>Gautam Buddha International Airport — A. Lukla, Solukhumbu</li>
<li>Tenzing–Hillary Airport — B. Bhairahawa, Rupandehi</li>
<li>Tribhuvan International Airport — C. Kathmandu</li>
<li>Talcha Airport — D. Near Rara Lake, Mugu</li>
</ol>
`,options:[`1-B, 2-A, 3-C, 4-D`,`1-A, 2-B, 3-C, 4-D`,`1-B, 2-D, 3-C, 4-A`,`1-C, 2-A, 3-B, 4-D`],answer:0,explanation:`Gautam Buddha–Bhairahawa, Tenzing–Hillary–Lukla, Tribhuvan–Kathmandu, Talcha–Mugu.`},{id:`Q 5.5.3`,label:`Expected – Practice`,stem:`<p>The Nagdhunga–Sisnekhola tunnel, described as Nepal's first modern road tunnel, was opened in:</p>
`,options:[`Baisakh 2081`,`Kartik 2082`,`Falgun 2082`,`Shrawan 2083`],answer:3,explanation:`It was opened on 11 Shrawan 2083 (27 July 2026). The main tunnel is 2.688 km long. 🔄`},{id:`Q 5.5.4`,label:`Pattern-Based – Reconstructed`,stem:`<p>Consider these statements, based on the Economic Survey 2082/83.</p>
<ol>
<li>The Mid-Hill (Pushpalal) Highway runs through the Terai.</li>
<li>The roads of the three levels together are more than 100,000 km long.</li>
<li>More than half of the federal road network is blacktopped.</li>
</ol>
<p>Which of them are correct?</p>
`,options:[`1 only`,`2 and 3 only`,`1 and 2 only`,`1, 2 and 3`],answer:1,explanation:`The Mid-Hill Highway runs through the hills; the road through the Terai is the Postal Highway. All roads together are 104,906 km, and 55.6 percent of the federal network is blacktopped. 🔄`},{id:`Q 5.5.5`,label:`Pattern-Based – Reconstructed`,stem:`<p>Arrange these in order of time, the earliest first.</p>
<ol>
<li>Royal Nepal Airlines Corporation is founded</li>
<li>The Raxaul–Amlekhganj railway opens</li>
<li>Pokhara International Airport opens</li>
<li>The Manakamana Cable Car opens</li>
</ol>
`,options:[`2, 1, 4, 3`,`1, 2, 4, 3`,`2, 4, 1, 3`,`2, 1, 3, 4`],answer:0,explanation:`Railway 1927, airline 1958, cable car 1998, airport 2023.`}]},{id:`5.6`,title:`Planned development and the periodic plans (योजनाबद्ध विकास र आवधिक योजना)`,questions:[{id:`Q 5.6.1`,label:`Expected – Practice`,stem:`<p>Which period does the Sixteenth Plan cover?</p>
`,options:[`2076/77–2080/81`,`2081/82–2085/86`,`2080/81–2084/85`,`2082/83–2086/87`],answer:1,explanation:`Fiscal years 2081/82 to 2085/86. The period 2076/77–2080/81 belonged to the Fifteenth Plan.`},{id:`Q 5.6.2`,label:`Pattern-Based – Reconstructed`,stem:`<p>Match the plan with its feature.</p>
<ol>
<li>First Plan — A. Poverty alleviation as the single main objective</li>
<li>Ninth Plan — B. Began in 2013 BS</li>
<li>Tenth Plan — C. Carried the long-term vision &quot;Prosperous Nepal, Happy Nepali&quot;</li>
<li>Fifteenth Plan — D. Also served as the Poverty Reduction Strategy Paper</li>
</ol>
`,options:[`1-B, 2-D, 3-A, 4-C`,`1-A, 2-B, 3-D, 4-C`,`1-B, 2-A, 3-C, 4-D`,`1-B, 2-A, 3-D, 4-C`],answer:3,explanation:`First Plan–2013 BS; Ninth–poverty alleviation; Tenth–Poverty Reduction Strategy Paper; Fifteenth–vision 2100.`},{id:`Q 5.6.3`,label:`Expected – Practice`,stem:`<p>Who chairs the National Planning Commission?</p>
`,options:[`The Prime Minister`,`The Finance Minister`,`The Vice-Chairperson of the Commission`,`The Chief Secretary`],answer:0,explanation:`The Prime Minister is the Chairperson. The Vice-Chairperson leads the daily work.`},{id:`Q 5.6.4`,label:`Pattern-Based – Reconstructed`,stem:`<p>Consider these statements about the Sixteenth Plan.</p>
<ol>
<li>It is a three-year plan.</li>
<li>Its vision is &quot;good governance, social justice and prosperity&quot;.</li>
<li>It aims to bring absolute poverty down to 12 percent.</li>
</ol>
<p>Which of them are correct?</p>
`,options:[`1 only`,`1 and 2 only`,`2 and 3 only`,`1, 2 and 3`],answer:2,explanation:`The Sixteenth Plan is a five-year plan (2081/82–2085/86). The other two statements are correct.`},{id:`Q 5.6.5`,label:`Expected – Practice`,stem:`<p>Of the fifteen periodic plans completed before the Sixteenth Plan, how many were three-year plans?</p>
`,options:[`Three`,`Four`,`Five`,`Six`],answer:2,explanation:`Five: the Second, Eleventh, Twelfth, Thirteenth and Fourteenth. The other ten were five-year plans.`}]},{id:`5.7`,title:`Budget system and the current budget (बजेट प्रणाली र चालू बजेट)`,questions:[{id:`Q 5.7.1`,label:`Expected – Practice`,stem:`<p>Under Article 122, the advance spending allowed by a vote on account may not be more than what share of the year's estimated expenditure?</p>
`,options:[`One fourth`,`One third`,`One half`,`Two thirds`],answer:1,explanation:`One third. A vote on account lets the Government spend while the Appropriation Bill is still being discussed.`},{id:`Q 5.7.2`,label:`Pattern-Based – Reconstructed`,stem:`<p>Match the Article with its subject.</p>
<ol>
<li>Article 116 — A. Federal Contingency Fund</li>
<li>Article 119 — B. Federal Consolidated Fund</li>
<li>Article 122 — C. Estimates of revenue and expenditure</li>
<li>Article 124 — D. Votes on account</li>
</ol>
`,options:[`1-B, 2-C, 3-D, 4-A`,`1-C, 2-B, 3-D, 4-A`,`1-B, 2-D, 3-C, 4-A`,`1-A, 2-C, 3-D, 4-B`],answer:0,explanation:`116 Consolidated Fund; 119 estimates (the budget); 122 votes on account; 124 Contingency Fund.`},{id:`Q 5.7.3`,label:`Expected – Practice`,stem:`<p>Who presented Nepal's first budget, on 21 Magh 2008 BS?</p>
`,options:[`Matrika Prasad Koirala`,`B.P. Koirala`,`Surya Prasad Upadhyaya`,`Subarna Shamsher`],answer:3,explanation:`Subarna Shamsher, as Finance Minister. The budget was of about Rs 5.25 crore.`},{id:`Q 5.7.4`,label:`Pattern-Based – Reconstructed`,stem:`<p>Consider these statements about the federal budget for 2083/84.</p>
<ol>
<li>Its total is Rs 2,124.34 billion.</li>
<li>It aims at economic growth of 7 percent.</li>
<li>More money is set aside for capital expenditure than for current expenditure.</li>
</ol>
<p>Which of them are correct?</p>
`,options:[`1 only`,`2 and 3 only`,`1 and 2 only`,`1, 2 and 3`],answer:2,explanation:`Current expenditure takes 59.8 percent and capital expenditure only 20.3 percent, so statement 3 is wrong. 🔄`},{id:`Q 5.7.5`,label:`Pattern-Based – Reconstructed`,stem:`<p>Arrange the stages of the budget cycle in the right order.</p>
<ol>
<li>Ministries prepare their programmes within the ceilings</li>
<li>The Auditor General audits the accounts</li>
<li>Parliament passes the Appropriation Bill</li>
<li>Offices spend the money during the fiscal year</li>
</ol>
`,options:[`1, 3, 4, 2`,`3, 1, 4, 2`,`1, 4, 3, 2`,`1, 3, 2, 4`],answer:0,explanation:`Formulation, approval, implementation, then audit.`}]},{id:`5.8`,title:`Revenue, taxation and public debt (राजस्व, कर र सार्वजनिक ऋण)`,questions:[{id:`Q 5.8.1`,label:`Expected – Practice`,stem:`<p>What is the standard rate of value-added tax in Nepal?</p>
`,options:[`10 percent`,`12 percent`,`13 percent`,`15 percent`],answer:2,explanation:`13 percent. The tax began at 10 percent in 2054 BS, and the budget for 2083/84 left the rate unchanged.`},{id:`Q 5.8.2`,label:`Pattern-Based – Reconstructed`,stem:`<p>Three of these are indirect taxes. Which one is a <strong>direct</strong> tax?</p>
`,options:[`Value-added tax`,`Excise duty`,`Customs duty`,`Income tax`],answer:3,explanation:`Income tax is borne by the person who earns the income. The other three are passed on to the buyer in the price.`},{id:`Q 5.8.3`,label:`Pattern-Based – Reconstructed`,stem:`<p>Match the office with its work.</p>
<ol>
<li>Inland Revenue Department — A. Keeps the accounts of government revenue and spending</li>
<li>Department of Customs — B. Administers income tax, value-added tax and excise</li>
<li>Financial Comptroller General Office — C. Manages government borrowing and its records</li>
<li>Public Debt Management Office — D. Collects duty on goods crossing the border</li>
</ol>
`,options:[`1-D, 2-B, 3-A, 4-C`,`1-B, 2-D, 3-A, 4-C`,`1-B, 2-D, 3-C, 4-A`,`1-A, 2-D, 3-B, 4-C`],answer:1,explanation:`Inland Revenue–internal taxes; Customs–border duty; Comptroller General–accounts; Debt Management Office–borrowing.`},{id:`Q 5.8.4`,label:`Expected – Practice`,stem:`<p>From which date was value-added tax applied in Nepal?</p>
`,options:[`1 Mangsir 2054`,`1 Shrawan 2052`,`1 Baisakh 2058`,`1 Magh 2061`],answer:0,explanation:`1 Mangsir 2054 (16 November 1997), under the Act of 2052. The day is kept as National Tax Day.`},{id:`Q 5.8.5`,label:`Pattern-Based – Reconstructed`,stem:`<p>Consider these statements about Nepal's public debt.</p>
<ol>
<li>It had passed Rs 3,000 billion by mid-October 2026.</li>
<li>External debt is a larger part of it than internal debt.</li>
<li>It is equal to about 45 percent of GDP.</li>
</ol>
<p>Which of them are correct?</p>
`,options:[`1 only`,`1 and 2 only`,`2 and 3 only`,`1, 2 and 3`],answer:3,explanation:`All three are correct: Rs 3,009.11 billion in mid-October 2026; about 54 percent of it external; about 45 percent of GDP. 🔄`}]},{id:`5.9`,title:`Banking, money and Nepal Rastra Bank (बैंकिङ, मुद्रा र नेपाल राष्ट्र बैंक)`,questions:[{id:`Q 5.9.1`,label:`Expected – Practice`,stem:`<p>Under the Banks and Financial Institutions Act, 2073, to which class do development banks belong?</p>
`,options:[`Class A`,`Class B`,`Class C`,`Class D`],answer:1,explanation:`Class B. Commercial banks are Class A, finance companies Class C and microfinance institutions Class D.`},{id:`Q 5.9.2`,label:`Pattern-Based – Reconstructed`,stem:`<p>Match the tool with its rate in the monetary policy for 2083/84.</p>
<ol>
<li>Bank rate — A. 4 percent</li>
<li>Policy rate — B. 2.75 percent</li>
<li>Deposit collection rate — C. 5.75 percent</li>
<li>Cash reserve ratio — D. 4.25 percent</li>
</ol>
`,options:[`1-D, 2-C, 3-B, 4-A`,`1-C, 2-B, 3-D, 4-A`,`1-C, 2-D, 3-B, 4-A`,`1-A, 2-D, 3-B, 4-C`],answer:2,explanation:`Bank rate 5.75, policy rate 4.25, deposit collection rate 2.75 and cash reserve ratio 4 percent. 🔄`},{id:`Q 5.9.3`,label:`Expected – Practice`,stem:`<p>At what fixed rate is the Nepali rupee tied to the Indian rupee?</p>
`,options:[`Rs 1.60 for one Indian rupee`,`Rs 1.45 for one Indian rupee`,`Rs 1.68 for one Indian rupee`,`Rs 2.00 for one Indian rupee`],answer:0,explanation:`Rs 1.60, unchanged since 2049 BS (February 1993).`},{id:`Q 5.9.4`,label:`Pattern-Based – Reconstructed`,stem:`<p>Arrange these by date of founding, the earliest first.</p>
<ol>
<li>Rastriya Banijya Bank</li>
<li>Nepal Rastra Bank</li>
<li>Nepal Bank Limited</li>
<li>Agricultural Development Bank</li>
</ol>
`,options:[`2, 3, 1, 4`,`3, 1, 2, 4`,`3, 2, 4, 1`,`3, 2, 1, 4`],answer:3,explanation:`Nepal Bank 1994 BS, Nepal Rastra Bank 2013, Rastriya Banijya Bank 2022, Agricultural Development Bank 2024.`},{id:`Q 5.9.5`,label:`Pattern-Based – Reconstructed`,stem:`<p>Consider these statements.</p>
<ol>
<li>Nepal Rastra Bank issues the monetary policy.</li>
<li>The Securities Board of Nepal regulates insurance companies.</li>
<li>The monetary policy for 2083/84 is the 25th yearly monetary policy.</li>
</ol>
<p>Which of them are correct?</p>
`,options:[`1 only`,`1 and 2 only`,`1 and 3 only`,`1, 2 and 3`],answer:2,explanation:`Insurance is regulated by the Nepal Insurance Authority; the Securities Board regulates the share market.`}]},{id:`5.10`,title:`Poverty, employment, remittance, graduation and the Sustainable Development Goals (गरिबी, रोजगारी, विप्रेषण, स्तरोन्नति र दिगो विकास लक्ष्य)`,questions:[{id:`Q 5.10.1`,label:`Expected – Practice`,stem:`<p>According to the fourth Nepal Living Standards Survey (2079/80), what share of the people live below the poverty line?</p>
`,options:[`30.85 percent`,`25.16 percent`,`17.4 percent`,`20.27 percent`],answer:3,explanation:`20.27 percent. The figures 30.85 and 25.16 come from the second and third surveys; 17.4 percent is multidimensional poverty.`},{id:`Q 5.10.2`,label:`Pattern-Based – Reconstructed`,stem:`<p>Fill in the blank. The Sustainable Development Goals have 17 goals and ______ targets.</p>
`,options:[`169`,`21`,`100`,`232`],answer:0,explanation:`169 targets, to be reached by 2030.`},{id:`Q 5.10.3`,label:`Expected – Practice`,stem:`<p>By its resolution of 29 October 2026, the United Nations General Assembly moved the date of Nepal's graduation from the least-developed-country category to:</p>
`,options:[`24 November 2027`,`24 November 2028`,`24 November 2029`,`24 November 2031`],answer:2,explanation:`24 November 2029, three years after the earlier date of 24 November 2026. The same resolution covers Bangladesh. 🔄`},{id:`Q 5.10.4`,label:`Pattern-Based – Reconstructed`,stem:`<p>Match the number of the Sustainable Development Goal with its subject.</p>
<ol>
<li>Goal 1 — A. Quality education</li>
<li>Goal 4 — B. Climate action</li>
<li>Goal 5 — C. No poverty</li>
<li>Goal 13 — D. Gender equality</li>
</ol>
`,options:[`1-C, 2-D, 3-A, 4-B`,`1-C, 2-A, 3-D, 4-B`,`1-A, 2-C, 3-D, 4-B`,`1-C, 2-A, 3-B, 4-D`],answer:1,explanation:`Goal 1 no poverty; Goal 4 quality education; Goal 5 gender equality; Goal 13 climate action.`},{id:`Q 5.10.5`,label:`Pattern-Based – Reconstructed`,stem:`<p>Consider these statements about the list of least developed countries.</p>
<ol>
<li>Nepal left the list on 24 November 2026.</li>
<li>Nepal has been on the list since 1971.</li>
<li>Three criteria are used to decide whether a country may graduate.</li>
</ol>
<p>Which of them are correct?</p>
`,options:[`2 and 3 only`,`1 and 2 only`,`1 only`,`1, 2 and 3`],answer:0,explanation:`Nepal has not left the list; in October 2026 its graduation was moved to 24 November 2029. 🔄`}]},{id:`T`,title:`End-of-chapter test — Top 25`,questions:[{id:`T1`,label:`Expected – Practice`,stem:`<p>Which Part of the Constitution contains the federal financial procedures, Articles 115 to 125?</p>
`,options:[`Part 8`,`Part 9`,`Part 10`,`Part 11`],answer:2,explanation:`Part 10. Part 11 is on the judiciary.`},{id:`T2`,label:`Expected – Practice`,stem:`<p>Gross National Income is equal to Gross Domestic Product plus:</p>
`,options:[`net income from abroad`,`indirect taxes`,`government spending`,`the value of imports`],answer:0,explanation:`GNI adds to GDP the income received from abroad minus the income paid abroad.`},{id:`T3`,label:`Pattern-Based – Reconstructed`,stem:`<p>Match the document or figure with the body that issues it.</p>
<ol>
<li>Economic Survey — A. Nepal Rastra Bank</li>
<li>Monetary policy — B. National Planning Commission</li>
<li>Periodic plan — C. Ministry of Finance</li>
<li>Foreign-trade figures — D. Department of Customs</li>
</ol>
`,options:[`1-A, 2-C, 3-B, 4-D`,`1-C, 2-B, 3-A, 4-D`,`1-B, 2-A, 3-C, 4-D`,`1-C, 2-A, 3-B, 4-D`],answer:3,explanation:`Economic Survey–Ministry of Finance; monetary policy–Nepal Rastra Bank; periodic plan–National Planning Commission; trade figures–Department of Customs.`},{id:`T4`,label:`Expected – Practice`,stem:`<p>By the estimates for 2082/83, which province produces the largest share of Nepal's GDP?</p>
`,options:[`Koshi`,`Bagmati`,`Lumbini`,`Madhesh`],answer:1,explanation:`Bagmati, 36.7 percent. Koshi is second with 15.8 percent. 🔄`},{id:`T5`,label:`Pattern-Based – Reconstructed`,stem:`<p>Fill in the blank. A GDP of 66 kharba 9 arba rupees is the same as Rs ______ billion.</p>
`,options:[`66.09`,`660.9`,`6,609`,`66,090`],answer:2,explanation:`One kharba is 100 arba, and one arba is one billion: 66 × 100 + 9 = 6,609.`},{id:`T6`,label:`Expected – Practice`,stem:`<p>The National Agricultural Census of 2078 BS was Nepal's:</p>
`,options:[`seventh`,`sixth`,`fifth`,`eighth`],answer:0,explanation:`The seventh. An agricultural census is taken every ten years.`},{id:`T7`,label:`Pattern-Based – Reconstructed`,stem:`<p>Consider these statements about land.</p>
<ol>
<li>One ropani has 16 aana.</li>
<li>One bigha is smaller than one ropani.</li>
<li>The Land Act, 2021 sets a ceiling of 25 ropani in the Kathmandu Valley.</li>
</ol>
<p>Which of them are correct?</p>
`,options:[`1 only`,`1 and 3 only`,`2 and 3 only`,`1, 2 and 3`],answer:1,explanation:`One bigha is about 13.31 ropani, so statement 2 is wrong.`},{id:`T8`,label:`Expected – Practice`,stem:`<p>On which date did the Government declare the kamaiya (bonded labour) system ended?</p>
`,options:[`21 Bhadra 2065`,`1 Baisakh 2063`,`15 Ashad 2061`,`2 Shrawan 2057`],answer:3,explanation:`2 Shrawan 2057 (17 July 2000). The date 21 Bhadra 2065 belongs to the haliya.`},{id:`T9`,label:`Pattern-Based – Reconstructed`,stem:`<p>A factory has fixed capital of Rs 30 crore. Under the Industrial Enterprises Act, 2076, it is a:</p>
`,options:[`small industry`,`medium industry`,`large industry`,`cottage industry`],answer:1,explanation:`A medium industry has fixed capital of more than Rs 15 crore and up to Rs 50 crore.`},{id:`T10`,label:`Expected – Practice`,stem:`<p>With which country does Nepal carry on the largest share of its foreign trade?</p>
`,options:[`India`,`China`,`The United States`,`The United Arab Emirates`],answer:0,explanation:`India. In 2082/83 Nepal imported about Rs 1,210 billion from India and exported about Rs 258 billion to it — about 61 percent of all trade. 🔄`},{id:`T11`,label:`Expected – Practice`,stem:`<p>In which year did Nepal become the 147th member of the World Trade Organization?</p>
`,options:[`1995`,`2000`,`2004`,`2006`],answer:2,explanation:`23 April 2004 (11 Baisakh 2061).`},{id:`T12`,label:`Pattern-Based – Reconstructed`,stem:`<p>Match the tourism campaign with its target.</p>
<ol>
<li>Visit Nepal Year 1998 — A. 2 million tourists</li>
<li>Nepal Tourism Year 2011 — B. 3.5 million tourists a year</li>
<li>Visit Nepal 2020 — C. 500,000 tourists</li>
<li>Tourism Decade, by 2032 — D. 1 million tourists</li>
</ol>
`,options:[`1-D, 2-C, 3-A, 4-B`,`1-C, 2-A, 3-D, 4-B`,`1-C, 2-D, 3-B, 4-A`,`1-C, 2-D, 3-A, 4-B`],answer:3,explanation:`1998: half a million; 2011: one million; 2020: two million; the Decade: 3.5 million a year.`},{id:`T13`,label:`Pattern-Based – Reconstructed`,stem:`<p>Three of these are international airports in operation. Which one is <strong>not</strong>?</p>
`,options:[`Tribhuvan, Kathmandu`,`Nijgadh, Bara`,`Gautam Buddha, Bhairahawa`,`Pokhara`],answer:1,explanation:`Nijgadh is a proposed airport. 🔄`},{id:`T14`,label:`Expected – Practice`,stem:`<p>How long is the Mid-Hill (Pushpalal) Highway planned to be?</p>
`,options:[`1,879 km`,`1,028 km`,`1,857 km`,`1,200 km`],answer:0,explanation:`1,879 km. The Mahendra Highway is about 1,028 km and the Postal Highway 1,857 km.`},{id:`T15`,label:`Pattern-Based – Reconstructed`,stem:`<p>Arrange these plans in order of time, the earliest first.</p>
<ol>
<li>Eleventh Plan (the Three-Year Interim Plan)</li>
<li>Fifteenth Plan</li>
<li>Eighth Plan</li>
<li>Second Plan</li>
</ol>
`,options:[`3, 4, 1, 2`,`4, 1, 3, 2`,`4, 3, 2, 1`,`4, 3, 1, 2`],answer:3,explanation:`Second (2019 BS), Eighth (2049), Eleventh (2064/65), Fifteenth (2076/77).`},{id:`T16`,label:`Expected – Practice`,stem:`<p>The long-term vision &quot;Prosperous Nepal, Happy Nepali&quot; looks ahead to which year?</p>
`,options:[`2087 BS`,`2090 BS`,`2100 BS`,`2105 BS`],answer:2,explanation:`2100 BS. It was adopted with the Fifteenth Plan.`},{id:`T17`,label:`Expected – Practice`,stem:`<p>What rate of economic growth does the Sixteenth Plan aim at for 2085/86?</p>
`,options:[`6.0 percent`,`7.3 percent`,`8.5 percent`,`10.5 percent`],answer:1,explanation:`7.3 percent. The budget for 2083/84 aims at 7 percent.`},{id:`T18`,label:`Pattern-Based – Reconstructed`,stem:`<p>Consider these statements about expenditure charged on the Federal Consolidated Fund.</p>
<ol>
<li>Article 118 names the pay of the President.</li>
<li>Charged expenditure does not need the approval of the Federal Parliament.</li>
<li>Article 118 names the pay of the Prime Minister.</li>
</ol>
<p>Which of them are correct?</p>
`,options:[`1 and 2 only`,`2 and 3 only`,`1 and 3 only`,`1, 2 and 3`],answer:0,explanation:`Article 118 lists the President and Vice-President, judges, the presiding officers of Parliament, constitutional bodies, Province Chiefs and debt payments. The Prime Minister is not in the list.`},{id:`T19`,label:`Expected – Practice`,stem:`<p>Which province presented the smallest budget for 2083/84?</p>
`,options:[`Karnali`,`Sudurpashchim`,`Lumbini`,`Gandaki`],answer:3,explanation:`Gandaki, about Rs 33.00 billion. Karnali's budget is about Rs 35.40 billion. 🔄`},{id:`T20`,label:`Expected – Practice`,stem:`<p>Under the Finance Act, 2083, what is the highest rate of income tax on an individual?</p>
`,options:[`39 percent`,`36 percent`,`29 percent`,`25 percent`],answer:2,explanation:`29 percent, on income above Rs 40 lakh. It was 39 percent before. 🔄`},{id:`T21`,label:`Pattern-Based – Reconstructed`,stem:`<p>Match the term with its meaning.</p>
<ol>
<li>Progressive tax — A. Short-term borrowing paper of the Government</li>
<li>Treasury bill — B. The rate rises as income rises</li>
<li>Fiscal deficit — C. Government income other than tax, such as fees and dividends</li>
<li>Non-tax revenue — D. Spending greater than revenue and grants</li>
</ol>
`,options:[`1-A, 2-B, 3-D, 4-C`,`1-B, 2-A, 3-D, 4-C`,`1-B, 2-A, 3-C, 4-D`,`1-D, 2-A, 3-B, 4-C`],answer:1,explanation:`Progressive tax–rising rate; treasury bill–short-term paper; fiscal deficit–spending above income; non-tax revenue–fees and dividends.`},{id:`T22`,label:`Expected – Practice`,stem:`<p>Which body regulates the share market in Nepal?</p>
`,options:[`Securities Board of Nepal`,`Nepal Stock Exchange`,`Nepal Rastra Bank`,`Nepal Insurance Authority`],answer:0,explanation:`The Securities Board of Nepal, set up in 2050 BS. The Stock Exchange is the market that it regulates.`},{id:`T23`,label:`Expected – Practice`,stem:`<p>Who was appointed the 18th Governor of Nepal Rastra Bank in Jestha 2082?</p>
`,options:[`Maha Prasad Adhikari`,`Chiranjibi Nepal`,`Yuba Raj Khatiwada`,`Biswo Nath Poudel`],answer:3,explanation:`Dr Biswo Nath Poudel, appointed on 6 Jestha 2082 (20 May 2025). The other three are former Governors. 🔄`},{id:`T24`,label:`Pattern-Based – Reconstructed`,stem:`<p>Consider these statements about fiscal year 2082/83.</p>
<ol>
<li>Remittance was more than Rs 2,300 billion.</li>
<li>The balance of payments was in deficit.</li>
<li>Foreign-exchange reserves stood near Rs 3,900 billion in mid-July 2026.</li>
</ol>
<p>Which of them are correct?</p>
`,options:[`1 only`,`1 and 3 only`,`2 and 3 only`,`1, 2 and 3`],answer:1,explanation:`The balance of payments was in surplus by Rs 1,027.04 billion. Remittance was Rs 2,363.13 billion and reserves Rs 3,897.67 billion. 🔄`},{id:`T25`,label:`Expected – Practice`,stem:`<p>In the Sustainable Development Report 2026, what is Nepal's rank among 167 countries on the SDG Index?</p>
`,options:[`55th`,`71st`,`90th`,`145th`],answer:2,explanation:`90th, with a score of 68.7. Nepal was 85th in 2025. The number 145 is Nepal's rank on the Human Development Index. 🔄`}]}]},{num:6,title:`Society, Culture and Heritage`,nep:`समाज, संस्कृति र सम्पदा`,slug:`part-10-chapter-06-society-culture-heritage`,topics:[{id:`6.1`,title:`Population and the Census of 2078 (जनसङ्ख्या र राष्ट्रिय जनगणना २०७८)`,questions:[{id:`Q 6.1.1`,label:`Pattern-Based – Reconstructed`,stem:`<p>Fill in the blank. According to the Census of 2078, there are ______ men for every 100 women in Nepal.</p>
`,options:[`94.16`,`95.59`,`98.02`,`100.55`],answer:1,explanation:`95.59. The figure 94.16 belongs to the census of 2068.`},{id:`Q 6.1.2`,label:`Pattern-Based – Reconstructed`,stem:`<p>Match the group with its share of the population in the Census of 2078.</p>
<ol>
<li>Children aged 0–14 — A. 10.21 percent</li>
<li>People aged 15–59 — B. 27.83 percent</li>
<li>People aged 60 and above — C. 61.96 percent</li>
<li>Persons with a disability — D. 2.2 percent</li>
</ol>
`,options:[`1-C, 2-B, 3-A, 4-D`,`1-B, 2-A, 3-C, 4-D`,`1-A, 2-C, 3-B, 4-D`,`1-B, 2-C, 3-A, 4-D`],answer:3,explanation:`Children 27.83, working age 61.96, seniors 10.21 and persons with a disability 2.2 percent.`},{id:`Q 6.1.3`,label:`Expected – Practice`,stem:`<p>The Census of 2078 was Nepal's:</p>
`,options:[`twelfth`,`eleventh`,`tenth`,`thirteenth`],answer:0,explanation:`The twelfth. The first count was made in 1968 BS.`},{id:`Q 6.1.4`,label:`Pattern-Based – Reconstructed`,stem:`<p>Consider these statements about the Census of 2078.</p>
<ol>
<li>Women are more than half of the population.</li>
<li>The average household has 4.37 members.</li>
<li>More people live in rural municipalities than in municipalities.</li>
</ol>
<p>Which of them are correct?</p>
`,options:[`1 only`,`2 and 3 only`,`1 and 2 only`,`1, 2 and 3`],answer:2,explanation:`Women are 51.13 percent and the average household has 4.37 members. But 66.17 percent of the people live in municipalities.`},{id:`Q 6.1.5`,label:`Expected – Practice`,stem:`<p>Which district has the largest average household size in the Census of 2078?</p>
`,options:[`Rautahat`,`Kathmandu`,`Dolakha`,`Manang`],answer:0,explanation:`Rautahat, 5.94 persons. Gorkha and Dolakha have the smallest, 3.49.`}]},{id:`6.2`,title:`Caste and ethnic groups (जातजाति)`,questions:[{id:`Q 6.2.1`,label:`Expected – Practice`,stem:`<p>How many castes and ethnic groups does the Census of 2078 list?</p>
`,options:[`125`,`131`,`142`,`159`],answer:2,explanation:`142. The census of 2068 listed 125.`},{id:`Q 6.2.2`,label:`Pattern-Based – Reconstructed`,stem:`<p>Arrange these groups by their share of the population in the Census of 2078, the largest first.</p>
<ol>
<li>Magar</li>
<li>Chhetri</li>
<li>Tharu</li>
<li>Brahman (Hill)</li>
</ol>
`,options:[`2, 4, 1, 3`,`4, 2, 1, 3`,`2, 1, 4, 3`,`2, 4, 3, 1`],answer:0,explanation:`Chhetri 16.45, Brahman (Hill) 11.29, Magar 6.9 and Tharu 6.2 percent.`},{id:`Q 6.2.3`,label:`Expected – Practice`,stem:`<p>How many groups are listed as indigenous nationalities (आदिवासी जनजाति) under the Act of 2058?</p>
`,options:[`26`,`45`,`61`,`59`],answer:3,explanation:`59, sorted into five classes.`},{id:`Q 6.2.4`,label:`Pattern-Based – Reconstructed`,stem:`<p>Match the group with its class among the indigenous nationalities.</p>
<ol>
<li>Raute — A. Advanced</li>
<li>Chepang — B. Endangered</li>
<li>Tharu — C. Highly marginalised</li>
<li>Newar — D. Marginalised</li>
</ol>
`,options:[`1-C, 2-B, 3-D, 4-A`,`1-B, 2-C, 3-D, 4-A`,`1-B, 2-D, 3-C, 4-A`,`1-A, 2-C, 3-D, 4-B`],answer:1,explanation:`Raute endangered, Chepang highly marginalised, Tharu marginalised, Newar advanced.`},{id:`Q 6.2.5`,label:`Pattern-Based – Reconstructed`,stem:`<p>Three of these are in the &quot;endangered&quot; class of indigenous nationalities. Which one is <strong>not</strong>?</p>
`,options:[`Kusunda`,`Raute`,`Bankariya`,`Gurung`],answer:3,explanation:`The Gurung are in the &quot;disadvantaged&quot; class.`}]},{id:`6.3`,title:`Languages and scripts (भाषा र लिपि)`,questions:[{id:`Q 6.3.1`,label:`Pattern-Based – Reconstructed`,stem:`<p>Fill in the blank. The Census of 2078 records ______ mother tongues in Nepal.</p>
`,options:[`124`,`123`,`131`,`142`],answer:0,explanation:`124. The census of 2068 recorded 123; the number 142 is that of castes and ethnic groups.`},{id:`Q 6.3.2`,label:`Pattern-Based – Reconstructed`,stem:`<p>Arrange these mother tongues by number of speakers in the Census of 2078, the largest first.</p>
<ol>
<li>Maithili</li>
<li>Tharu</li>
<li>Nepali</li>
<li>Bhojpuri</li>
</ol>
`,options:[`3, 4, 1, 2`,`1, 3, 4, 2`,`3, 1, 4, 2`,`3, 1, 2, 4`],answer:2,explanation:`Nepali 44.86, Maithili 11.05, Bhojpuri 6.24 and Tharu 5.88 percent.`},{id:`Q 6.3.3`,label:`Expected – Practice`,stem:`<p>Which Article of the Constitution lets a province choose, by provincial law, one or more languages as official languages in addition to Nepali?</p>
`,options:[`Article 6`,`Article 7`,`Article 32`,`Article 287`],answer:1,explanation:`Article 7 (2). Article 6 is on the languages of the nation and Article 287 on the Language Commission.`},{id:`Q 6.3.4`,label:`Pattern-Based – Reconstructed`,stem:`<p>Match the province with the languages that the Language Commission recommended for it.</p>
<ol>
<li>Koshi — A. Tamang and Nepal Bhasa</li>
<li>Bagmati — B. Dotyali and Tharu</li>
<li>Lumbini — C. Maithili and Limbu</li>
<li>Sudurpashchim — D. Tharu and Awadhi</li>
</ol>
`,options:[`1-A, 2-C, 3-D, 4-B`,`1-C, 2-A, 3-B, 4-D`,`1-C, 2-D, 3-A, 4-B`,`1-C, 2-A, 3-D, 4-B`],answer:3,explanation:`Koshi–Maithili and Limbu; Bagmati–Tamang and Nepal Bhasa; Lumbini–Tharu and Awadhi; Sudurpashchim–Dotyali and Tharu.`},{id:`Q 6.3.5`,label:`Expected – Practice`,stem:`<p>In which script is the Limbu language traditionally written?</p>
`,options:[`Ranjana`,`Sirijanga`,`Tirhuta`,`Sambhota`],answer:1,explanation:`Sirijanga. Ranjana is a script of Nepal Bhasa, Tirhuta of Maithili and Sambhota of Tibetan.`}]},{id:`6.4`,title:`Religions and festivals (धर्म र चाडपर्व)`,questions:[{id:`Q 6.4.1`,label:`Expected – Practice`,stem:`<p>According to the Census of 2078, what share of the people of Nepal are Hindu?</p>
`,options:[`86.51 percent`,`84.24 percent`,`79.80 percent`,`81.19 percent`],answer:3,explanation:`81.19 percent. Buddhists are 8.21 percent and Muslims 5.09 percent.`},{id:`Q 6.4.2`,label:`Pattern-Based – Reconstructed`,stem:`<p>Match the festival with the community or place that mainly keeps it.</p>
<ol>
<li>Chhath — A. Gurung</li>
<li>Tamu Lhosar — B. People of the Terai and Mithila</li>
<li>Ubhauli and Udhauli — C. Newar of Kathmandu</li>
<li>Indra Jatra — D. Kirat</li>
</ol>
`,options:[`1-A, 2-B, 3-D, 4-C`,`1-B, 2-A, 3-D, 4-C`,`1-B, 2-D, 3-A, 4-C`,`1-C, 2-A, 3-D, 4-B`],answer:1,explanation:`Chhath–Terai and Mithila; Tamu Lhosar–Gurung; Ubhauli and Udhauli–Kirat; Indra Jatra–Kathmandu.`},{id:`Q 6.4.3`,label:`Expected – Practice`,stem:`<p>On which day do the Tharu celebrate Maghi as their new year?</p>
`,options:[`1 Baisakh`,`15 Poush`,`1 Magh`,`The full moon of Falgun`],answer:2,explanation:`1 Magh, the day of Maghe Sankranti. 15 Poush is Tamu Lhosar.`},{id:`Q 6.4.4`,label:`Pattern-Based – Reconstructed`,stem:`<p>Consider these statements.</p>
<ol>
<li>Dashain lasts fifteen days, from Ghatasthapana to the full moon.</li>
<li>Tihar is a festival of five days.</li>
<li>Chhath is a worship of the Moon.</li>
</ol>
<p>Which of them are correct?</p>
`,options:[`1 and 2 only`,`2 and 3 only`,`1 and 3 only`,`1, 2 and 3`],answer:0,explanation:`Chhath is a worship of the Sun.`},{id:`Q 6.4.5`,label:`Expected – Practice`,stem:`<p>Which king is traditionally credited with starting the Gai Jatra festival?</p>
`,options:[`Jayasthiti Malla`,`Gunakamadeva`,`Pratap Malla`,`Narendradeva`],answer:2,explanation:`Pratap Malla of Kathmandu. Tradition links Gunakamadeva with Indra Jatra and Narendradeva with the Rato Machhindranath Jatra.`}]},{id:`6.5`,title:`Art, architecture, music and dance (कला, वास्तुकला, सङ्गीत र नृत्य)`,questions:[{id:`Q 6.5.1`,label:`Expected – Practice`,stem:`<p>The Krishna Mandir of Patan is the best-known example of which style of architecture?</p>
`,options:[`Pagoda`,`Shikhara`,`Stupa`,`Dome`],answer:1,explanation:`Shikhara. It is built of stone and dates from 1637.`},{id:`Q 6.5.2`,label:`Pattern-Based – Reconstructed`,stem:`<p>Match the dance with its community or region.</p>
<ol>
<li>Dhan Nach — A. Tamang</li>
<li>Tamang Selo — B. Limbu</li>
<li>Sakela — C. Far west</li>
<li>Deuda — D. Rai</li>
</ol>
`,options:[`1-A, 2-B, 3-D, 4-C`,`1-B, 2-A, 3-C, 4-D`,`1-D, 2-A, 3-B, 4-C`,`1-B, 2-A, 3-D, 4-C`],answer:3,explanation:`Dhan Nach–Limbu; Tamang Selo–Tamang; Sakela–Rai; Deuda–far west.`},{id:`Q 6.5.3`,label:`Expected – Practice`,stem:`<p>Which musical instrument is traditionally played by the Gandarbha community?</p>
`,options:[`Sarangi`,`Damphu`,`Dhimay`,`Chyabrung`],answer:0,explanation:`The sarangi. The damphu is Tamang, the dhimay Newar and the chyabrung Limbu.`},{id:`Q 6.5.4`,label:`Pattern-Based – Reconstructed`,stem:`<p>Three of these are instruments of the Panche Baja. Which one is <strong>not</strong>?</p>
`,options:[`Damaha`,`Sanai`,`Murchunga`,`Jhyali`],answer:2,explanation:`The murchunga is a small mouth instrument of the Kirat.`},{id:`Q 6.5.5`,label:`Pattern-Based – Reconstructed`,stem:`<p>Consider these statements.</p>
<ol>
<li>The Nyatapola temple of Bhaktapur has five roofs.</li>
<li>Paubha is a traditional painting of the Newar.</li>
<li>Mithila painting comes from the Sherpa community.</li>
</ol>
<p>Which of them are correct?</p>
`,options:[`1 only`,`1 and 2 only`,`2 and 3 only`,`1, 2 and 3`],answer:1,explanation:`Mithila painting is the art of Maithil women; its centre is Janakpur.`}]},{id:`6.6`,title:`Literature and notable persons (साहित्य र विशिष्ट व्यक्तित्व)`,questions:[{id:`Q 6.6.1`,label:`Pattern-Based – Reconstructed`,stem:`<p>Match the writer with his title of honour.</p>
<ol>
<li>Bhanubhakta Acharya — A. Mahakavi</li>
<li>Laxmi Prasad Devkota — B. Kavi Shiromani</li>
<li>Lekhnath Paudyal — C. Adikavi</li>
<li>Balkrishna Sama — D. Natya Samrat</li>
</ol>
`,options:[`1-A, 2-C, 3-B, 4-D`,`1-C, 2-B, 3-A, 4-D`,`1-C, 2-A, 3-B, 4-D`,`1-C, 2-A, 3-D, 4-B`],answer:2,explanation:`Bhanubhakta–Adikavi; Devkota–Mahakavi; Lekhnath–Kavi Shiromani; Sama–Natya Samrat.`},{id:`Q 6.6.2`,label:`Expected – Practice`,stem:`<p>Who wrote &quot;Muna Madan&quot;?</p>
`,options:[`Laxmi Prasad Devkota`,`Lekhnath Paudyal`,`Madhav Prasad Ghimire`,`Siddhicharan Shrestha`],answer:0,explanation:`Laxmi Prasad Devkota wrote it in the folk jhyaure metre.`},{id:`Q 6.6.3`,label:`Expected – Practice`,stem:`<p>Whose book won the Madan Puraskar for 2082 BS?</p>
`,options:[`Chhuden Kabimo`,`Krishna Dharabasi`,`Jhamak Kumari Ghimire`,`Bina Joshi (Rajbhandari)`],answer:3,explanation:`Bina Joshi (Rajbhandari), for her book on the traditional mask dances of the Newar community. Chhuden Kabimo's <em>Urmal</em> won for 2081. 🔄`},{id:`Q 6.6.4`,label:`Pattern-Based – Reconstructed`,stem:`<p>Consider these statements about the Madan Puraskar.</p>
<ol>
<li>It is given by the Nepal Academy.</li>
<li>It was set up in 2012 BS.</li>
<li>The Jagadamba Shree has been given by the same body since 2045 BS.</li>
</ol>
<p>Which of them are correct?</p>
`,options:[`1 only`,`2 and 3 only`,`1 and 2 only`,`1, 2 and 3`],answer:1,explanation:`The prize is given by the Madan Puraskar Guthi, not by the Nepal Academy.`},{id:`Q 6.6.5`,label:`Expected – Practice`,stem:`<p>For which novel did Parijat win the Madan Puraskar?</p>
`,options:[`Shirish ko Phool`,`Sumnima`,`Basain`,`Seto Bagh`],answer:0,explanation:`<em>Shirish ko Phool</em>, in 2022 BS. She was the first woman to win the prize.`}]},{id:`6.7`,title:`World Heritage Sites and places of pilgrimage (विश्व सम्पदा र तीर्थस्थल)`,questions:[{id:`Q 6.7.1`,label:`Expected – Practice`,stem:`<p>How many monument zones make up the Kathmandu Valley World Heritage Site?</p>
`,options:[`Seven`,`Four`,`Five`,`Ten`],answer:0,explanation:`Seven: three Durbar Squares, two stupas and two temples.`},{id:`Q 6.7.2`,label:`Pattern-Based – Reconstructed`,stem:`<p>Three of these are among the seven monument zones of the Kathmandu Valley. Which one is <strong>not</strong>?</p>
`,options:[`Changu Narayan`,`Boudhanath`,`Budhanilkantha`,`Patan Durbar Square`],answer:2,explanation:`Budhanilkantha is a famous shrine of the reclining Vishnu, but it is not one of the seven zones.`},{id:`Q 6.7.3`,label:`Expected – Practice`,stem:`<p>In which year was Lumbini inscribed on the World Heritage List?</p>
`,options:[`1979`,`1997`,`1984`,`2003`],answer:1,explanation:`1997. The Kathmandu Valley and Sagarmatha National Park were listed in 1979 and Chitwan National Park in 1984.`},{id:`Q 6.7.4`,label:`Pattern-Based – Reconstructed`,stem:`<p>Consider these statements.</p>
<ol>
<li>Nepal has four World Heritage Sites.</li>
<li>Tilaurakot was added to the World Heritage List in 2025.</li>
<li>Fifteen sites are on Nepal's tentative list.</li>
</ol>
<p>Which of them are correct?</p>
`,options:[`1 only`,`1 and 2 only`,`2 and 3 only`,`1 and 3 only`],answer:3,explanation:`The nomination of Tilaurakot was deferred in July 2025; it was not added. 🔄`},{id:`Q 6.7.5`,label:`Pattern-Based – Reconstructed`,stem:`<p>Match the holy place with its district.</p>
<ol>
<li>Muktinath — A. Dhanusha</li>
<li>Janaki Temple — B. Mustang</li>
<li>Pathibhara — C. Taplejung</li>
<li>Swargadwari — D. Pyuthan</li>
</ol>
`,options:[`1-A, 2-B, 3-C, 4-D`,`1-B, 2-A, 3-D, 4-C`,`1-B, 2-A, 3-C, 4-D`,`1-C, 2-A, 3-B, 4-D`],answer:2,explanation:`Muktinath–Mustang; Janaki Temple–Dhanusha; Pathibhara–Taplejung; Swargadwari–Pyuthan.`}]},{id:`6.8`,title:`National symbols, heroes, honours and days (राष्ट्रिय प्रतीक, विभूति, विभूषण र दिवस)`,questions:[{id:`Q 6.8.1`,label:`Pattern-Based – Reconstructed`,stem:`<p>Fill in the blank. Nepal has ______ national heroes (राष्ट्रिय विभूति).</p>
`,options:[`13`,`16`,`17`,`18`],answer:3,explanation:`Eighteen, since Jay Prithvi Bahadur Singh was added in Ashad 2079. 🔄`},{id:`Q 6.8.2`,label:`Expected – Practice`,stem:`<p>Who wrote the words of the national anthem &quot;Sayaun Thunga Phulka&quot;?</p>
`,options:[`Amber Gurung`,`Byakul Maila`,`Chakrapani Chalise`,`Madhav Prasad Ghimire`],answer:1,explanation:`Byakul Maila. Amber Gurung composed the music.`},{id:`Q 6.8.3`,label:`Pattern-Based – Reconstructed`,stem:`<p>Match the date with the day.</p>
<ol>
<li>3 Ashoj — A. Martyrs' Day</li>
<li>15 Jestha — B. Democracy Day</li>
<li>16 Magh — C. Constitution Day</li>
<li>7 Falgun — D. Republic Day</li>
</ol>
`,options:[`1-D, 2-C, 3-A, 4-B`,`1-C, 2-D, 3-B, 4-A`,`1-C, 2-D, 3-A, 4-B`,`1-A, 2-D, 3-C, 4-B`],answer:2,explanation:`3 Ashoj Constitution Day; 15 Jestha Republic Day; 16 Magh Martyrs' Day; 7 Falgun Democracy Day.`},{id:`Q 6.8.4`,label:`Expected – Practice`,stem:`<p>Who was the latest person to be declared a national hero, in Ashad 2079?</p>
`,options:[`Jay Prithvi Bahadur Singh`,`Bhakti Thapa`,`Mahaguru Phalgunanda`,`Pasang Lhamu Sherpa`],answer:0,explanation:`Jay Prithvi Bahadur Singh of Bajhang, by a decision of 6 Ashad 2079. Bhakti Thapa was added in 2078. 🔄`},{id:`Q 6.8.5`,label:`Pattern-Based – Reconstructed`,stem:`<p>Consider these statements.</p>
<ol>
<li>Under Article 277 the President confers titles, honours and decorations.</li>
<li>The national sport of Nepal is volleyball.</li>
<li>Since Chaitra 2082 government offices have two weekly holidays, Saturday and Sunday.</li>
</ol>
<p>Which of them are correct?</p>
`,options:[`1 only`,`1 and 2 only`,`2 and 3 only`,`1, 2 and 3`],answer:3,explanation:`All three are correct. The third follows the decision of 22 Chaitra 2082. 🔄`}]},{id:`6.9`,title:`Social issues and inclusion (सामाजिक समस्या र समावेशीकरण)`,questions:[{id:`Q 6.9.1`,label:`Expected – Practice`,stem:`<p>On which date was Nepal declared a nation free of caste-based untouchability?</p>
`,options:[`3 Ashoj 2072`,`21 Jestha 2063`,`11 Baisakh 2063`,`1 Bhadra 2075`],answer:1,explanation:`21 Jestha 2063 (4 June 2006). The Act against untouchability followed in 2068.`},{id:`Q 6.9.2`,label:`Pattern-Based – Reconstructed`,stem:`<p>Match the Act with its subject.</p>
<ol>
<li>Act of 2068 — A. Rights of persons with disabilities</li>
<li>Act of 2063 — B. Caste-based discrimination and untouchability</li>
<li>Act of 2074 — C. Senior citizens</li>
<li>Act of 2066 — D. Domestic violence</li>
</ol>
`,options:[`1-C, 2-B, 3-A, 4-D`,`1-B, 2-A, 3-C, 4-D`,`1-B, 2-C, 3-A, 4-D`,`1-D, 2-C, 3-A, 4-B`],answer:2,explanation:`2068 untouchability; 2063 senior citizens; 2074 disability; 2066 domestic violence.`},{id:`Q 6.9.3`,label:`Pattern-Based – Reconstructed`,stem:`<p>Fill in the blank. The legal age of marriage in Nepal, for both men and women, is ______ years.</p>
`,options:[`20`,`18`,`21`,`16`],answer:0,explanation:`Twenty years. Eighteen is the age at which childhood ends under the Act of 2075. 🔄`},{id:`Q 6.9.4`,label:`Pattern-Based – Reconstructed`,stem:`<p>Consider these statements.</p>
<ol>
<li>Chhaupadi is a punishable offence.</li>
<li>Under the Senior Citizens Act, 2063 a person becomes a senior citizen at 70 years.</li>
<li>Article 24 gives the right against untouchability and discrimination.</li>
</ol>
<p>Which of them are correct?</p>
`,options:[`1 only`,`1 and 2 only`,`2 and 3 only`,`1 and 3 only`],answer:3,explanation:`A senior citizen is a person of 60 years or more under the Act of 2063.`},{id:`Q 6.9.5`,label:`Expected – Practice`,stem:`<p>Which Article of the Constitution gives disadvantaged groups the right to take part in State bodies on the principle of inclusion?</p>
`,options:[`Article 42`,`Article 40`,`Article 38`,`Article 43`],answer:0,explanation:`Article 42, the right to social justice. Article 43 is the right to social security.`}]},{id:`6.10`,title:`Education (शिक्षा)`,questions:[{id:`Q 6.10.1`,label:`Expected – Practice`,stem:`<p>What was the literacy rate of people aged five and above in the Census of 2078?</p>
`,options:[`65.9 percent`,`71.9 percent`,`76.2 percent`,`83.6 percent`],answer:2,explanation:`76.2 percent. It was 65.9 percent in 2068; 83.6 percent is the rate for men.`},{id:`Q 6.10.2`,label:`Expected – Practice`,stem:`<p>Which province has the lowest literacy rate in the Census of 2078?</p>
`,options:[`Madhesh`,`Karnali`,`Sudurpashchim`,`Lumbini`],answer:0,explanation:`Madhesh, 63.5 percent. Bagmati is highest with 82.1 percent.`},{id:`Q 6.10.3`,label:`Pattern-Based – Reconstructed`,stem:`<p>Arrange these by date of founding, the earliest first.</p>
<ol>
<li>Tribhuvan University</li>
<li>Durbar High School</li>
<li>Kathmandu University</li>
<li>Tri-Chandra College</li>
</ol>
`,options:[`2, 1, 4, 3`,`4, 2, 1, 3`,`2, 4, 3, 1`,`2, 4, 1, 3`],answer:3,explanation:`Durbar High School 1910 BS, Tri-Chandra College 1975, Tribhuvan University 2016, Kathmandu University 2048.`},{id:`Q 6.10.4`,label:`Pattern-Based – Reconstructed`,stem:`<p>Consider these statements.</p>
<ol>
<li>Basic education covers Grades 1 to 8.</li>
<li>A new School Education Act replaced the Education Act, 2028 in 2082 BS.</li>
<li>Article 31 makes basic education compulsory and free.</li>
</ol>
<p>Which of them are correct?</p>
`,options:[`1 only`,`1 and 3 only`,`2 and 3 only`,`1, 2 and 3`],answer:1,explanation:`The Education Act, 2028 was still in force when this chapter was checked; a new Act was only being prepared. 🔄`},{id:`Q 6.10.5`,label:`Expected – Practice`,stem:`<p>Which body conducts the national examination at the end of Grade 12?</p>
`,options:[`Curriculum Development Centre`,`University Grants Commission`,`Tribhuvan University`,`National Examinations Board`],answer:3,explanation:`The National Examinations Board.`}]},{id:`T`,title:`End-of-chapter test — Top 25`,questions:[{id:`T1`,label:`Expected – Practice`,stem:`<p>Which day was the census day (reference day) of the Census of 2078?</p>
`,options:[`25 Kartik 2078`,`9 Mangsir 2078`,`1 Baisakh 2078`,`12 Magh 2078`],answer:1,explanation:`9 Mangsir 2078 (25 November 2021). The field count began on 25 Kartik.`},{id:`T2`,label:`Pattern-Based – Reconstructed`,stem:`<p>Fill in the blank. Between the censuses of 2068 and 2078 the population grew by ______ percent a year.</p>
`,options:[`1.35`,`2.25`,`0.92`,`0.52`],answer:2,explanation:`0.92 percent. The rate in the ten years before was 1.35 percent.`},{id:`T3`,label:`Pattern-Based – Reconstructed`,stem:`<p>Fill in the blank. In the Census of 2078, ______ percent of households were headed by a woman.</p>
`,options:[`31.55`,`23.8`,`11.8`,`51.13`],answer:0,explanation:`31.55 percent. In 23.8 percent of households a woman owns the house, the land or both.`},{id:`T4`,label:`Expected – Practice`,stem:`<p>Which people are known as the last nomads of Nepal, moving through the forests of the west?</p>
`,options:[`Chepang`,`Raji`,`Tharu`,`Raute`],answer:3,explanation:`The Raute. The census counted only 566 of them.`},{id:`T5`,label:`Pattern-Based – Reconstructed`,stem:`<p>Match the province with its largest caste or ethnic group in the Census of 2078.</p>
<ol>
<li>Madhesh — A. Tamang</li>
<li>Bagmati — B. Yadav</li>
<li>Lumbini — C. Chhetri</li>
<li>Karnali — D. Magar</li>
</ol>
`,options:[`1-A, 2-B, 3-D, 4-C`,`1-B, 2-A, 3-D, 4-C`,`1-B, 2-D, 3-A, 4-C`,`1-C, 2-A, 3-D, 4-B`],answer:1,explanation:`Madhesh–Yadav; Bagmati–Tamang; Lumbini–Magar; Karnali–Chhetri.`},{id:`T6`,label:`Expected – Practice`,stem:`<p>Which is the second-largest religion of Nepal in the Census of 2078?</p>
`,options:[`Islam`,`Kirat`,`Buddhism`,`Christianity`],answer:2,explanation:`Buddhism, 8.21 percent. Islam is third and Kirat fourth.`},{id:`T7`,label:`Expected – Practice`,stem:`<p>Which language of Nepal stands alone, related to no other language?</p>
`,options:[`Kusunda`,`Santhali`,`Kurux`,`Dura`],answer:0,explanation:`Kusunda. Santhali is Austro-Asiatic and Kurux is Dravidian.`},{id:`T8`,label:`Expected – Practice`,stem:`<p>On which date did Tamang and Nepal Bhasa come into use as official languages of Bagmati Province?</p>
`,options:[`3 Ashoj 2080`,`24 Baisakh 2081`,`25 Kartik 2083`,`1 Shrawan 2082`],answer:1,explanation:`24 Baisakh 2081 (6 May 2024). The date 25 Kartik 2083 belongs to Koshi. 🔄`},{id:`T9`,label:`Pattern-Based – Reconstructed`,stem:`<p>Arrange these festivals in the order in which they fall in a year that begins in Baisakh.</p>
<ol>
<li>Dashain</li>
<li>Maghe Sankranti</li>
<li>Buddha Jayanti</li>
<li>Tihar</li>
</ol>
`,options:[`3, 4, 1, 2`,`1, 3, 4, 2`,`3, 1, 2, 4`,`3, 1, 4, 2`],answer:3,explanation:`Buddha Jayanti (Baisakh), Dashain (Ashoj), Tihar (Kartik), Maghe Sankranti (1 Magh).`},{id:`T10`,label:`Expected – Practice`,stem:`<p>The chariot festival of Rato Machhindranath belongs to which city?</p>
`,options:[`Kathmandu`,`Bhaktapur`,`Lalitpur`,`Kirtipur`],answer:2,explanation:`Lalitpur (Patan). It ends with the Bhoto Jatra.`},{id:`T11`,label:`Expected – Practice`,stem:`<p>In which style of architecture is the Janaki Temple of Janakpur built?</p>
`,options:[`Dome style`,`Pagoda style`,`Shikhara style`,`Stupa style`],answer:0,explanation:`The dome style, with rounded roofs and arches.`},{id:`T12`,label:`Pattern-Based – Reconstructed`,stem:`<p>Match the craft with the place known for it.</p>
<ol>
<li>Dhaka cloth — A. Bhojpur</li>
<li>Khukuri — B. Palpa</li>
<li>Pottery — C. Janakpur</li>
<li>Mithila painting — D. Thimi</li>
</ol>
`,options:[`1-A, 2-B, 3-D, 4-C`,`1-B, 2-A, 3-D, 4-C`,`1-B, 2-D, 3-A, 4-C`,`1-C, 2-A, 3-D, 4-B`],answer:1,explanation:`Dhaka–Palpa; khukuri–Bhojpur; pottery–Thimi; Mithila painting–Janakpur.`},{id:`T13`,label:`Expected – Practice`,stem:`<p>Who is known as the &quot;Rashtra Kavi&quot; (राष्ट्रकवि)?</p>
`,options:[`Siddhicharan Shrestha`,`Lekhnath Paudyal`,`Madhav Prasad Ghimire`,`Motiram Bhatta`],answer:2,explanation:`Madhav Prasad Ghimire. Siddhicharan Shrestha is the Yuga Kavi.`},{id:`T14`,label:`Expected – Practice`,stem:`<p>In which district was Bhanubhakta Acharya born?</p>
`,options:[`Kaski`,`Gorkha`,`Lamjung`,`Tanahun`],answer:3,explanation:`Tanahun, at Chundi Ramgha, on 29 Ashad 1871 BS.`},{id:`T15`,label:`Pattern-Based – Reconstructed`,stem:`<p>Consider these statements.</p>
<ol>
<li>&quot;Shakuntala&quot; is an epic by Laxmi Prasad Devkota.</li>
<li>&quot;Tarun Tapasi&quot; is by Lekhnath Paudyal.</li>
<li>&quot;Mukunda Indira&quot; is by Bhanubhakta Acharya.</li>
</ol>
<p>Which of them are correct?</p>
`,options:[`1 and 2 only`,`2 and 3 only`,`1 and 3 only`,`1, 2 and 3`],answer:0,explanation:`&quot;Mukunda Indira&quot; is a play by Balkrishna Sama.`},{id:`T16`,label:`Expected – Practice`,stem:`<p>Who received the Jagadamba Shree for 2082 BS?</p>
`,options:[`Premdev Giri`,`Kiran Kharel`,`Narayan Gopal`,`Bairagi Kainla`],answer:1,explanation:`The lyricist Kiran Kharel. Premdev Giri received it for 2081. 🔄`},{id:`T17`,label:`Expected – Practice`,stem:`<p>Which two natural sites of Nepal are on the World Heritage List?</p>
`,options:[`Rara and Shey Phoksundo National Parks`,`Annapurna Conservation Area and Langtang National Park`,`Sagarmatha and Chitwan National Parks`,`Bardiya and Shuklaphanta National Parks`],answer:2,explanation:`Sagarmatha (1979) and Chitwan (1984).`},{id:`T18`,label:`Expected – Practice`,stem:`<p>At which session of the World Heritage Committee, held in 2025, was the nomination of Tilaurakot deferred?</p>
`,options:[`The 47th`,`The 45th`,`The 46th`,`The 48th`],answer:0,explanation:`The 47th session, held in Paris in July 2025. 🔄`},{id:`T19`,label:`Pattern-Based – Reconstructed`,stem:`<p>Three of these are named in Article 9 of the Constitution. Which one is <strong>not</strong>?</p>
`,options:[`Rhododendron — national flower`,`Cow — national animal`,`Danphe — national bird`,`Volleyball — national sport`],answer:3,explanation:`Volleyball was declared the national sport by a Government decision in 2074; it is not in the Constitution.`},{id:`T20`,label:`Expected – Practice`,stem:`<p>On which date was the present national anthem adopted?</p>
`,options:[`15 Jestha 2065`,`18 Shrawan 2064`,`3 Ashoj 2072`,`1 Poush 2019`],answer:1,explanation:`18 Shrawan 2064 (3 August 2007).`},{id:`T21`,label:`Expected – Practice`,stem:`<p>Which day was placed in the holiday list for 2083 as Gen Z Martyrs' Day?</p>
`,options:[`16 Magh`,`27 Bhadra`,`23 Bhadra`,`3 Ashoj`],answer:2,explanation:`23 Bhadra. The older Martyrs' Day is 16 Magh. 🔄`},{id:`T22`,label:`Pattern-Based – Reconstructed`,stem:`<p>Match the Article with the right.</p>
<ol>
<li>Article 24 — A. Rights of senior citizens</li>
<li>Article 38 — B. Right against untouchability and discrimination</li>
<li>Article 40 — C. Rights of women</li>
<li>Article 41 — D. Rights of Dalit</li>
</ol>
`,options:[`1-B, 2-C, 3-D, 4-A`,`1-C, 2-B, 3-D, 4-A`,`1-B, 2-D, 3-C, 4-A`,`1-A, 2-C, 3-D, 4-B`],answer:0,explanation:`24 untouchability; 38 women; 40 Dalit; 41 senior citizens.`},{id:`T23`,label:`Expected – Practice`,stem:`<p>What colour is the identity card given to a person with a profound disability?</p>
`,options:[`Blue`,`Red`,`Yellow`,`White`],answer:1,explanation:`Red. Blue is for severe, yellow for moderate and white for mild disability.`},{id:`T24`,label:`Expected – Practice`,stem:`<p>Which district has the highest literacy rate in the Census of 2078?</p>
`,options:[`Lalitpur`,`Kaski`,`Bhaktapur`,`Kathmandu`],answer:3,explanation:`Kathmandu, 89.23 percent. Rautahat has the lowest, 57.75 percent.`},{id:`T25`,label:`Pattern-Based – Reconstructed`,stem:`<p>Consider these statements.</p>
<ol>
<li>The University Grants Commission was set up in 2050 BS.</li>
<li>The Secondary Education Examination is taken at the end of Grade 10.</li>
<li>Nepal Sanskrit University is the oldest university of Nepal.</li>
</ol>
<p>Which of them are correct?</p>
`,options:[`1 only`,`2 and 3 only`,`1 and 2 only`,`1, 2 and 3`],answer:2,explanation:`The oldest university is Tribhuvan University (2016 BS). Nepal Sanskrit University dates from 2043 BS.`}]}]},{num:7,title:`Science, Technology and Environment`,nep:`विज्ञान, प्रविधि र वातावरण`,slug:`part-11-chapter-07-science-technology-environment`,topics:[{id:`7.1`,title:`Science in daily life (दैनिक जीवनमा विज्ञान)`,questions:[{id:`Q 7.1.1`,label:`Expected – Practice`,stem:`<p>Which of these is the SI unit of force?</p>
`,options:[`Joule`,`Newton`,`Pascal`,`Watt`],answer:1,explanation:`The newton. The joule measures energy, the pascal pressure and the watt power.`},{id:`Q 7.1.2`,label:`Pattern-Based – Reconstructed`,stem:`<p>Fill in the blank. The instrument used to measure the pressure of the air is the ______.</p>
`,options:[`hygrometer`,`anemometer`,`seismograph`,`barometer`],answer:3,explanation:`The barometer. The hygrometer measures humidity, the anemometer wind speed and the seismograph earthquake waves.`},{id:`Q 7.1.3`,label:`Pattern-Based – Reconstructed`,stem:`<p>Match the person with the invention or discovery.</p>
<div class="tw"><table>
<thead>
<tr>
<th>Person</th>
<th>Invention or discovery</th>
</tr>
</thead>
<tbody>
<tr>
<td>A. Alexander Graham Bell</td>
<td>1. X-ray</td>
</tr>
<tr>
<td>B. Thomas Alva Edison</td>
<td>2. Telephone</td>
</tr>
<tr>
<td>C. Wright brothers</td>
<td>3. Aeroplane</td>
</tr>
<tr>
<td>D. Wilhelm Röntgen</td>
<td>4. Electric bulb</td>
</tr>
</tbody>
</table></div>
`,options:[`A-2, B-4, C-3, D-1`,`A-4, B-2, C-3, D-1`,`A-2, B-3, C-4, D-1`,`A-1, B-4, C-3, D-2`],answer:0,explanation:`Bell made the telephone (1876), Edison the electric bulb (1879), the Wright brothers the aeroplane (1903), and Röntgen discovered the X-ray (1895).`},{id:`Q 7.1.4`,label:`Pattern-Based – Reconstructed`,stem:`<p>Read the statements about sound.</p>
<ol>
<li>Sound travels faster in air than in steel.</li>
<li>Sound cannot travel through a vacuum.</li>
<li>The human ear hears sounds between 20 hertz and 20,000 hertz.</li>
</ol>
<p>Which statements are correct?</p>
`,options:[`1 and 2 only`,`1 and 3 only`,`2 and 3 only`,`1, 2 and 3`],answer:2,explanation:`Statement 1 is wrong: sound travels fastest in solids such as steel and slowest in gases such as air.`},{id:`Q 7.1.5`,label:`Expected – Practice`,stem:`<p>Which mirror is used as the rear-view mirror of a vehicle?</p>
`,options:[`Plane mirror`,`Convex mirror`,`Concave mirror`,`Cylindrical mirror`],answer:1,explanation:`A convex mirror gives a small, upright image and a wide view of the road behind.`}]},{id:`7.2`,title:`Chemistry in daily life: soap, plastic, fibre, glass, fertiliser and pesticide (दैनिक जीवनमा रसायन: साबुन, प्लास्टिक, रेसा, काँच, मल र कीटनाशक)`,questions:[{id:`Q 7.2.1`,label:`Expected – Practice`,stem:`<p>What is the process of making soap from fat or oil and an alkali called?</p>
`,options:[`Fermentation`,`Polymerisation`,`Saponification`,`Galvanising`],answer:2,explanation:`Saponification. Glycerol is the by-product.`},{id:`Q 7.2.2`,label:`Pattern-Based – Reconstructed`,stem:`<p>Fill in the blank. Urea contains about ______ percent nitrogen.</p>
`,options:[`46`,`21`,`18`,`60`],answer:0,explanation:`About 46 percent. Ammonium sulphate has about 21 percent, DAP 18 percent, and muriate of potash has about 60 percent potash.`},{id:`Q 7.2.3`,label:`Pattern-Based – Reconstructed`,stem:`<p>Match the kind of pesticide with the pest it controls.</p>
<div class="tw"><table>
<thead>
<tr>
<th>Pesticide</th>
<th>Pest</th>
</tr>
</thead>
<tbody>
<tr>
<td>A. Insecticide</td>
<td>1. Weeds</td>
</tr>
<tr>
<td>B. Fungicide</td>
<td>2. Rats and mice</td>
</tr>
<tr>
<td>C. Herbicide</td>
<td>3. Insects</td>
</tr>
<tr>
<td>D. Rodenticide</td>
<td>4. Fungi</td>
</tr>
</tbody>
</table></div>
`,options:[`A-3, B-1, C-4, D-2`,`A-4, B-3, C-1, D-2`,`A-3, B-4, C-2, D-1`,`A-3, B-4, C-1, D-2`],answer:3,explanation:`Insecticides kill insects, fungicides fungi, herbicides weeds and rodenticides rats and mice.`},{id:`Q 7.2.4`,label:`Pattern-Based – Reconstructed`,stem:`<p>Three of these are thermoplastics. Which one is a thermosetting plastic?</p>
`,options:[`Polythene`,`Bakelite`,`PVC`,`Polystyrene`],answer:1,explanation:`Bakelite cannot be softened and shaped again once it has set.`},{id:`Q 7.2.5`,label:`Pattern-Based – Reconstructed`,stem:`<p>Read the statements.</p>
<ol>
<li>Glass is made mainly from sand, soda ash and limestone.</li>
<li>Nylon is a natural fibre obtained from a plant.</li>
<li>Rayon is made from cellulose and is called artificial silk.</li>
</ol>
<p>Which statements are correct?</p>
`,options:[`1 and 3 only`,`1 and 2 only`,`2 and 3 only`,`1, 2 and 3`],answer:0,explanation:`Statement 2 is wrong: nylon is a fully synthetic fibre, first made in 1935.`}]},{id:`7.3`,title:`Cell, genes and evolution (कोष, वंशाणु र क्रमविकास)`,questions:[{id:`Q 7.3.1`,label:`Expected – Practice`,stem:`<p>Who is called the father of genetics?</p>
`,options:[`Charles Darwin`,`Jean-Baptiste Lamarck`,`Robert Hooke`,`Gregor Mendel`],answer:3,explanation:`Mendel found the laws of heredity by crossing pea plants.`},{id:`Q 7.3.2`,label:`Pattern-Based – Reconstructed`,stem:`<p>Fill in the blank. A normal body cell of a human being has ______ chromosomes.</p>
`,options:[`23`,`46`,`44`,`47`],answer:1,explanation:`46, in 23 pairs. An egg or a sperm has 23; a person with Down syndrome has 47.`},{id:`Q 7.3.3`,label:`Pattern-Based – Reconstructed`,stem:`<p>Match the scientist with the work.</p>
<div class="tw"><table>
<thead>
<tr>
<th>Scientist</th>
<th>Work</th>
</tr>
</thead>
<tbody>
<tr>
<td>A. Robert Hooke</td>
<td>1. Natural selection</td>
</tr>
<tr>
<td>B. Charles Darwin</td>
<td>2. First saw and named the cell</td>
</tr>
<tr>
<td>C. Watson and Crick</td>
<td>3. Inheritance of acquired characters</td>
</tr>
<tr>
<td>D. Lamarck</td>
<td>4. Double-helix model of DNA</td>
</tr>
</tbody>
</table></div>
`,options:[`A-2, B-3, C-4, D-1`,`A-1, B-2, C-4, D-3`,`A-2, B-1, C-4, D-3`,`A-2, B-1, C-3, D-4`],answer:2,explanation:`Hooke named the cell (1665); Darwin gave natural selection (1859); Watson and Crick the double helix (1953); Lamarck the inheritance of acquired characters (1809).`},{id:`Q 7.3.4`,label:`Pattern-Based – Reconstructed`,stem:`<p>Read the statements.</p>
<ol>
<li>The sex of a child depends on the chromosome carried by the father's sperm.</li>
<li>The mitochondrion is called the powerhouse of the cell.</li>
<li>The cell wall is found in animal cells but not in plant cells.</li>
</ol>
<p>Which statements are correct?</p>
`,options:[`1 and 2 only`,`2 and 3 only`,`1 and 3 only`,`1, 2 and 3`],answer:0,explanation:`Statement 3 is the wrong way round: the cell wall is found in plant cells, not in animal cells.`},{id:`Q 7.3.5`,label:`Expected – Practice`,stem:`<p>Which of these is a vestigial organ of the human body?</p>
`,options:[`Liver`,`Kidney`,`Appendix`,`Lung`],answer:2,explanation:`The appendix has no clear use in the human body today; it is a sign of our evolution.`}]},{id:`7.4`,title:`Health, disease, nutrition, vaccines and sanitation (स्वास्थ्य, रोग, पोषण, खोप र सरसफाइ)`,questions:[{id:`Q 7.4.1`,label:`Expected – Practice`,stem:`<p>On 18 August 2025 the World Health Organization announced that Nepal had eliminated which disease as a public-health problem?</p>
`,options:[`Rubella`,`Measles`,`Malaria`,`Kala-azar`],answer:0,explanation:`Rubella. Nepal was the sixth country of the South-East Asia Region to do so. Measles has not been eliminated.`},{id:`Q 7.4.2`,label:`Pattern-Based – Reconstructed`,stem:`<p>Match the missing nutrient with the disease it causes.</p>
<div class="tw"><table>
<thead>
<tr>
<th>Lack of</th>
<th>Disease</th>
</tr>
</thead>
<tbody>
<tr>
<td>A. Vitamin A</td>
<td>1. Rickets</td>
</tr>
<tr>
<td>B. Vitamin C</td>
<td>2. Scurvy</td>
</tr>
<tr>
<td>C. Vitamin D</td>
<td>3. Night blindness</td>
</tr>
<tr>
<td>D. Iodine</td>
<td>4. Goitre</td>
</tr>
</tbody>
</table></div>
`,options:[`A-3, B-1, C-2, D-4`,`A-2, B-3, C-1, D-4`,`A-3, B-2, C-1, D-4`,`A-3, B-2, C-4, D-1`],answer:2,explanation:`Lack of vitamin A causes night blindness, vitamin C scurvy, vitamin D rickets and iodine goitre.`},{id:`Q 7.4.3`,label:`Pattern-Based – Reconstructed`,stem:`<p>Fill in the blank. Under the health insurance programme, a family of up to five members pays Rs ______ a year.</p>
`,options:[`2,500`,`3,500`,`5,000`,`1,000`],answer:1,explanation:`Rs 3,500, for treatment worth up to Rs 100,000 a year.`},{id:`Q 7.4.4`,label:`Pattern-Based – Reconstructed`,stem:`<p>Three of these diseases are caused by a virus. Which one is caused by a bacterium?</p>
`,options:[`Dengue`,`Measles`,`Rabies`,`Tuberculosis`],answer:3,explanation:`Tuberculosis is caused by a bacterium, which Robert Koch found in 1882.`},{id:`Q 7.4.5`,label:`Pattern-Based – Reconstructed`,stem:`<p>Read the statements.</p>
<ol>
<li>Nepal's first case of COVID-19 was confirmed on 23 January 2020.</li>
<li>In the survey of 2022, 25 percent of children under five were stunted.</li>
<li>The Census of 2078 found a maternal mortality ratio of 151 for every 100,000 live births.</li>
</ol>
<p>Which statements are correct?</p>
`,options:[`1 and 2 only`,`2 and 3 only`,`1 and 3 only`,`1, 2 and 3`],answer:3,explanation:`All three are correct.`}]},{id:`7.5`,title:`Information and communication technology and cyber security (सूचना तथा सञ्चार प्रविधि र साइबर सुरक्षा)`,questions:[{id:`Q 7.5.1`,label:`Expected – Practice`,stem:`<p>Who invented the World Wide Web?</p>
`,options:[`Charles Babbage`,`Tim Berners-Lee`,`Ray Tomlinson`,`John McCarthy`],answer:1,explanation:`Tim Berners-Lee, in 1989. Babbage is the father of the computer, Tomlinson sent the first e-mail, and McCarthy named artificial intelligence.`},{id:`Q 7.5.2`,label:`Pattern-Based – Reconstructed`,stem:`<p>Fill in the blank. The Cyber Bureau of Nepal Police was set up by a decision of ______.</p>
`,options:[`27 Jestha 2075`,`5 Kartik 2076`,`3 Mangsir 2075`,`1 Ashoj 2070`],answer:0,explanation:`27 Jestha 2075 (10 June 2018). The Digital Nepal Framework was approved on 5 Kartik 2076, and the first national identity card was given on 3 Mangsir 2075.`},{id:`Q 7.5.3`,label:`Pattern-Based – Reconstructed`,stem:`<p>Arrange these main parts in the order of the computer generations that used them, from the first to the fourth.</p>
<ol>
<li>Integrated circuit</li>
<li>Vacuum tube</li>
<li>Microprocessor</li>
<li>Transistor</li>
</ol>
`,options:[`2, 1, 4, 3`,`4, 2, 1, 3`,`2, 4, 3, 1`,`2, 4, 1, 3`],answer:3,explanation:`Vacuum tube, transistor, integrated circuit, microprocessor.`},{id:`Q 7.5.4`,label:`Pattern-Based – Reconstructed`,stem:`<p>Match the term with its meaning.</p>
<div class="tw"><table>
<thead>
<tr>
<th>Term</th>
<th>Meaning</th>
</tr>
</thead>
<tbody>
<tr>
<td>A. Phishing</td>
<td>1. Locks the files and demands money</td>
</tr>
<tr>
<td>B. Ransomware</td>
<td>2. Blocks unwanted traffic between networks</td>
</tr>
<tr>
<td>C. Hacking</td>
<td>3. A fake message or website that steals passwords</td>
</tr>
<tr>
<td>D. Firewall</td>
<td>4. Entering a system without permission</td>
</tr>
</tbody>
</table></div>
`,options:[`A-3, B-4, C-1, D-2`,`A-1, B-3, C-4, D-2`,`A-3, B-1, C-4, D-2`,`A-3, B-1, C-2, D-4`],answer:2,explanation:`Phishing steals passwords through fake messages; ransomware locks files; hacking is unauthorised entry; a firewall filters traffic.`},{id:`Q 7.5.5`,label:`Expected – Practice`,stem:`<p>How many cybercrime complaints did Nepal Police record in fiscal year 2082/83?</p>
`,options:[`20,526`,`18,926`,`19,730`,`7,123`],answer:0,explanation:`20,526. The figure 18,926 is of 2081/82, 19,730 of 2080/81, and 7,123 is the number about Facebook and Messenger alone.`}]},{id:`7.6`,title:`Biotechnology, alternative energy and space (जैविक प्रविधि, वैकल्पिक ऊर्जा र अन्तरिक्ष)`,questions:[{id:`Q 7.6.1`,label:`Expected – Practice`,stem:`<p>Which is the main gas in biogas?</p>
`,options:[`Carbon dioxide`,`Hydrogen`,`Methane`,`Butane`],answer:2,explanation:`Methane. Butane and propane are the gases of cooking gas (LPG).`},{id:`Q 7.6.2`,label:`Pattern-Based – Reconstructed`,stem:`<p>Fill in the blank. The Alternative Energy Promotion Centre was set up on ______.</p>
`,options:[`1 Ashoj 2070`,`27 Jestha 2075`,`15 Mangsir 2082`,`18 Kartik 2053`],answer:3,explanation:`18 Kartik 2053 (3 November 1996).`},{id:`Q 7.6.3`,label:`Pattern-Based – Reconstructed`,stem:`<p>Match the Nepali satellite with the fact about it.</p>
<div class="tw"><table>
<thead>
<tr>
<th>Satellite</th>
<th>Fact</th>
</tr>
</thead>
<tbody>
<tr>
<td>A. NepaliSat-1</td>
<td>1. Lost when an Indian rocket failed in January 2026</td>
</tr>
<tr>
<td>B. SanoSat-1</td>
<td>2. Nepal's first satellite, 2019</td>
</tr>
<tr>
<td>C. Slippers2Sat</td>
<td>3. Launched from China in December 2025</td>
</tr>
<tr>
<td>D. Munal</td>
<td>4. Launched in January 2022</td>
</tr>
</tbody>
</table></div>
`,options:[`A-2, B-4, C-3, D-1`,`A-2, B-3, C-4, D-1`,`A-4, B-2, C-3, D-1`,`A-2, B-4, C-1, D-3`],answer:0,explanation:`NepaliSat-1 was the first (2019); SanoSat-1 flew in January 2022; Slippers2Sat was launched from China in December 2025; Munal was lost in January 2026.`},{id:`Q 7.6.4`,label:`Pattern-Based – Reconstructed`,stem:`<p>Read the statements.</p>
<ol>
<li>Artemis II carried four astronauts round the Moon in April 2026.</li>
<li>Dolly the sheep was the first mammal cloned from an adult body cell.</li>
<li>The first artificial satellite, Sputnik 1, was launched by the United States.</li>
</ol>
<p>Which statements are correct?</p>
`,options:[`1 and 3 only`,`1 and 2 only`,`2 and 3 only`,`1, 2 and 3`],answer:1,explanation:`Statement 3 is wrong: Sputnik 1 was launched by the Soviet Union on 4 October 1957.`},{id:`Q 7.6.5`,label:`Expected – Practice`,stem:`<p>Who won the Nobel Prize in Physics in 2026?</p>
`,options:[`Karl Deisseroth`,`Francis Halzen`,`Henri B. Kagan`,`Kenso Soai`],answer:1,explanation:`Francis Halzen, for the IceCube neutrino observatory. Deisseroth shared the prize in medicine; Kagan and Soai shared the prize in chemistry.`}]},{id:`7.7`,title:`Ecosystem, natural cycles and biodiversity (पारिस्थितिक प्रणाली, जैव-भू-रासायनिक चक्र र जैविक विविधता)`,questions:[{id:`Q 7.7.1`,label:`Expected – Practice`,stem:`<p>Which living things are the producers of an ecosystem?</p>
`,options:[`Green plants`,`Plant-eating animals`,`Fungi`,`Flesh-eating animals`],answer:0,explanation:`Green plants make food from sunlight. Fungi are decomposers.`},{id:`Q 7.7.2`,label:`Pattern-Based – Reconstructed`,stem:`<p>Fill in the blank. In the tiger count announced on 29 July 2026, Chitwan had the most tigers: ______.</p>
`,options:[`112`,`145`,`71`,`51`],answer:1,explanation:`145. Bardiya had 112, Parsa 71, Banke 51 and Shuklaphanta 50 — 429 in all.`},{id:`Q 7.7.3`,label:`Pattern-Based – Reconstructed`,stem:`<p>Arrange these into a food chain, from the producer to the last consumer.</p>
<ol>
<li>Snake</li>
<li>Grass</li>
<li>Eagle</li>
<li>Grasshopper</li>
<li>Frog</li>
</ol>
`,options:[`2, 5, 4, 1, 3`,`4, 2, 5, 1, 3`,`2, 4, 1, 5, 3`,`2, 4, 5, 1, 3`],answer:3,explanation:`Grass → grasshopper → frog → snake → eagle.`},{id:`Q 7.7.4`,label:`Pattern-Based – Reconstructed`,stem:`<p>Match the animal with its main home.</p>
<div class="tw"><table>
<thead>
<tr>
<th>Animal</th>
<th>Home</th>
</tr>
</thead>
<tbody>
<tr>
<td>A. Wild water buffalo (arna)</td>
<td>1. Chitwan</td>
</tr>
<tr>
<td>B. Blackbuck</td>
<td>2. Khairapur, Bardiya</td>
</tr>
<tr>
<td>C. Swamp deer</td>
<td>3. Shuklaphanta</td>
</tr>
<tr>
<td>D. One-horned rhinoceros</td>
<td>4. Koshi Tappu</td>
</tr>
</tbody>
</table></div>
`,options:[`A-4, B-3, C-2, D-1`,`A-2, B-4, C-3, D-1`,`A-4, B-2, C-3, D-1`,`A-4, B-2, C-1, D-3`],answer:2,explanation:`The arna lives in Koshi Tappu, the blackbuck at Khairapur, the swamp deer in Shuklaphanta and most rhinoceroses in Chitwan.`},{id:`Q 7.7.5`,label:`Expected – Practice`,stem:`<p>Which of these is conservation outside the natural home of a species (ex-situ conservation)?</p>
`,options:[`National park`,`Wildlife reserve`,`Conservation area`,`Zoo`],answer:3,explanation:`A zoo keeps animals away from their natural home. The other three protect them where they live.`}]},{id:`7.8`,title:`Pollution, greenhouse effect, climate change and the ozone layer (प्रदूषण, हरितगृह प्रभाव, जलवायु परिवर्तन र ओजोन तह)`,questions:[{id:`Q 7.8.1`,label:`Expected – Practice`,stem:`<p>In which city did the United Nations climate conference COP31 open on 9 November 2026?</p>
`,options:[`Baku`,`Belém`,`Dubai`,`Antalya`],answer:3,explanation:`Antalya, Türkiye. Dubai held COP28, Baku COP29 and Belém COP30.`},{id:`Q 7.8.2`,label:`Pattern-Based – Reconstructed`,stem:`<p>Fill in the blank. The International Day for the Preservation of the Ozone Layer is marked on ______.</p>
`,options:[`5 June`,`22 April`,`16 September`,`22 May`],answer:2,explanation:`16 September, the date on which the Montreal Protocol was signed in 1987.`},{id:`Q 7.8.3`,label:`Pattern-Based – Reconstructed`,stem:`<p>Arrange these agreements in order of time, the earliest first.</p>
<ol>
<li>Paris Agreement</li>
<li>Kyoto Protocol</li>
<li>Montreal Protocol</li>
<li>United Nations Framework Convention on Climate Change</li>
</ol>
`,options:[`4, 3, 2, 1`,`3, 4, 2, 1`,`3, 2, 4, 1`,`2, 3, 4, 1`],answer:1,explanation:`Montreal Protocol 1987; Framework Convention 1992; Kyoto Protocol 1997; Paris Agreement 2015.`},{id:`Q 7.8.4`,label:`Pattern-Based – Reconstructed`,stem:`<p>Read the statements.</p>
<ol>
<li>The ozone layer lies in the stratosphere.</li>
<li>Chlorofluorocarbons damage the ozone layer.</li>
<li>The thinning of the ozone layer is the main cause of global warming.</li>
</ol>
<p>Which statements are correct?</p>
`,options:[`1 and 2 only`,`2 and 3 only`,`1 and 3 only`,`1, 2 and 3`],answer:0,explanation:`Statement 3 is wrong. Global warming is caused mainly by greenhouse gases such as carbon dioxide and methane.`},{id:`Q 7.8.5`,label:`Expected – Practice`,stem:`<p>In its third Nationally Determined Contribution, by what percentage does Nepal aim to cut net greenhouse-gas emissions by 2035, against &quot;business as usual&quot;?</p>
`,options:[`17.12`,`45`,`26.79`,`100`],answer:2,explanation:`26.79 percent by 2035. The figure 17.12 percent is the aim for 2030.`}]},{id:`7.9`,title:`Sustainable development, the Sustainable Development Goals and carbon trade (दिगो विकास, दिगो विकास लक्ष्य र कार्बन व्यापार)`,questions:[{id:`Q 7.9.1`,label:`Expected – Practice`,stem:`<p>Which report of 1987 gave the best-known definition of sustainable development?</p>
`,options:[`Agenda 21`,`Our Common Future`,`The Limits to Growth`,`The Future We Want`],answer:1,explanation:`<em>Our Common Future</em>, the Brundtland Report. Agenda 21 is of 1992 and <em>The Future We Want</em> of 2012.`},{id:`Q 7.9.2`,label:`Pattern-Based – Reconstructed`,stem:`<p>Fill in the blank. One carbon credit stands for ______ of carbon dioxide cut or removed.</p>
`,options:[`one tonne`,`one kilogram`,`one hundred tonnes`,`one quintal`],answer:0,explanation:`One tonne of carbon dioxide, or the same warming effect from another gas.`},{id:`Q 7.9.3`,label:`Pattern-Based – Reconstructed`,stem:`<p>Match each goal on environment and energy with its number among the Sustainable Development Goals.</p>
<div class="tw"><table>
<thead>
<tr>
<th>Number</th>
<th>Subject</th>
</tr>
</thead>
<tbody>
<tr>
<td>A. Goal 6</td>
<td>1. Life on land</td>
</tr>
<tr>
<td>B. Goal 7</td>
<td>2. Clean water and sanitation</td>
</tr>
<tr>
<td>C. Goal 13</td>
<td>3. Climate action</td>
</tr>
<tr>
<td>D. Goal 15</td>
<td>4. Affordable and clean energy</td>
</tr>
</tbody>
</table></div>
`,options:[`A-2, B-3, C-4, D-1`,`A-4, B-2, C-3, D-1`,`A-2, B-4, C-3, D-1`,`A-2, B-4, C-1, D-3`],answer:2,explanation:`Goal 6 clean water and sanitation; Goal 7 affordable and clean energy; Goal 13 climate action; Goal 15 life on land.`},{id:`Q 7.9.4`,label:`Pattern-Based – Reconstructed`,stem:`<p>Read the statements.</p>
<ol>
<li>The Carbon Trade Regulations, 2082 allow the private sector to take part in carbon trade.</li>
<li>Nepal's first forest-carbon payment from the World Bank's facility was USD 9.4 million.</li>
<li>The Clean Development Mechanism was created by the Paris Agreement.</li>
</ol>
<p>Which statements are correct?</p>
`,options:[`1 and 3 only`,`2 and 3 only`,`1, 2 and 3`,`1 and 2 only`],answer:3,explanation:`Statement 3 is wrong: the Clean Development Mechanism was created by the Kyoto Protocol of 1997.`},{id:`Q 7.9.5`,label:`Pattern-Based – Reconstructed`,stem:`<p>Three of these are the flexible mechanisms of the Kyoto Protocol. Which one is not?</p>
`,options:[`Carbon tax`,`Emissions Trading`,`Clean Development Mechanism`,`Joint Implementation`],answer:0,explanation:`A carbon tax is a separate tool that a government may use on its own.`}]},{id:`7.10`,title:`Population, urbanisation, migration and disaster management (जनसङ्ख्या, सहरीकरण, बसाइँसराइ र विपद् व्यवस्थापन)`,questions:[{id:`Q 7.10.1`,label:`Expected – Practice`,stem:`<p>Who chairs the National Council for Disaster Risk Reduction and Management?</p>
`,options:[`The Home Minister`,`The Chief Secretary`,`The Prime Minister`,`The President`],answer:2,explanation:`The Prime Minister. The Home Minister chairs the Executive Committee.`},{id:`Q 7.10.2`,label:`Pattern-Based – Reconstructed`,stem:`<p>Fill in the blank. The Sendai Framework for Disaster Risk Reduction covers the years ______.</p>
`,options:[`2005–2015`,`2000–2015`,`2016–2030`,`2015–2030`],answer:3,explanation:`2015–2030. The Hyogo Framework covered 2005–2015.`},{id:`Q 7.10.3`,label:`Pattern-Based – Reconstructed`,stem:`<p>Match the body with its chair.</p>
<div class="tw"><table>
<thead>
<tr>
<th>Body</th>
<th>Chair</th>
</tr>
</thead>
<tbody>
<tr>
<td>A. Executive Committee (federal)</td>
<td>1. Chief District Officer</td>
</tr>
<tr>
<td>B. Province Disaster Management Council</td>
<td>2. Chairperson of the rural municipality or mayor</td>
</tr>
<tr>
<td>C. District Disaster Management Committee</td>
<td>3. Home Minister</td>
</tr>
<tr>
<td>D. Local Disaster Management Committee</td>
<td>4. Chief Minister</td>
</tr>
</tbody>
</table></div>
`,options:[`A-3, B-1, C-4, D-2`,`A-3, B-4, C-1, D-2`,`A-4, B-3, C-1, D-2`,`A-3, B-4, C-2, D-1`],answer:1,explanation:`Home Minister; Chief Minister; Chief District Officer; chairperson or mayor.`},{id:`Q 7.10.4`,label:`Pattern-Based – Reconstructed`,stem:`<p>Read the statements.</p>
<ol>
<li>The Bhote Koshi flood struck on 10 Bhadra 2083.</li>
<li>By the degree-of-urbanisation measure, 27.07 percent of Nepal's people lived in urban areas in 2021.</li>
<li>The Disaster Risk Reduction and Management Act was made in 2039 BS.</li>
</ol>
<p>Which statements are correct?</p>
`,options:[`1 and 2 only`,`2 and 3 only`,`1 and 3 only`,`1, 2 and 3`],answer:0,explanation:`Statement 3 is wrong: the Act is of 2074. The Act of 2039 was the Natural Calamity (Relief) Act, which it replaced.`},{id:`Q 7.10.5`,label:`Pattern-Based – Reconstructed`,stem:`<p>Put these stages of disaster management in the usual order, starting before a disaster.</p>
<ol>
<li>Response</li>
<li>Preparedness</li>
<li>Recovery</li>
<li>Mitigation</li>
</ol>
`,options:[`2, 4, 1, 3`,`4, 2, 1, 3`,`4, 1, 2, 3`,`1, 2, 3, 4`],answer:1,explanation:`Mitigation, preparedness, response, recovery.`}]},{id:`T`,title:`End-of-chapter test — Top 25`,questions:[{id:`T1`,label:`Expected – Practice`,stem:`<p>Which is the SI unit of electric current?</p>
`,options:[`Volt`,`Ohm`,`Ampere`,`Coulomb`],answer:2,explanation:`The ampere. The volt measures potential difference, the ohm resistance and the coulomb charge.`},{id:`T2`,label:`Pattern-Based – Reconstructed`,stem:`<p>Fill in the blank. The pH of a neutral liquid such as pure water is ______.</p>
`,options:[`7`,`0`,`14`,`1`],answer:0,explanation:`7. Below 7 is acid; above 7 is base.`},{id:`T3`,label:`Expected – Practice`,stem:`<p>Which gas makes up the largest part of the air?</p>
`,options:[`Oxygen`,`Carbon dioxide`,`Argon`,`Nitrogen`],answer:3,explanation:`Nitrogen, about 78 percent. Oxygen is about 21 percent.`},{id:`T4`,label:`Pattern-Based – Reconstructed`,stem:`<p>Match the disease with its carrier.</p>
<div class="tw"><table>
<thead>
<tr>
<th>Disease</th>
<th>Carrier</th>
</tr>
</thead>
<tbody>
<tr>
<td>A. Malaria</td>
<td>1. Sandfly</td>
</tr>
<tr>
<td>B. Dengue</td>
<td>2. Culex mosquito</td>
</tr>
<tr>
<td>C. Kala-azar</td>
<td>3. Female Anopheles mosquito</td>
</tr>
<tr>
<td>D. Japanese encephalitis</td>
<td>4. Aedes mosquito</td>
</tr>
</tbody>
</table></div>
`,options:[`A-4, B-3, C-1, D-2`,`A-3, B-4, C-1, D-2`,`A-3, B-4, C-2, D-1`,`A-3, B-1, C-4, D-2`],answer:1,explanation:`Malaria is carried by the female Anopheles mosquito, dengue by Aedes, kala-azar by the sandfly and Japanese encephalitis by Culex.`},{id:`T5`,label:`Expected – Practice`,stem:`<p>Who discovered penicillin?</p>
`,options:[`Louis Pasteur`,`Edward Jenner`,`Alexander Fleming`,`Robert Koch`],answer:2,explanation:`Alexander Fleming, in 1928. Jenner made the first vaccine; Koch found the germ of tuberculosis.`},{id:`T6`,label:`Pattern-Based – Reconstructed`,stem:`<p>Read the statements about the human body.</p>
<ol>
<li>Blood of group O negative is called the universal donor.</li>
<li>An adult human body has 206 bones.</li>
<li>Insulin is made in the liver.</li>
</ol>
<p>Which statements are correct?</p>
`,options:[`1 and 2 only`,`2 and 3 only`,`1 and 3 only`,`1, 2 and 3`],answer:0,explanation:`Statement 3 is wrong: insulin is made in the pancreas.`},{id:`T7`,label:`Expected – Practice`,stem:`<p>On which date was Nepal declared an open-defecation-free country?</p>
`,options:[`25 Chaitra 2072`,`13 Ashoj 2076`,`11 Chaitra 2076`,`14 Magh 2077`],answer:1,explanation:`13 Ashoj 2076 (30 September 2019). The other dates are the start of health insurance, the first lockdown and the start of COVID-19 vaccination.`},{id:`T8`,label:`Pattern-Based – Reconstructed`,stem:`<p>Fill in the blank. The virus that causes COVID-19 is called ______.</p>
`,options:[`HIV`,`rotavirus`,`rubella virus`,`SARS-CoV-2`],answer:3,explanation:`SARS-CoV-2. The disease was first reported from Wuhan, China, in December 2019.`},{id:`T9`,label:`Expected – Practice`,stem:`<p>How many bits make one byte?</p>
`,options:[`4`,`10`,`8`,`1,024`],answer:2,explanation:`8 bits make 1 byte; 1,024 bytes make 1 kilobyte.`},{id:`T10`,label:`Pattern-Based – Reconstructed`,stem:`<p>Three of these are input devices of a computer. Which one is an output device?</p>
`,options:[`Printer`,`Keyboard`,`Mouse`,`Scanner`],answer:0,explanation:`A printer gives results out. The other three send data in.`},{id:`T11`,label:`Expected – Practice`,stem:`<p>Of which year is Nepal's National Artificial Intelligence Policy?</p>
`,options:[`2063`,`2076`,`2080`,`2082`],answer:3,explanation:`2082. The Electronic Transactions Act is of 2063, the Digital Nepal Framework of 2076 and the National Cyber Security Policy of 2080.`},{id:`T12`,label:`Pattern-Based – Reconstructed`,stem:`<p>Fill in the blank. Louise Brown, the world's first test-tube baby, was born in ______.</p>
`,options:[`1953`,`1978`,`1996`,`2003`],answer:1,explanation:`1978. The other years belong to the double helix of DNA, Dolly the sheep and the Human Genome Project.`},{id:`T13`,label:`Expected – Practice`,stem:`<p>From which country was the Nepali satellite Slippers2Sat launched in December 2025?</p>
`,options:[`India`,`Japan`,`China`,`United States`],answer:2,explanation:`China. Munal, launched from India in January 2026, was lost when the rocket failed.`},{id:`T14`,label:`Pattern-Based – Reconstructed`,stem:`<p>Read the statements about energy.</p>
<ol>
<li>Coal is a renewable source of energy.</li>
<li>Biogas forms when dung rots without air.</li>
<li>In Nepal a micro-hydropower plant is one of up to 100 kilowatts.</li>
</ol>
<p>Which statements are correct?</p>
`,options:[`2 and 3 only`,`1 and 2 only`,`1 and 3 only`,`1, 2 and 3`],answer:0,explanation:`Statement 1 is wrong: coal is a fossil fuel and will run out.`},{id:`T15`,label:`Expected – Practice`,stem:`<p>How many birds are fully protected by the National Parks and Wildlife Conservation Act, 2029?</p>
`,options:[`3`,`9`,`26`,`38`],answer:1,explanation:`Nine birds. The Act also protects 26 mammals and 3 reptiles — 38 animals in all.`},{id:`T16`,label:`Pattern-Based – Reconstructed`,stem:`<p>Fill in the blank. Green plants make food from carbon dioxide and water with the help of sunlight. This process is ______.</p>
`,options:[`respiration`,`transpiration`,`fermentation`,`photosynthesis`],answer:3,explanation:`Photosynthesis. It also gives out oxygen.`},{id:`T17`,label:`Pattern-Based – Reconstructed`,stem:`<p>Three of these are greenhouse gases. Which one is not?</p>
`,options:[`Carbon dioxide`,`Methane`,`Nitrogen`,`Nitrous oxide`],answer:2,explanation:`Nitrogen, the main gas of the air, does not trap heat.`},{id:`T18`,label:`Expected – Practice`,stem:`<p>Which year is the warmest on record, according to the World Meteorological Organization?</p>
`,options:[`2016`,`2024`,`2025`,`2023`],answer:1,explanation:`2024, at about 1.55 °C above the average of 1850–1900.`},{id:`T19`,label:`Pattern-Based – Reconstructed`,stem:`<p>Match the climate conference with its city.</p>
<div class="tw"><table>
<thead>
<tr>
<th>Conference</th>
<th>City</th>
</tr>
</thead>
<tbody>
<tr>
<td>A. COP28</td>
<td>1. Antalya</td>
</tr>
<tr>
<td>B. COP29</td>
<td>2. Dubai</td>
</tr>
<tr>
<td>C. COP30</td>
<td>3. Belém</td>
</tr>
<tr>
<td>D. COP31</td>
<td>4. Baku</td>
</tr>
</tbody>
</table></div>
`,options:[`A-2, B-4, C-3, D-1`,`A-4, B-2, C-3, D-1`,`A-2, B-3, C-4, D-1`,`A-2, B-4, C-1, D-3`],answer:0,explanation:`COP28 Dubai (2023); COP29 Baku (2024); COP30 Belém (2025); COP31 Antalya (2026).`},{id:`T20`,label:`Expected – Practice`,stem:`<p>By which year does Nepal aim to reach net-zero emissions of greenhouse gases?</p>
`,options:[`2030`,`2035`,`2050`,`2045`],answer:3,explanation:`2045, under its long-term strategy.`},{id:`T21`,label:`Pattern-Based – Reconstructed`,stem:`<p>Fill in the blank. The Sagarmatha Sambaad of May 2025 ended with a ______-point &quot;Sagarmatha Call for Action&quot;.</p>
`,options:[`10`,`17`,`25`,`40`],answer:2,explanation:`25 points. The meeting was held in Kathmandu on 2–4 Jestha 2082.`},{id:`T22`,label:`Expected – Practice`,stem:`<p>Under the Environment Protection Act, 2076, which is the fullest level of study, required for the largest projects?</p>
`,options:[`Brief environmental study`,`Environmental impact assessment`,`Initial environmental examination`,`Feasibility study`],answer:1,explanation:`The environmental impact assessment. The brief study is the lightest and the initial examination lies between.`},{id:`T23`,label:`Expected – Practice`,stem:`<p>Of which year is the National Population Policy now in force?</p>
`,options:[`2082`,`2071`,`2078`,`2068`],answer:0,explanation:`2082, approved on 23 Ashad 2082. It replaced the policy of 2071.`},{id:`T24`,label:`Pattern-Based – Reconstructed`,stem:`<p>Read the statements.</p>
<ol>
<li>The International Day for Disaster Risk Reduction is 13 October.</li>
<li>Earthquake Safety Day in Nepal is 2 Magh.</li>
<li>The Jajarkot earthquake struck on 17 Kartik 2080.</li>
</ol>
<p>Which statements are correct?</p>
`,options:[`1 and 2 only`,`2 and 3 only`,`1 and 3 only`,`1, 2 and 3`],answer:3,explanation:`All three are correct.`},{id:`T25`,label:`Pattern-Based – Reconstructed`,stem:`<p>Arrange these disasters in order of time, the earliest first.</p>
<ol>
<li>Jajarkot earthquake</li>
<li>Bhote Koshi flood</li>
<li>Gorkha earthquake</li>
<li>Thame flood</li>
</ol>
`,options:[`1, 3, 4, 2`,`3, 4, 1, 2`,`3, 1, 4, 2`,`3, 1, 2, 4`],answer:2,explanation:`Gorkha earthquake 2072; Jajarkot earthquake 2080; Thame flood 2081; Bhote Koshi flood 2083.`}]}]},{num:8,title:`International Relations and Organisations`,nep:`अन्तर्राष्ट्रिय सम्बन्ध र सङ्गठन`,slug:`part-12-chapter-08-international-relations`,topics:[{id:`8.1`,title:`Foreign policy of Nepal (नेपालको परराष्ट्र नीति)`,questions:[{id:`Q 8.1.1`,label:`Expected – Practice`,stem:`<p>How many diplomatic missions did Nepal keep abroad in June 2026?</p>
`,options:[`31`,`34`,`44`,`188`],answer:2,explanation:`44: 31 embassies, 3 permanent missions to the United Nations and 10 consulates general. 188 is the number of countries with which Nepal has diplomatic relations. 🔄`},{id:`Q 8.1.2`,label:`Pattern-Based – Reconstructed`,stem:`<p>Fill in the blank. The five principles of Panchsheel were first written in an agreement of 1954 between India and ______.</p>
`,options:[`Nepal`,`China`,`Indonesia`,`Egypt`],answer:1,explanation:`China. The agreement of 29 April 1954 was about trade with Tibet. Article 51 of the Constitution of Nepal names Panchsheel as a base of foreign policy.`},{id:`Q 8.1.3`,label:`Pattern-Based – Reconstructed`,stem:`<p>Read the statements about treaty-making under the Constitution.</p>
<ol>
<li>Only the Federation may make treaties.</li>
<li>A treaty on the boundaries of Nepal needs two-thirds of all members of both Houses.</li>
<li>A Province may sign a defence treaty with a foreign state if the Government of Nepal consents.</li>
</ol>
<p>Which statements are correct?</p>
`,options:[`1 and 2 only`,`1 and 3 only`,`2 and 3 only`,`1, 2 and 3`],answer:0,explanation:`Statement 3 is wrong. Under Article 278 a Province may make only contractual agreements on financial and industrial matters, with federal consent.`},{id:`Q 8.1.4`,label:`Pattern-Based – Reconstructed`,stem:`<p>Match the body with the year Nepal entered it.</p>
<div class="tw"><table>
<thead>
<tr>
<th>Body</th>
<th>Year</th>
</tr>
</thead>
<tbody>
<tr>
<td>A. United Nations</td>
<td>1. 2004</td>
</tr>
<tr>
<td>B. Non-Aligned Movement</td>
<td>2. 1955</td>
</tr>
<tr>
<td>C. SAARC</td>
<td>3. 1961</td>
</tr>
<tr>
<td>D. World Trade Organization</td>
<td>4. 1985</td>
</tr>
</tbody>
</table></div>
`,options:[`A-2, B-4, C-3, D-1`,`A-3, B-2, C-4, D-1`,`A-1, B-3, C-4, D-2`,`A-2, B-3, C-4, D-1`],answer:3,explanation:`United Nations 1955; Non-Aligned Movement 1961 (founding member); SAARC 1985 (founding member); World Trade Organization 2004.`},{id:`Q 8.1.5`,label:`Pattern-Based – Reconstructed`,stem:`<p>Which of these is NOT one of the five principles of Panchsheel?</p>
`,options:[`Mutual non-aggression`,`Peaceful co-existence`,`Collective military alliance`,`Equality and mutual benefit`],answer:2,explanation:`Panchsheel has nothing on military alliances. Its five principles are respect for territorial integrity and sovereignty, non-aggression, non-interference, equality and mutual benefit, and peaceful co-existence.`}]},{id:`8.2`,title:`Nepal and India (नेपाल–भारत सम्बन्ध)`,questions:[{id:`Q 8.2.1`,label:`Expected – Practice`,stem:`<p>The Treaty of Peace and Friendship of 1950 between Nepal and India can be ended by either side with a notice of</p>
`,options:[`six months`,`one year`,`two years`,`five years`],answer:1,explanation:`One year, under Article 10. The treaty has 10 Articles and was signed on 31 July 1950.`},{id:`Q 8.2.2`,label:`Pattern-Based – Reconstructed`,stem:`<p>Match the agreement with its year.</p>
<div class="tw"><table>
<thead>
<tr>
<th>Agreement</th>
<th>Year</th>
</tr>
</thead>
<tbody>
<tr>
<td>A. Koshi Agreement</td>
<td>1. 1996</td>
</tr>
<tr>
<td>B. Gandak Agreement</td>
<td>2. 1954</td>
</tr>
<tr>
<td>C. Mahakali Treaty</td>
<td>3. 2024</td>
</tr>
<tr>
<td>D. Agreement on 10,000 megawatts in ten years</td>
<td>4. 1959</td>
</tr>
</tbody>
</table></div>
`,options:[`A-2, B-4, C-1, D-3`,`A-4, B-2, C-1, D-3`,`A-2, B-1, C-4, D-3`,`A-2, B-4, C-3, D-1`],answer:0,explanation:`Koshi 1954, Gandak 1959, Mahakali 1996, and the long-term power agreement of 4 January 2024.`},{id:`Q 8.2.3`,label:`Pattern-Based – Reconstructed`,stem:`<p>Read the statements about the boundary questions with India.</p>
<ol>
<li>Nepal's claim to Limpiyadhura, Lipulekh and Kalapani rests on the Sugauli Treaty, which makes the Kali river the boundary.</li>
<li>Nepal published a map showing these areas on 7 Jestha 2077.</li>
<li>Susta lies in Darchula district.</li>
</ol>
<p>Which statements are correct?</p>
`,options:[`1 only`,`2 and 3 only`,`1 and 2 only`,`1, 2 and 3`],answer:2,explanation:`Statement 3 is wrong. Susta is in Nawalparasi West; Kalapani, Lipulekh and Limpiyadhura are in Darchula.`},{id:`Q 8.2.4`,label:`Pattern-Based – Reconstructed`,stem:`<p>Fill in the blank. The Pancheshwar Multipurpose Project is provided for in the ______ Treaty of 1996.</p>
`,options:[`Koshi`,`Gandak`,`Sugauli`,`Mahakali`],answer:3,explanation:`The Mahakali Treaty of 12 February 1996 covers the Sarada Barrage, the Tanakpur Barrage and the Pancheshwar project.`},{id:`Q 8.2.5`,label:`Expected – Practice`,stem:`<p>Which is the first cross-border petroleum pipeline of South Asia, opened in September 2019?</p>
`,options:[`Motihari–Amlekhgunj`,`Siliguri–Jhapa`,`Raxaul–Kathmandu`,`Gorakhpur–Butwal`],answer:0,explanation:`The Motihari–Amlekhgunj pipeline carries petroleum from Bihar to Bara district. A pipeline from Siliguri to Jhapa is planned.`}]},{id:`8.3`,title:`Nepal and China (नेपाल–चीन सम्बन्ध)`,questions:[{id:`Q 8.3.1`,label:`Expected – Practice`,stem:`<p>On which date did Nepal and China establish diplomatic relations?</p>
`,options:[`1 August 1955`,`14 December 1955`,`28 April 1960`,`5 October 1961`],answer:0,explanation:`1 August 1955. Nepal joined the United Nations on 14 December 1955; the friendship treaty is of 28 April 1960 and the boundary treaty of 5 October 1961.`},{id:`Q 8.3.2`,label:`Pattern-Based – Reconstructed`,stem:`<p>Arrange these events in the order in which they happened.</p>
<ol>
<li>Boundary Treaty with China</li>
<li>Diplomatic relations with China</li>
<li>Memorandum of Understanding on the Belt and Road Initiative</li>
<li>Treaty of Peace and Friendship with China</li>
</ol>
`,options:[`2 – 1 – 4 – 3`,`4 – 2 – 1 – 3`,`2 – 4 – 3 – 1`,`2 – 4 – 1 – 3`],answer:3,explanation:`Relations 1955, friendship treaty 1960, boundary treaty 1961, Belt and Road memorandum 2017.`},{id:`Q 8.3.3`,label:`Pattern-Based – Reconstructed`,stem:`<p>Read the statements about transit through China.</p>
<ol>
<li>The Transit and Transport Agreement was signed in 2016.</li>
<li>Its Protocol lets Nepal use four sea ports and three dry ports.</li>
<li>Kolkata is one of the sea ports named in the Protocol.</li>
</ol>
<p>Which statements are correct?</p>
`,options:[`1 only`,`1 and 2 only`,`2 and 3 only`,`1, 2 and 3`],answer:1,explanation:`Statement 3 is wrong. The Chinese sea ports are Tianjin, Shenzhen, Lianyungang and Zhanjiang. Kolkata is an Indian port.`},{id:`Q 8.3.4`,label:`Pattern-Based – Reconstructed`,stem:`<p>Fill in the blank. The Framework for Belt and Road Cooperation between Nepal and China was signed in Beijing on ______.</p>
`,options:[`12 May 2017`,`13 October 2019`,`4 December 2024`,`15 June 2026`],answer:2,explanation:`4 December 2024. The earlier memorandum was signed in Kathmandu on 12 May 2017.`},{id:`Q 8.3.5`,label:`Expected – Practice`,stem:`<p>Who signed the Boundary Treaty of 1961 on behalf of Nepal?</p>
`,options:[`B.P. Koirala`,`Tanka Prasad Acharya`,`King Tribhuvan`,`King Mahendra`],answer:3,explanation:`King Mahendra signed it in Beijing with Chairman Liu Shaoqi. B.P. Koirala had signed the friendship treaty of 1960 with Zhou Enlai.`}]},{id:`8.4`,title:`Nepal and the United Kingdom, the United States and Japan (नेपाल र बेलायत, अमेरिका, जापान)`,questions:[{id:`Q 8.4.1`,label:`Expected – Practice`,stem:`<p>On which date did the MCC compact between Nepal and the United States come into force?</p>
`,options:[`14 September 2017`,`27 February 2022`,`30 August 2023`,`10 June 2026`],answer:2,explanation:`30 August 2023 (13 Bhadra 2080). It was signed on 14 September 2017 and ratified on 27 February 2022.`},{id:`Q 8.4.2`,label:`Pattern-Based – Reconstructed`,stem:`<p>Match the partner with the link.</p>
<div class="tw"><table>
<thead>
<tr>
<th>Partner</th>
<th>Link</th>
</tr>
</thead>
<tbody>
<tr>
<td>A. United Kingdom</td>
<td>1. MCC compact</td>
</tr>
<tr>
<td>B. United States</td>
<td>2. Framework for Belt and Road Cooperation</td>
</tr>
<tr>
<td>C. Japan</td>
<td>3. Gurkha soldiers</td>
</tr>
<tr>
<td>D. China</td>
<td>4. Loan for the Nagdhunga tunnel</td>
</tr>
</tbody>
</table></div>
`,options:[`A-3, B-1, C-2, D-4`,`A-3, B-1, C-4, D-2`,`A-1, B-3, C-4, D-2`,`A-3, B-4, C-1, D-2`],answer:1,explanation:`Gurkhas serve in the British army; the MCC compact is American; Japan lent the money for the tunnel; the Belt and Road framework was signed with China.`},{id:`Q 8.4.3`,label:`Pattern-Based – Reconstructed`,stem:`<p>Read the statements about Nepal and the United Kingdom.</p>
<ol>
<li>The United Kingdom was the first country with which Nepal had diplomatic relations.</li>
<li>Nepal's first mission abroad was opened in London.</li>
<li>The Tripartite Agreement of 1947 was signed by Nepal, Britain and the United States.</li>
</ol>
<p>Which statements are correct?</p>
`,options:[`1 and 2 only`,`1 and 3 only`,`2 and 3 only`,`1, 2 and 3`],answer:0,explanation:`Statement 3 is wrong. The third party to the agreement on the Gurkhas was India.`},{id:`Q 8.4.4`,label:`Pattern-Based – Reconstructed`,stem:`<p>Fill in the blank. Nepal's first road tunnel, from Nagdhunga to Sisnekhola, was built with a loan from ______.</p>
`,options:[`China`,`India`,`the Asian Development Bank`,`Japan`],answer:3,explanation:`Japan. The 2.688 km tunnel was opened on 27 July 2026.`},{id:`Q 8.4.5`,label:`Expected – Practice`,stem:`<p>How much grant does the United States give under the MCC compact with Nepal?</p>
`,options:[`USD 197 million`,`USD 550 million`,`USD 747 million`,`USD 1 billion`],answer:1,explanation:`USD 550 million. Nepal adds USD 197 million, which makes USD 747 million in all.`}]},{id:`8.5`,title:`Nepal and the Gulf countries, South Korea, Malaysia and Israel (नेपाल र खाडी मुलुक, दक्षिण कोरिया, मलेसिया र इजरायल)`,questions:[{id:`Q 8.5.1`,label:`Pattern-Based – Reconstructed`,stem:`<p>Which of these countries is NOT a member of the Gulf Cooperation Council?</p>
`,options:[`Oman`,`Bahrain`,`Kuwait`,`Iran`],answer:3,explanation:`Iran. The six members are Saudi Arabia, the United Arab Emirates, Qatar, Kuwait, Bahrain and Oman.`},{id:`Q 8.5.2`,label:`Pattern-Based – Reconstructed`,stem:`<p>Match the country with its currency.</p>
<div class="tw"><table>
<thead>
<tr>
<th>Country</th>
<th>Currency</th>
</tr>
</thead>
<tbody>
<tr>
<td>A. Malaysia</td>
<td>1. Won</td>
</tr>
<tr>
<td>B. South Korea</td>
<td>2. Dirham</td>
</tr>
<tr>
<td>C. United Arab Emirates</td>
<td>3. Shekel</td>
</tr>
<tr>
<td>D. Israel</td>
<td>4. Ringgit</td>
</tr>
</tbody>
</table></div>
`,options:[`A-4, B-1, C-2, D-3`,`A-1, B-4, C-2, D-3`,`A-4, B-1, C-3, D-2`,`A-2, B-1, C-4, D-3`],answer:0,explanation:`Malaysia uses the ringgit, South Korea the won, the United Arab Emirates the dirham and Israel the shekel.`},{id:`Q 8.5.3`,label:`Expected – Practice`,stem:`<p>Under which arrangement do Nepali workers go to South Korea?</p>
`,options:[`The sponsorship (<em>kafala</em>) system`,`The Employment Permit System`,`The Colombo Plan`,`The Tripartite Agreement`],answer:1,explanation:`The Employment Permit System, run by the two governments. Workers must first pass a Korean-language test.`},{id:`Q 8.5.4`,label:`Pattern-Based – Reconstructed`,stem:`<p>Fill in the blank. Nepal, the first country of South Asia to do so, opened diplomatic relations with Israel in ______.</p>
`,options:[`1947`,`1955`,`1960`,`1977`],answer:2,explanation:`On 1 June 1960, when B.P. Koirala was Prime Minister.`},{id:`Q 8.5.5`,label:`Pattern-Based – Reconstructed`,stem:`<p>Read the statements about labour relations.</p>
<ol>
<li>Under the memorandum of 2018 with Malaysia the employer bears the cost of recruitment.</li>
<li>Nepal opened relations with Kuwait before it did so with Qatar.</li>
<li>Private recruiting agencies select the workers who go to South Korea.</li>
</ol>
<p>Which statements are correct?</p>
`,options:[`1 only`,`2 and 3 only`,`1 and 2 only`,`1, 2 and 3`],answer:2,explanation:`Statement 3 is wrong. Selection for South Korea is done by the two governments through a language test, not by private agencies.`}]},{id:`8.6`,title:`The United Nations (संयुक्त राष्ट्रसङ्घ)`,questions:[{id:`Q 8.6.1`,label:`Expected – Practice`,stem:`<p>On which date did the Charter of the United Nations come into force?</p>
`,options:[`1 January 1942`,`26 June 1945`,`10 December 1948`,`24 October 1945`],answer:3,explanation:`24 October 1945, kept as United Nations Day. The Charter was signed at San Francisco on 26 June 1945.`},{id:`Q 8.6.2`,label:`Pattern-Based – Reconstructed`,stem:`<p>Read the statements about the organs of the United Nations.</p>
<ol>
<li>The Security Council has ten elected members, each chosen for two years.</li>
<li>The Economic and Social Council has 54 members.</li>
<li>The International Court of Justice sits in New York.</li>
</ol>
<p>Which statements are correct?</p>
`,options:[`1 and 2 only`,`1 and 3 only`,`2 and 3 only`,`1, 2 and 3`],answer:0,explanation:`Statement 3 is wrong. The Court sits at The Hague in the Netherlands.`},{id:`Q 8.6.3`,label:`Pattern-Based – Reconstructed`,stem:`<p>Match the Secretary-General with his country.</p>
<div class="tw"><table>
<thead>
<tr>
<th>Secretary-General</th>
<th>Country</th>
</tr>
</thead>
<tbody>
<tr>
<td>A. U Thant</td>
<td>1. Ghana</td>
</tr>
<tr>
<td>B. Kofi Annan</td>
<td>2. Portugal</td>
</tr>
<tr>
<td>C. Ban Ki-moon</td>
<td>3. Myanmar</td>
</tr>
<tr>
<td>D. António Guterres</td>
<td>4. Republic of Korea</td>
</tr>
</tbody>
</table></div>
`,options:[`A-3, B-4, C-1, D-2`,`A-1, B-3, C-4, D-2`,`A-3, B-1, C-4, D-2`,`A-3, B-1, C-2, D-4`],answer:2,explanation:`U Thant was from Myanmar, Kofi Annan from Ghana, Ban Ki-moon from the Republic of Korea, and António Guterres is from Portugal.`},{id:`Q 8.6.4`,label:`Pattern-Based – Reconstructed`,stem:`<p>Fill in the blank. The work of the ______ was suspended on 1 November 1994, after Palau became independent.</p>
`,options:[`Economic and Social Council`,`Trusteeship Council`,`Security Council`,`Secretariat`],answer:1,explanation:`The Trusteeship Council. It had no trust territory left to supervise.`},{id:`Q 8.6.5`,label:`Expected – Practice`,stem:`<p>Which Nepali diplomat was elected President of the Economic and Social Council for its 2026 session?</p>
`,options:[`Gyan Chandra Acharya`,`Kul Chandra Gautam`,`Amrit Bahadur Rai`,`Lok Bahadur Thapa`],answer:3,explanation:`Lok Bahadur Thapa, Nepal's Permanent Representative in New York, was elected on 31 July 2025. Nepal had never before led a principal organ.`}]},{id:`8.7`,title:`SAARC (दक्षिण एसियाली क्षेत्रीय सहयोग सङ्गठन — सार्क)`,questions:[{id:`Q 8.7.1`,label:`Expected – Practice`,stem:`<p>Where and when was the Charter of SAARC signed?</p>
`,options:[`Kathmandu, 16 January 1987`,`Dhaka, 8 December 1985`,`New Delhi, 8 December 1985`,`Islamabad, 6 January 2004`],answer:1,explanation:`At the first summit in Dhaka on 8 December 1985. The Secretariat opened in Kathmandu on 16 January 1987.`},{id:`Q 8.7.2`,label:`Pattern-Based – Reconstructed`,stem:`<p>Match the SAARC institution with its seat.</p>
<div class="tw"><table>
<thead>
<tr>
<th>Institution</th>
<th>Seat</th>
</tr>
</thead>
<tbody>
<tr>
<td>A. SAARC Development Fund</td>
<td>1. New Delhi</td>
</tr>
<tr>
<td>B. South Asian University</td>
<td>2. Bhaktapur</td>
</tr>
<tr>
<td>C. SAARC Arbitration Council</td>
<td>3. Thimphu</td>
</tr>
<tr>
<td>D. SAARC Tuberculosis and HIV/AIDS Centre</td>
<td>4. Islamabad</td>
</tr>
</tbody>
</table></div>
`,options:[`A-3, B-1, C-4, D-2`,`A-1, B-3, C-4, D-2`,`A-3, B-4, C-1, D-2`,`A-2, B-1, C-4, D-3`],answer:0,explanation:`The Development Fund is in Thimphu, the University in New Delhi, the Arbitration Council in Islamabad, and the Tuberculosis and HIV/AIDS Centre at Thimi in Bhaktapur.`},{id:`Q 8.7.3`,label:`Pattern-Based – Reconstructed`,stem:`<p>Read the statements about SAARC.</p>
<ol>
<li>Afghanistan became the eighth member in 2007.</li>
<li>Decisions are taken by a two-thirds majority.</li>
<li>Bilateral and contentious issues are kept out of its discussions.</li>
</ol>
<p>Which statements are correct?</p>
`,options:[`1 and 2 only`,`2 and 3 only`,`1, 2 and 3`,`1 and 3 only`],answer:3,explanation:`Statement 2 is wrong. SAARC decides by unanimity.`},{id:`Q 8.7.4`,label:`Pattern-Based – Reconstructed`,stem:`<p>Fill in the blank. The agreement on the South Asian Free Trade Area (SAFTA) came into force on ______.</p>
`,options:[`8 December 1985`,`1 January 1995`,`1 January 2006`,`26 November 2014`],answer:2,explanation:`1 January 2006. It had been signed at the 12th Summit in Islamabad in January 2004.`},{id:`Q 8.7.5`,label:`Pattern-Based – Reconstructed`,stem:`<p>Which of these is NOT an observer of SAARC?</p>
`,options:[`Russia`,`China`,`Japan`,`Myanmar`],answer:0,explanation:`Russia. The nine observers are Australia, China, the European Union, Iran, Japan, the Republic of Korea, Mauritius, Myanmar and the United States.`}]},{id:`8.8`,title:`BIMSTEC (बिमस्टेक)`,questions:[{id:`Q 8.8.1`,label:`Expected – Practice`,stem:`<p>In which city is the Secretariat of BIMSTEC?</p>
`,options:[`Bangkok`,`Kathmandu`,`Dhaka`,`Colombo`],answer:2,explanation:`Dhaka, since 2014. BIMSTEC was founded in Bangkok; Kathmandu houses the Secretariat of SAARC.`},{id:`Q 8.8.2`,label:`Pattern-Based – Reconstructed`,stem:`<p>Arrange the hosts of the first four BIMSTEC summits in order.</p>
<ol>
<li>Kathmandu</li>
<li>Bangkok</li>
<li>Nay Pyi Taw</li>
<li>New Delhi</li>
</ol>
`,options:[`2 – 4 – 3 – 1`,`2 – 3 – 4 – 1`,`4 – 2 – 3 – 1`,`2 – 4 – 1 – 3`],answer:0,explanation:`Bangkok (2004), New Delhi (2008), Nay Pyi Taw (2014) and Kathmandu (2018).`},{id:`Q 8.8.3`,label:`Pattern-Based – Reconstructed`,stem:`<p>Which of these countries is NOT a member of BIMSTEC?</p>
`,options:[`Bhutan`,`Maldives`,`Myanmar`,`Thailand`],answer:1,explanation:`The Maldives is a member of SAARC only. BIMSTEC has Bangladesh, Bhutan, India, Myanmar, Nepal, Sri Lanka and Thailand.`},{id:`Q 8.8.4`,label:`Pattern-Based – Reconstructed`,stem:`<p>Fill in the blank. BIMSTEC was founded on 6 June 1997 by the ______ Declaration.</p>
`,options:[`Dhaka`,`Kathmandu`,`Colombo`,`Bangkok`],answer:3,explanation:`The Bangkok Declaration. The first members were Bangladesh, India, Sri Lanka and Thailand.`},{id:`Q 8.8.5`,label:`Pattern-Based – Reconstructed`,stem:`<p>Match the BIMSTEC sector with its lead country.</p>
<div class="tw"><table>
<thead>
<tr>
<th>Sector</th>
<th>Lead country</th>
</tr>
</thead>
<tbody>
<tr>
<td>A. Connectivity</td>
<td>1. Nepal</td>
</tr>
<tr>
<td>B. Security</td>
<td>2. Bangladesh</td>
</tr>
<tr>
<td>C. People-to-people contact</td>
<td>3. Thailand</td>
</tr>
<tr>
<td>D. Trade, investment and development</td>
<td>4. India</td>
</tr>
</tbody>
</table></div>
`,options:[`A-4, B-3, C-1, D-2`,`A-3, B-4, C-1, D-2`,`A-3, B-4, C-2, D-1`,`A-2, B-4, C-1, D-3`],answer:1,explanation:`Thailand leads connectivity, India security, Nepal people-to-people contact and Bangladesh trade, investment and development.`}]},{id:`8.9`,title:`ASEAN, the European Union and other groupings (आसियान, युरोपेली सङ्घ र अन्य समूह)`,questions:[{id:`Q 8.9.1`,label:`Expected – Practice`,stem:`<p>Which country became the eleventh member of ASEAN in October 2025?</p>
`,options:[`Timor-Leste`,`Papua New Guinea`,`Bangladesh`,`Sri Lanka`],answer:0,explanation:`Timor-Leste joined on 26 October 2025 at the summit in Kuala Lumpur.`},{id:`Q 8.9.2`,label:`Pattern-Based – Reconstructed`,stem:`<p>Fill in the blank. The European Union was created by the Treaty of ______, which came into force on 1 November 1993.</p>
`,options:[`Rome`,`Paris`,`Lisbon`,`Maastricht`],answer:3,explanation:`The Maastricht Treaty, signed on 7 February 1992. The Treaty of Rome (1957) had created the European Economic Community.`},{id:`Q 8.9.3`,label:`Pattern-Based – Reconstructed`,stem:`<p>Match the organisation with its seat.</p>
<div class="tw"><table>
<thead>
<tr>
<th>Organisation</th>
<th>Seat</th>
</tr>
</thead>
<tbody>
<tr>
<td>A. ASEAN</td>
<td>1. Vienna</td>
</tr>
<tr>
<td>B. European Union</td>
<td>2. Jakarta</td>
</tr>
<tr>
<td>C. Shanghai Cooperation Organisation</td>
<td>3. Brussels</td>
</tr>
<tr>
<td>D. OPEC</td>
<td>4. Beijing</td>
</tr>
</tbody>
</table></div>
`,options:[`A-2, B-3, C-1, D-4`,`A-3, B-2, C-4, D-1`,`A-2, B-3, C-4, D-1`,`A-4, B-3, C-2, D-1`],answer:2,explanation:`ASEAN is seated in Jakarta, the European Union in Brussels, the Shanghai Cooperation Organisation in Beijing and OPEC in Vienna.`},{id:`Q 8.9.4`,label:`Pattern-Based – Reconstructed`,stem:`<p>Read the statements about the European Union.</p>
<ol>
<li>It has 27 member states.</li>
<li>Bulgaria began to use the euro on 1 January 2026.</li>
<li>The United Kingdom is still a member.</li>
</ol>
<p>Which statements are correct?</p>
`,options:[`1 only`,`1 and 2 only`,`2 and 3 only`,`1, 2 and 3`],answer:1,explanation:`Statement 3 is wrong. The United Kingdom left the Union on 31 January 2020.`},{id:`Q 8.9.5`,label:`Pattern-Based – Reconstructed`,stem:`<p>Which of these countries is NOT a member of the G7?</p>
`,options:[`Canada`,`Italy`,`China`,`Japan`],answer:2,explanation:`China. The seven are Canada, France, Germany, Italy, Japan, the United Kingdom and the United States.`}]},{id:`8.10`,title:`Specialised agencies and international financial institutions (विशिष्टीकृत संस्था र अन्तर्राष्ट्रिय वित्तीय संस्था)`,questions:[{id:`Q 8.10.1`,label:`Expected – Practice`,stem:`<p>In which city is the headquarters of the Asian Development Bank?</p>
`,options:[`Tokyo`,`Manila`,`Beijing`,`Bangkok`],answer:1,explanation:`Manila, in the Philippines. Beijing is the seat of the Asian Infrastructure Investment Bank.`},{id:`Q 8.10.2`,label:`Pattern-Based – Reconstructed`,stem:`<p>Match the agency with its headquarters.</p>
<div class="tw"><table>
<thead>
<tr>
<th>Agency</th>
<th>Headquarters</th>
</tr>
</thead>
<tbody>
<tr>
<td>A. Food and Agriculture Organization</td>
<td>1. Paris</td>
</tr>
<tr>
<td>B. International Labour Organization</td>
<td>2. Washington, D.C.</td>
</tr>
<tr>
<td>C. International Monetary Fund</td>
<td>3. Rome</td>
</tr>
<tr>
<td>D. UNESCO</td>
<td>4. Geneva</td>
</tr>
</tbody>
</table></div>
`,options:[`A-3, B-4, C-1, D-2`,`A-4, B-3, C-2, D-1`,`A-3, B-2, C-4, D-1`,`A-3, B-4, C-2, D-1`],answer:3,explanation:`The Food and Agriculture Organization is in Rome, the International Labour Organization in Geneva, the Fund in Washington and UNESCO in Paris.`},{id:`Q 8.10.3`,label:`Pattern-Based – Reconstructed`,stem:`<p>Read the statements about the financial institutions.</p>
<ol>
<li>The World Bank and the International Monetary Fund were agreed at Bretton Woods in 1944.</li>
<li>The International Development Association gives very cheap loans to the poorest countries.</li>
<li>The headquarters of the International Monetary Fund is in Geneva.</li>
</ol>
<p>Which statements are correct?</p>
`,options:[`1 and 2 only`,`1 and 3 only`,`2 and 3 only`,`1, 2 and 3`],answer:0,explanation:`Statement 3 is wrong. The Fund, like the World Bank, is in Washington, D.C.`},{id:`Q 8.10.4`,label:`Pattern-Based – Reconstructed`,stem:`<p>Fill in the blank. The International Labour Organization was founded in ______.</p>
`,options:[`1895`,`1945`,`1919`,`1966`],answer:2,explanation:`In 1919, under the Treaty of Versailles. It became the first specialised agency of the United Nations in 1946.`},{id:`Q 8.10.5`,label:`Pattern-Based – Reconstructed`,stem:`<p>Which of these is NOT a specialised agency of the United Nations?</p>
`,options:[`International Cooperative Alliance`,`World Health Organization`,`Food and Agriculture Organization`,`International Labour Organization`],answer:0,explanation:`The International Cooperative Alliance is a non-governmental body of cooperatives, founded in 1895.`}]},{id:`T`,title:`End-of-chapter test — Top 25`,questions:[{id:`T1`,label:`Expected – Practice`,stem:`<p>With how many countries did Nepal have diplomatic relations at the end of September 2026?</p>
`,options:[`183`,`184`,`186`,`188`],answer:3,explanation:`188. Senegal was the 188th; five countries were added in September 2026. 🔄`},{id:`T2`,label:`Pattern-Based – Reconstructed`,stem:`<p>Fill in the blank. The first summit of the Non-Aligned Movement, of which Nepal is a founding member, met in 1961 at ______.</p>
`,options:[`Bandung`,`Belgrade`,`Cairo`,`Havana`],answer:1,explanation:`Belgrade. Bandung was the place of the Asian–African conference of 1955.`},{id:`T3`,label:`Expected – Practice`,stem:`<p>Which of these Indian states touches Nepal only along Sudurpashchim Province?</p>
`,options:[`Bihar`,`Sikkim`,`Uttarakhand`,`West Bengal`],answer:2,explanation:`Uttarakhand. Sikkim and West Bengal touch only Koshi; Bihar touches five provinces.`},{id:`T4`,label:`Pattern-Based – Reconstructed`,stem:`<p>Read the statements about the Eminent Persons Group of Nepal and India.</p>
<ol>
<li>It was formed in 2016.</li>
<li>Both prime ministers have received its report and put it into effect.</li>
<li>It had four members from each country.</li>
</ol>
<p>Which statements are correct?</p>
`,options:[`1 and 2 only`,`1 and 3 only`,`2 and 3 only`,`1, 2 and 3`],answer:1,explanation:`Statement 2 is wrong. The group finished its joint report in 2018, but the prime ministers have not yet received it.`},{id:`T5`,label:`Pattern-Based – Reconstructed`,stem:`<p>Match the treaty with the person who signed it for Nepal.</p>
<div class="tw"><table>
<thead>
<tr>
<th>Treaty</th>
<th>Signer</th>
</tr>
</thead>
<tbody>
<tr>
<td>A. Treaty of Peace and Friendship with India, 1950</td>
<td>1. King Mahendra</td>
</tr>
<tr>
<td>B. Treaty of Peace and Friendship with China, 1960</td>
<td>2. Chandra Shamsher</td>
</tr>
<tr>
<td>C. Boundary Treaty with China, 1961</td>
<td>3. Mohan Shamsher</td>
</tr>
<tr>
<td>D. Treaty with Britain, 1923</td>
<td>4. B.P. Koirala</td>
</tr>
</tbody>
</table></div>
`,options:[`A-3, B-4, C-1, D-2`,`A-4, B-3, C-1, D-2`,`A-3, B-1, C-4, D-2`,`A-2, B-4, C-1, D-3`],answer:0,explanation:`Mohan Shamsher signed in 1950, B.P. Koirala in 1960, King Mahendra in 1961 and Chandra Shamsher in 1923.`},{id:`T6`,label:`Expected – Practice`,stem:`<p>Which Chinese leader paid a state visit to Nepal on 12–13 October 2019?</p>
`,options:[`Li Qiang`,`Wang Yi`,`Zhou Enlai`,`Xi Jinping`],answer:3,explanation:`President Xi Jinping. It was the first visit by a Chinese president in 23 years.`},{id:`T7`,label:`Pattern-Based – Reconstructed`,stem:`<p>Which of these is NOT one of the three Chinese dry ports opened to Nepal by the transit protocol?</p>
`,options:[`Lanzhou`,`Lhasa`,`Tianjin`,`Xigatse`],answer:2,explanation:`Tianjin is one of the four sea ports. The dry ports are Lanzhou, Lhasa and Xigatse.`},{id:`T8`,label:`Pattern-Based – Reconstructed`,stem:`<p>Fill in the blank. Parliament ratified the MCC compact on 15 Falgun 2078 together with an interpretive declaration of ______ points.</p>
`,options:[`5`,`12`,`10`,`7`],answer:1,explanation:`Twelve points. The compact came into force on 30 August 2023.`},{id:`T9`,label:`Expected – Practice`,stem:`<p>Who became Prime Minister of the United Kingdom on 20 July 2026?</p>
`,options:[`Keir Starmer`,`Andy Burnham`,`Rishi Sunak`,`John Healey`],answer:1,explanation:`Andy Burnham took office after Keir Starmer resigned. 🔄`},{id:`T10`,label:`Expected – Practice`,stem:`<p>What is the capital of the United Arab Emirates?</p>
`,options:[`Dubai`,`Doha`,`Abu Dhabi`,`Muscat`],answer:2,explanation:`Abu Dhabi. Doha is the capital of Qatar and Muscat of Oman; Dubai is the largest city of the Emirates but not the capital.`},{id:`T11`,label:`Pattern-Based – Reconstructed`,stem:`<p>Read the statements.</p>
<ol>
<li>Nepal opened diplomatic relations with South Korea in 1974.</li>
<li>A worker must pass a Korean-language test to go under the Employment Permit System.</li>
<li>Nepal opened relations with Malaysia and with Israel in the same year.</li>
</ol>
<p>Which statements are correct?</p>
`,options:[`1 only`,`1 and 2 only`,`2 and 3 only`,`1, 2 and 3`],answer:3,explanation:`All three are correct. Relations with Malaysia date from 1 January 1960 and with Israel from 1 June 1960.`},{id:`T12`,label:`Expected – Practice`,stem:`<p>How many Articles does the Charter of the United Nations have?</p>
`,options:[`30`,`51`,`111`,`193`],answer:2,explanation:`111 Articles in 19 Chapters. Thirty is the number of Articles in the Universal Declaration of Human Rights; 51 is the number of original members; 193 is the number of members now.`},{id:`T13`,label:`Pattern-Based – Reconstructed`,stem:`<p>Match the body with its number of members.</p>
<div class="tw"><table>
<thead>
<tr>
<th>Body</th>
<th>Members</th>
</tr>
</thead>
<tbody>
<tr>
<td>A. General Assembly</td>
<td>1. 47</td>
</tr>
<tr>
<td>B. Security Council</td>
<td>2. 54</td>
</tr>
<tr>
<td>C. Economic and Social Council</td>
<td>3. 193</td>
</tr>
<tr>
<td>D. Human Rights Council</td>
<td>4. 15</td>
</tr>
</tbody>
</table></div>
`,options:[`A-3, B-4, C-2, D-1`,`A-3, B-2, C-4, D-1`,`A-4, B-3, C-2, D-1`,`A-3, B-4, C-1, D-2`],answer:0,explanation:`General Assembly 193, Security Council 15, Economic and Social Council 54, Human Rights Council 47.`},{id:`T14`,label:`Pattern-Based – Reconstructed`,stem:`<p>Fill in the blank. Nepal was an elected member of the Security Council in 1969–1970 and again in ______.</p>
`,options:[`1978–1979`,`1988–1989`,`1998–1999`,`2008–2009`],answer:1,explanation:`1988–1989. Nepal has served two terms on the Council.`},{id:`T15`,label:`Expected – Practice`,stem:`<p>Who was elected President of the 81st session of the United Nations General Assembly in June 2026?</p>
`,options:[`Khalilur Rahman`,`Annalena Baerbock`,`Rebeca Grynspan`,`Lok Bahadur Thapa`],answer:0,explanation:`Khalilur Rahman of Bangladesh. Annalena Baerbock of Germany led the 80th session. 🔄`},{id:`T16`,label:`Pattern-Based – Reconstructed`,stem:`<p>Which of these countries is NOT a permanent member of the Security Council?</p>
`,options:[`France`,`Germany`,`Russia`,`China`],answer:1,explanation:`Germany. The five are China, France, Russia, the United Kingdom and the United States.`},{id:`T17`,label:`Expected – Practice`,stem:`<p>Who was the first Secretary-General of SAARC?</p>
`,options:[`Abul Ahsan`,`Yadav Kant Silwal`,`Arjun Bahadur Thapa`,`Golam Sarwar`],answer:0,explanation:`Abul Ahsan of Bangladesh. Yadav Kant Silwal and Arjun Bahadur Thapa are the two Nepalis who have held the post.`},{id:`T18`,label:`Pattern-Based – Reconstructed`,stem:`<p>Arrange these bodies by date of founding, the oldest first.</p>
<ol>
<li>BIMSTEC</li>
<li>ASEAN</li>
<li>SAARC</li>
<li>European Union (Maastricht Treaty in force)</li>
</ol>
`,options:[`2 – 3 – 1 – 4`,`3 – 2 – 4 – 1`,`2 – 3 – 4 – 1`,`2 – 4 – 3 – 1`],answer:2,explanation:`ASEAN 1967, SAARC 1985, European Union 1993, BIMSTEC 1997.`},{id:`T19`,label:`Pattern-Based – Reconstructed`,stem:`<p>Fill in the blank. The 18th Summit of SAARC, the last one held so far, met in Kathmandu in November ______.</p>
`,options:[`2014`,`2002`,`2011`,`2016`],answer:0,explanation:`On 26–27 November 2014. The 19th Summit, due in Islamabad in 2016, never met.`},{id:`T20`,label:`Expected – Practice`,stem:`<p>When did the Charter of BIMSTEC come into force?</p>
`,options:[`6 June 1997`,`31 July 2004`,`30 March 2022`,`20 May 2024`],answer:3,explanation:`20 May 2024. It had been signed at the 5th Summit on 30 March 2022.`},{id:`T21`,label:`Pattern-Based – Reconstructed`,stem:`<p>Read the statements about BIMSTEC.</p>
<ol>
<li>Nepal and Bhutan joined it in 2004.</li>
<li>Myanmar and Thailand are also members of ASEAN.</li>
<li>Pakistan is one of its members.</li>
</ol>
<p>Which statements are correct?</p>
`,options:[`1 and 2 only`,`1 and 3 only`,`2 and 3 only`,`1, 2 and 3`],answer:0,explanation:`Statement 3 is wrong. Pakistan, Afghanistan and the Maldives are in SAARC but not in BIMSTEC.`},{id:`T22`,label:`Expected – Practice`,stem:`<p>In which city is the Secretariat of ASEAN?</p>
`,options:[`Bangkok`,`Manila`,`Kuala Lumpur`,`Jakarta`],answer:3,explanation:`Jakarta, Indonesia. ASEAN was founded in Bangkok.`},{id:`T23`,label:`Pattern-Based – Reconstructed`,stem:`<p>Match the body with its head in November 2026.</p>
<div class="tw"><table>
<thead>
<tr>
<th>Body</th>
<th>Head</th>
</tr>
</thead>
<tbody>
<tr>
<td>A. World Bank</td>
<td>1. Masato Kanda</td>
</tr>
<tr>
<td>B. International Monetary Fund</td>
<td>2. Dr Tedros Adhanom Ghebreyesus</td>
</tr>
<tr>
<td>C. Asian Development Bank</td>
<td>3. Ajay Banga</td>
</tr>
<tr>
<td>D. World Health Organization</td>
<td>4. Kristalina Georgieva</td>
</tr>
</tbody>
</table></div>
`,options:[`A-4, B-3, C-1, D-2`,`A-3, B-4, C-1, D-2`,`A-3, B-4, C-2, D-1`,`A-1, B-4, C-3, D-2`],answer:1,explanation:`Ajay Banga leads the World Bank, Kristalina Georgieva the Fund, Masato Kanda the Asian Development Bank and Dr Tedros the World Health Organization. 🔄`},{id:`T24`,label:`Pattern-Based – Reconstructed`,stem:`<p>Which of these is NOT an institution of the World Bank Group?</p>
`,options:[`International Development Association`,`International Finance Corporation`,`Multilateral Investment Guarantee Agency`,`International Fund for Agricultural Development`],answer:3,explanation:`The International Fund for Agricultural Development is a separate specialised agency in Rome. The Group's five are IBRD, IDA, IFC, MIGA and ICSID.`},{id:`T25`,label:`Expected – Practice`,stem:`<p>Which day is kept as World Food Day, the founding day of the Food and Agriculture Organization?</p>
`,options:[`7 April`,`5 June`,`16 October`,`24 October`],answer:2,explanation:`16 October. 7 April is World Health Day, 5 June World Environment Day and 24 October United Nations Day.`}]}]},{num:9,title:`Current Affairs`,nep:`समसामयिक गतिविधि`,slug:`part-13-chapter-09-current-affairs`,topics:[{id:`9.1`,title:`National politics and governance (राष्ट्रिय राजनीति र शासन)`,questions:[{id:`Q 9.1.1`,label:`Pattern-Based – Reconstructed`,stem:`<p>Arrange these events in order of time, the earliest first.</p>
<ol>
<li>Sushila Karki becomes interim Prime Minister</li>
<li>Election to the House of Representatives</li>
<li>The government orders social-media platforms to be blocked</li>
<li>Balendra Shah is sworn in as Prime Minister</li>
</ol>
`,options:[`1, 3, 2, 4`,`3, 2, 1, 4`,`3, 1, 2, 4`,`1, 2, 3, 4`],answer:2,explanation:`The block was ordered on 19 Bhadra 2082; Sushila Karki took office on 27 Bhadra 2082; the election was on 21 Falgun 2082; Balendra Shah took the oath on 13 Chaitra 2082.`},{id:`Q 9.1.2`,label:`Expected – Practice`,stem:`<p>Who chaired the commission that inquired into the events of 23 and 24 Bhadra 2082?</p>
`,options:[`Gauri Bahadur Karki`,`Sushila Karki`,`Man Bahadur Karki`,`Asim Shah`],answer:0,explanation:`Gauri Bahadur Karki, a former judge of the Special Court. The commission was formed on 5 Ashoj 2082 and reported on 24 Falgun 2082.`},{id:`Q 9.1.3`,label:`Pattern-Based – Reconstructed`,stem:`<p>Consider these statements about the election of 21 Falgun 2082.</p>
<ol>
<li>The Rastriya Swatantra Party won 182 seats.</li>
<li>That number is a two-thirds majority of the House of Representatives.</li>
<li>The Nepali Congress came second with 38 seats.</li>
</ol>
<p>Which of them are correct?</p>
`,options:[`1 only`,`1 and 3 only`,`2 and 3 only`,`1, 2 and 3`],answer:1,explanation:`Statement 2 is wrong. Two-thirds of 275 is 184, so 182 is a simple majority only.`},{id:`Q 9.1.4`,label:`Pattern-Based – Reconstructed`,stem:`<p>Match the office with its holder in Kartik 2083.</p>
<div class="tw"><table>
<thead>
<tr>
<th>Office</th>
<th>Holder</th>
</tr>
</thead>
<tbody>
<tr>
<td>A. Speaker of the House of Representatives</td>
<td>1. Man Bahadur Karki</td>
</tr>
<tr>
<td>B. Chief Justice</td>
<td>2. Dol Prasad Aryal</td>
</tr>
<tr>
<td>C. Chief Election Commissioner</td>
<td>3. Govinda Bahadur Karki</td>
</tr>
<tr>
<td>D. Chief Secretary</td>
<td>4. Dr Manoj Kumar Sharma</td>
</tr>
</tbody>
</table></div>
`,options:[`A-2, B-1, C-4, D-3`,`A-4, B-2, C-1, D-3`,`A-2, B-4, C-3, D-1`,`A-2, B-4, C-1, D-3`],answer:3,explanation:`Dol Prasad Aryal is Speaker, Dr Manoj Kumar Sharma is Chief Justice, Man Bahadur Karki is Chief Election Commissioner and Govinda Bahadur Karki is Chief Secretary.`},{id:`Q 9.1.5`,label:`Pattern-Based – Reconstructed`,stem:`<p>Three of these persons were ministers in the Council of Ministers listed on 26 Jestha 2083. Which one was <strong>not</strong>?</p>
`,options:[`Dr Swarnim Wagle`,`Rabi Lamichhane`,`Mahabir Pun`,`Sobita Gautam`],answer:1,explanation:`Rabi Lamichhane is president of the Rastriya Swatantra Party; he was not in the list of ministers. Wagle holds Finance, Pun holds Science, Technology and Innovation, and Gautam holds Law.`}]},{id:`9.2`,title:`Economy and development (अर्थतन्त्र र विकास)`,questions:[{id:`Q 9.2.1`,label:`Expected – Practice`,stem:`<p>What happened to Nepal at the meeting of the Financial Action Task Force that ended on 30 October 2026?</p>
`,options:[`It was removed from the grey list`,`It was moved to the black list`,`It stayed on the grey list`,`It was put on the grey list for the first time`],answer:2,explanation:`Nepal has been on the grey list since February 2025 and stayed on it after the reviews of June and October 2026.`},{id:`Q 9.2.2`,label:`Pattern-Based – Reconstructed`,stem:`<p>Fill in the blank. The contractor named in the corruption cases on the building of Pokhara International Airport is ______.</p>
`,options:[`China CAMC Engineering`,`Hazama Ando Corporation`,`Larsen and Toubro`,`Korea Expressway Corporation`],answer:0,explanation:`China CAMC Engineering built the airport under a Chinese loan. Three cases about the construction have been filed in the Special Court.`},{id:`Q 9.2.3`,label:`Pattern-Based – Reconstructed`,stem:`<p>Consider these statements about the effect on Nepal of the war that began in the Gulf in Falgun 2082.</p>
<ol>
<li>The government announced two weekly public holidays to save fuel.</li>
<li>Labour approvals for the Gulf were stopped for a time.</li>
<li>Remittance in 2082/83 fell below the level of the year before.</li>
</ol>
<p>Which of them are correct?</p>
`,options:[`1 only`,`2 and 3 only`,`1, 2 and 3`,`1 and 2 only`],answer:3,explanation:`Statement 3 is wrong. Remittance rose by 37.1 percent in 2082/83, to Rs 2,363.13 billion.`},{id:`Q 9.2.4`,label:`Pattern-Based – Reconstructed`,stem:`<p>Match the item with its figure in Rs billion.</p>
<div class="tw"><table>
<thead>
<tr>
<th>Item</th>
<th>Figure</th>
</tr>
</thead>
<tbody>
<tr>
<td>A. Federal budget for 2083/84</td>
<td>1. about 408</td>
</tr>
<tr>
<td>B. Remittance in 2082/83</td>
<td>2. about 292</td>
</tr>
<tr>
<td>C. The seven provincial budgets for 2083/84 together</td>
<td>3. 2,363.13</td>
</tr>
<tr>
<td>D. Loss from the Bhote Koshi flood</td>
<td>4. 2,124.34</td>
</tr>
</tbody>
</table></div>
`,options:[`A-3, B-4, C-2, D-1`,`A-4, B-3, C-1, D-2`,`A-4, B-3, C-2, D-1`,`A-4, B-2, C-3, D-1`],answer:2,explanation:`The budget is Rs 2,124.34 billion, remittance Rs 2,363.13 billion, the provincial budgets about Rs 292 billion and the flood loss about Rs 408 billion.`},{id:`Q 9.2.5`,label:`Expected – Practice`,stem:`<p>Who took office as Chief Secretary of the Government of Nepal on 26 Ashad 2083?</p>
`,options:[`Suman Raj Aryal`,`Govinda Bahadur Karki`,`Man Bahadur Karki`,`Madhav Belbase`],answer:1,explanation:`Govinda Bahadur Karki, the 30th Chief Secretary. Suman Raj Aryal retired the day before.`}]},{id:`9.3`,title:`International events (अन्तर्राष्ट्रिय घटना)`,questions:[{id:`Q 9.3.1`,label:`Expected – Practice`,stem:`<p>Who was named Supreme Leader of Iran in March 2026?</p>
`,options:[`Masoud Pezeshkian`,`Abbas Araghchi`,`Hassan Rouhani`,`Mojtaba Khamenei`],answer:3,explanation:`Mojtaba Khamenei, son of Ali Khamenei, who was killed when the war began on 28 February 2026.`},{id:`Q 9.3.2`,label:`Pattern-Based – Reconstructed`,stem:`<p>Match the country with the leader whose party won its parliamentary election in 2026.</p>
<div class="tw"><table>
<thead>
<tr>
<th>Country</th>
<th>Leader</th>
</tr>
</thead>
<tbody>
<tr>
<td>A. Bangladesh</td>
<td>1. Péter Magyar</td>
</tr>
<tr>
<td>B. Hungary</td>
<td>2. Sanae Takaichi</td>
</tr>
<tr>
<td>C. Japan</td>
<td>3. Balendra Shah</td>
</tr>
<tr>
<td>D. Nepal</td>
<td>4. Tarique Rahman</td>
</tr>
</tbody>
</table></div>
`,options:[`A-4, B-1, C-2, D-3`,`A-4, B-2, C-1, D-3`,`A-1, B-4, C-2, D-3`,`A-3, B-1, C-2, D-4`],answer:0,explanation:`Tarique Rahman (Bangladesh, 12 February), Péter Magyar (Hungary, 12 April), Sanae Takaichi (Japan, 8 February) and Balendra Shah (Nepal, 5 March).`},{id:`Q 9.3.3`,label:`Pattern-Based – Reconstructed`,stem:`<p>Consider these statements about meetings held in 2026.</p>
<ol>
<li>The 18th BRICS summit met in New Delhi.</li>
<li>The G7 summit met at Évian in France.</li>
<li>The climate conference COP31 met at Belém in Brazil.</li>
</ol>
<p>Which of them are correct?</p>
`,options:[`1 only`,`1 and 2 only`,`2 and 3 only`,`1, 2 and 3`],answer:1,explanation:`Statement 3 is wrong. COP31 met at Antalya in Türkiye; Belém held COP30 in 2025.`},{id:`Q 9.3.4`,label:`Pattern-Based – Reconstructed`,stem:`<p>Fill in the blank. In the election of 27 October 2026 in Israel, no side won the ______ seats needed for a majority in the Knesset.</p>
`,options:[`51`,`76`,`61`,`91`],answer:2,explanation:`The Knesset has 120 seats, so 61 make a majority. The two blocs won 53 and 48.`},{id:`Q 9.3.5`,label:`Expected – Practice`,stem:`<p>In January 2026 a military operation of the United States captured the President of which country?</p>
`,options:[`Venezuela`,`Cuba`,`Colombia`,`Nicaragua`],answer:0,explanation:`Venezuela. President Nicolás Maduro was captured.`}]},{id:`9.4`,title:`Science, technology, health and environment (विज्ञान, प्रविधि, स्वास्थ्य र वातावरण)`,questions:[{id:`Q 9.4.1`,label:`Pattern-Based – Reconstructed`,stem:`<p>Consider these statements.</p>
<ol>
<li>Artemis II was the first flight of people beyond low earth orbit since Apollo 17 in 1972.</li>
<li>China's Chang'e-7 landed at the south pole of the Moon in August 2026.</li>
<li>Starlink received a licence to work in Nepal in 2026.</li>
</ol>
<p>Which of them are correct?</p>
`,options:[`1 only`,`1 and 2 only`,`1 and 3 only`,`1, 2 and 3`],answer:0,explanation:`The launch of Chang'e-7 was called off on 23 August 2026, and Starlink had no licence in Nepal up to October 2026.`},{id:`Q 9.4.2`,label:`Expected – Practice`,stem:`<p>The outbreak of hantavirus reported to the World Health Organization on 2 May 2026 took place:</p>
`,options:[`in a refugee camp`,`in a mine`,`on a cruise ship`,`in a hospital`],answer:2,explanation:`On the cruise ship MV Hondius. The cause was the Andes virus; 13 cases and 3 deaths were reported by 27 May 2026.`},{id:`Q 9.4.3`,label:`Pattern-Based – Reconstructed`,stem:`<p>Match the Nobel Prize of 2026 with its winner.</p>
<div class="tw"><table>
<thead>
<tr>
<th>Prize</th>
<th>Winner</th>
</tr>
</thead>
<tbody>
<tr>
<td>A. Physiology or Medicine</td>
<td>1. Francis Halzen</td>
</tr>
<tr>
<td>B. Physics</td>
<td>2. Robert E. Hall and Michael Woodford</td>
</tr>
<tr>
<td>C. Chemistry</td>
<td>3. Karl Deisseroth, Peter Hegemann and Georg Nagel</td>
</tr>
<tr>
<td>D. Economics</td>
<td>4. Henri B. Kagan and Kenso Soai</td>
</tr>
</tbody>
</table></div>
`,options:[`A-3, B-4, C-1, D-2`,`A-4, B-1, C-3, D-2`,`A-3, B-1, C-2, D-4`,`A-3, B-1, C-4, D-2`],answer:3,explanation:`Medicine: Deisseroth, Hegemann and Nagel. Physics: Halzen. Chemistry: Kagan and Soai. Economics: Hall and Woodford.`},{id:`Q 9.4.4`,label:`Pattern-Based – Reconstructed`,stem:`<p>Fill in the blank. The earthquake of 23 Bhadra 2083, which damaged hundreds of houses near Lo Manthang, had a magnitude of ______.</p>
`,options:[`6.4`,`7.8`,`4.9`,`5.9`],answer:2,explanation:`4.9. No one was killed, but many mud-and-stone houses of Upper Mustang were damaged.`},{id:`Q 9.4.5`,label:`Pattern-Based – Reconstructed`,stem:`<p>Three of these astronauts flew on Artemis II. Which one did <strong>not</strong>?</p>
`,options:[`Reid Wiseman`,`Sunita Williams`,`Christina Koch`,`Jeremy Hansen`],answer:1,explanation:`Sunita Williams was not in the crew. The fourth member was Victor Glover.`}]},{id:`9.5`,title:`Sports (खेलकुद)`,questions:[{id:`Q 9.5.1`,label:`Expected – Practice`,stem:`<p>Which country won the FIFA World Cup of 2026?</p>
`,options:[`Argentina`,`Spain`,`France`,`England`],answer:1,explanation:`Spain beat Argentina 1–0 after extra time on 19 July 2026. It was Spain's second title.`},{id:`Q 9.5.2`,label:`Pattern-Based – Reconstructed`,stem:`<p>Match the competition with its winner.</p>
<div class="tw"><table>
<thead>
<tr>
<th>Competition</th>
<th>Winner</th>
</tr>
</thead>
<tbody>
<tr>
<td>A. Men's T20 World Cup 2026</td>
<td>1. Australia</td>
</tr>
<tr>
<td>B. Women's T20 World Cup 2026</td>
<td>2. Lumbini Lions</td>
</tr>
<tr>
<td>C. FIFA World Cup 2026</td>
<td>3. India</td>
</tr>
<tr>
<td>D. Nepal Premier League, second season</td>
<td>4. Spain</td>
</tr>
</tbody>
</table></div>
`,options:[`A-1, B-3, C-4, D-2`,`A-3, B-1, C-2, D-4`,`A-3, B-1, C-4, D-2`,`A-3, B-4, C-1, D-2`],answer:2,explanation:`India won the men's T20 World Cup, Australia the women's, Spain the football World Cup and Lumbini Lions the second season of the Nepal Premier League.`},{id:`Q 9.5.3`,label:`Pattern-Based – Reconstructed`,stem:`<p>Consider these statements about the 20th Asian Games.</p>
<ol>
<li>They were held at Aichi–Nagoya in Japan.</li>
<li>Nepal won two bronze medals.</li>
<li>Nepal's medals came in athletics and swimming.</li>
</ol>
<p>Which of them are correct?</p>
`,options:[`1 and 2 only`,`2 and 3 only`,`1 only`,`1, 2 and 3`],answer:0,explanation:`Statement 3 is wrong. The medals came in karate (Tenzing Sherpa) and women's kabaddi.`},{id:`Q 9.5.4`,label:`Pattern-Based – Reconstructed`,stem:`<p>Fill in the blank. When Kami Rita Sherpa reached the top of Sagarmatha on 3 Jestha 2083, it was his ______ ascent.</p>
`,options:[`29th`,`30th`,`31st`,`32nd`],answer:3,explanation:`The 32nd, the most by any person. He first climbed the mountain in 1994.`},{id:`Q 9.5.5`,label:`Expected – Practice`,stem:`<p>Against which team did Nepal win its first T20 series over a full member of the International Cricket Council, at Sharjah in Ashoj 2082?</p>
`,options:[`West Indies`,`Zimbabwe`,`Ireland`,`Afghanistan`],answer:0,explanation:`The West Indies. Nepal won on 27 and 29 September 2025 and took the series with a match to spare.`}]},{id:`9.6`,title:`Awards, books and persons in the news (पुरस्कार, पुस्तक र चर्चित व्यक्ति)`,questions:[{id:`Q 9.6.1`,label:`Expected – Practice`,stem:`<p>Who won the Booker Prize of 2026?</p>
`,options:[`M. John Harrison`,`David Szalay`,`Douglas Stuart`,`Anne Carson`],answer:0,explanation:`M. John Harrison, for <em>The End of Everything</em>. David Szalay won in 2025; Anne Carson won the Nobel Prize in Literature of 2026.`},{id:`Q 9.6.2`,label:`Pattern-Based – Reconstructed`,stem:`<p>Match the prize of 2026 with its winner.</p>
<div class="tw"><table>
<thead>
<tr>
<th>Prize</th>
<th>Winner</th>
</tr>
</thead>
<tbody>
<tr>
<td>A. Nobel Peace Prize</td>
<td>1. Yáng Shuāng-zǐ</td>
</tr>
<tr>
<td>B. Nobel Prize in Literature</td>
<td>2. M. John Harrison</td>
</tr>
<tr>
<td>C. Booker Prize</td>
<td>3. Navi Pillay</td>
</tr>
<tr>
<td>D. International Booker Prize</td>
<td>4. Anne Carson</td>
</tr>
</tbody>
</table></div>
`,options:[`A-4, B-3, C-2, D-1`,`A-3, B-4, C-1, D-2`,`A-3, B-2, C-4, D-1`,`A-3, B-4, C-2, D-1`],answer:3,explanation:`Peace: Navi Pillay. Literature: Anne Carson. Booker: M. John Harrison. International Booker: Yáng Shuāng-zǐ.`},{id:`Q 9.6.3`,label:`Pattern-Based – Reconstructed`,stem:`<p>Consider these statements.</p>
<ol>
<li>The Madan Puraskar for 2082 went to Bina Joshi (Rajbhandari).</li>
<li>The Jagadamba Shree for 2082 went to the lyricist Kiran Kharel.</li>
<li>Kumar Nagarkoti was appointed Chancellor of the Nepal Academy in Shrawan 2083.</li>
</ol>
<p>Which of them are correct?</p>
`,options:[`1 only`,`1 and 2 only`,`1, 2 and 3`,`2 and 3 only`],answer:2,explanation:`All three are correct. The two prizes were announced on 21 Bhadra 2083; the Chancellor was named on 20 Shrawan 2083.`},{id:`Q 9.6.4`,label:`Pattern-Based – Reconstructed`,stem:`<p>Three of these persons won the Ramon Magsaysay Award of 2026. Which one did <strong>not</strong>?</p>
`,options:[`Tommy Koh`,`Navi Pillay`,`Runa Khan`,`Bo Kyi`],answer:1,explanation:`Navi Pillay won the Nobel Peace Prize of 2026. The Magsaysay Award went to Tommy Koh, Runa Khan and Bo Kyi.`},{id:`Q 9.6.5`,label:`Expected – Practice`,stem:`<p>Nirmal Purja, who died on Broad Peak on 30 July 2026, was best known for:</p>
`,options:[`the most ascents of Sagarmatha`,`the first ascent of Sagarmatha without bottled oxygen`,`skiing down from the top of Sagarmatha`,`climbing all fourteen peaks above 8,000 metres in about six months`],answer:3,explanation:`In 2019 he climbed the fourteen peaks in 189 days. The most ascents of Sagarmatha belong to Kami Rita Sherpa.`}]},{id:`9.7`,title:`Province-wise events (प्रदेशगत घटना)`,questions:[{id:`Q 9.7.1`,label:`Pattern-Based – Reconstructed`,stem:`<p>Match the province with its Chief Minister in Kartik 2083.</p>
<div class="tw"><table>
<thead>
<tr>
<th>Province</th>
<th>Chief Minister</th>
</tr>
</thead>
<tbody>
<tr>
<td>A. Bagmati</td>
<td>1. Khagaraj Bhatta</td>
</tr>
<tr>
<td>B. Karnali</td>
<td>2. Krishna Prasad Yadav</td>
</tr>
<tr>
<td>C. Sudurpashchim</td>
<td>3. Kiran Thapa Magar</td>
</tr>
<tr>
<td>D. Madhesh</td>
<td>4. Mangal Bahadur Shahi</td>
</tr>
</tbody>
</table></div>
`,options:[`A-3, B-1, C-4, D-2`,`A-3, B-4, C-1, D-2`,`A-4, B-3, C-1, D-2`,`A-3, B-4, C-2, D-1`],answer:1,explanation:`Kiran Thapa Magar leads Bagmati, Mangal Bahadur Shahi Karnali, Khagaraj Bhatta Sudurpashchim and Krishna Prasad Yadav Madhesh.`},{id:`Q 9.7.2`,label:`Expected – Practice`,stem:`<p>Which party leads the provincial governments of both Karnali and Sudurpashchim in Kartik 2083?</p>
`,options:[`Nepali Communist Party`,`CPN (UML)`,`Nepali Congress`,`Rastriya Swatantra Party`],answer:0,explanation:`The Nepali Communist Party: Mangal Bahadur Shahi in Karnali and Khagaraj Bhatta in Sudurpashchim. No Chief Minister belongs to the Rastriya Swatantra Party.`},{id:`Q 9.7.3`,label:`Pattern-Based – Reconstructed`,stem:`<p>Consider these statements.</p>
<ol>
<li>The communal violence of Shrawan 2083 began in Sunsari.</li>
<li>The earthquake of 23 Bhadra 2083 in Mustang killed more than a hundred people.</li>
<li>The Tenth National Games are to be held in Karnali Province.</li>
</ol>
<p>Which of them are correct?</p>
`,options:[`1 only`,`1 and 2 only`,`1 and 3 only`,`1, 2 and 3`],answer:2,explanation:`Statement 2 is wrong. The Mustang earthquake damaged hundreds of houses but killed no one.`},{id:`Q 9.7.4`,label:`Pattern-Based – Reconstructed`,stem:`<p>Fill in the blank. Koshi Province chose 25 Kartik 2083, the birthday of ______, to begin the official use of 13 provincial languages.</p>
`,options:[`Bhanubhakta Acharya`,`Pasang Lhamu Sherpa`,`Bhimsen Thapa`,`Mahaguru Phalgunanda`],answer:3,explanation:`Mahaguru Phalgunanda, the Kirat religious reformer and national hero.`},{id:`Q 9.7.5`,label:`Expected – Practice`,stem:`<p>Rasuwa, Nuwakot and Dhading, the districts struck by the flood of 10 Bhadra 2083, are in which province?</p>
`,options:[`Gandaki`,`Koshi`,`Lumbini`,`Bagmati`],answer:3,explanation:`Bagmati. The flood came down the Bhote Koshi and the Trishuli from the border at Rasuwagadhi.`}]},{id:`9.8`,title:`National and international days and themes (राष्ट्रिय तथा अन्तर्राष्ट्रिय दिवस र नारा)`,questions:[{id:`Q 9.8.1`,label:`Pattern-Based – Reconstructed`,stem:`<p>Match the day with its date.</p>
<div class="tw"><table>
<thead>
<tr>
<th>Day</th>
<th>Date</th>
</tr>
</thead>
<tbody>
<tr>
<td>A. World Health Day</td>
<td>1. 27 September</td>
</tr>
<tr>
<td>B. World Environment Day</td>
<td>2. 21 June</td>
</tr>
<tr>
<td>C. International Day of Yoga</td>
<td>3. 7 April</td>
</tr>
<tr>
<td>D. World Tourism Day</td>
<td>4. 5 June</td>
</tr>
</tbody>
</table></div>
`,options:[`A-3, B-4, C-2, D-1`,`A-4, B-3, C-2, D-1`,`A-3, B-4, C-1, D-2`,`A-3, B-2, C-4, D-1`],answer:0,explanation:`World Health Day is 7 April, World Environment Day 5 June, the International Day of Yoga 21 June and World Tourism Day 27 September.`},{id:`Q 9.8.2`,label:`Expected – Practice`,stem:`<p>What was the United Nations theme of International Women's Day 2026?</p>
`,options:[`Yoga for Healthy Ageing`,`Resilience Starts at Home`,`Rights. Justice. Action. For ALL Women and Girls.`,`Innovate Today. Nourish Tomorrow.`],answer:2,explanation:`The other three are the themes of the International Day of Yoga, the International Day for Disaster Risk Reduction and World Food Day in 2026.`},{id:`Q 9.8.3`,label:`Pattern-Based – Reconstructed`,stem:`<p>The United Nations named 2026 the International Year of:</p>
<ol>
<li>the Woman Farmer</li>
<li>Rangelands and Pastoralists</li>
<li>Cooperatives</li>
</ol>
<p>Which of them are correct?</p>
`,options:[`1 only`,`1 and 2 only`,`2 and 3 only`,`1, 2 and 3`],answer:1,explanation:`The International Year of Cooperatives was 2025. The third year of 2026 is the International Year of Volunteers for Sustainable Development.`},{id:`Q 9.8.4`,label:`Pattern-Based – Reconstructed`,stem:`<p>Fill in the blank. The official host of World Tourism Day 2026 was ______.</p>
`,options:[`Malaysia`,`Azerbaijan`,`Kenya`,`El Salvador`],answer:3,explanation:`El Salvador. Malaysia hosted the day in 2025; Azerbaijan hosted World Environment Day 2026; Kenya hosted Desertification and Drought Day 2026.`},{id:`Q 9.8.5`,label:`Pattern-Based – Reconstructed`,stem:`<p>Which of these pairs for the year 2026 is <strong>wrongly</strong> matched?</p>
`,options:[`World Health Day — &quot;Together for health. Stand with science.&quot;`,`World Environment Day — host: Republic of Korea`,`International Day of Yoga — &quot;Yoga for Healthy Ageing&quot;`,`World Food Day — &quot;Innovate Today. Nourish Tomorrow.&quot;`],answer:1,explanation:`Azerbaijan hosted World Environment Day in 2026. The Republic of Korea was the host in 2025.`}]},{id:`T`,title:`End-of-chapter test — Top 25`,questions:[{id:`T1`,label:`Expected – Practice`,stem:`<p>Of the 182 seats won by the Rastriya Swatantra Party in the election of 21 Falgun 2082, how many were first-past-the-post seats?</p>
`,options:[`125`,`110`,`57`,`165`],answer:0,explanation:`125 direct seats and 57 proportional seats. The House has 165 direct and 110 proportional seats in all.`},{id:`T2`,label:`Pattern-Based – Reconstructed`,stem:`<p>Consider these statements about the interim government of 2082.</p>
<ol>
<li>Sushila Karki was the first woman to become Prime Minister of Nepal.</li>
<li>She took office on 27 Bhadra 2082.</li>
<li>The election to the House of Representatives was held within six months of that day.</li>
</ol>
<p>Which of them are correct?</p>
`,options:[`1 only`,`1 and 2 only`,`2 and 3 only`,`1, 2 and 3`],answer:3,explanation:`All three are correct. From 27 Bhadra 2082 (12 September 2025) to the election of 21 Falgun 2082 (5 March 2026) is less than six months.`},{id:`T3`,label:`Pattern-Based – Reconstructed`,stem:`<p>Fill in the blank. With 182 seats, the Rastriya Swatantra Party is ______ short of a two-thirds majority in the House of Representatives.</p>
`,options:[`1 seat`,`2 seats`,`4 seats`,`12 seats`],answer:1,explanation:`Two-thirds of 275 is 184, so the party is two seats short and cannot amend the Constitution alone.`},{id:`T4`,label:`Expected – Practice`,stem:`<p>Who has been Minister for Science, Technology and Innovation since the reshuffle of 26 Jestha 2083?</p>
`,options:[`Sasmit Pokharel`,`Dr Bikram Timilsina`,`Mahabir Pun`,`Sunil Lamsal`],answer:2,explanation:`Mahabir Pun, winner of the Ramon Magsaysay Award of 2007. Pokharel holds Education and Sports, Timilsina holds Information and Communication, and Lamsal holds Infrastructure Development.`},{id:`T5`,label:`Pattern-Based – Reconstructed`,stem:`<p>Match the date with the event.</p>
<div class="tw"><table>
<thead>
<tr>
<th>Date</th>
<th>Event</th>
</tr>
</thead>
<tbody>
<tr>
<td>A. 13 Chaitra 2082</td>
<td>1. Budget for 2083/84 presented</td>
</tr>
<tr>
<td>B. 15 Jestha 2083</td>
<td>2. Prime Minister addresses the General Assembly of the United Nations</td>
</tr>
<tr>
<td>C. 10 Bhadra 2083</td>
<td>3. Balendra Shah sworn in as Prime Minister</td>
</tr>
<tr>
<td>D. 8 Ashoj 2083</td>
<td>4. Bhote Koshi flood</td>
</tr>
</tbody>
</table></div>
`,options:[`A-3, B-1, C-4, D-2`,`A-1, B-3, C-4, D-2`,`A-3, B-1, C-2, D-4`,`A-3, B-4, C-1, D-2`],answer:0,explanation:`The oath was on 13 Chaitra 2082, the budget on 15 Jestha 2083, the flood on 10 Bhadra 2083 and the address on 8 Ashoj 2083.`},{id:`T6`,label:`Expected – Practice`,stem:`<p>Whom did the Council of Ministers name as the 34th Inspector General of Police on 18 Kartik 2083?</p>
`,options:[`Dan Bahadur Karki`,`Govinda Bahadur Karki`,`Ashok Raj Sigdel`,`Manoj KC`],answer:3,explanation:`Manoj KC. Dan Bahadur Karki was the 33rd; Govinda Bahadur Karki is Chief Secretary; General Ashok Raj Sigdel heads the Army.`},{id:`T7`,label:`Pattern-Based – Reconstructed`,stem:`<p>Consider these statements.</p>
<ol>
<li>The monetary policy for 2083/84 is the 25th monetary policy of Nepal Rastra Bank.</li>
<li>Nepal was removed from the grey list of the Financial Action Task Force in June 2026.</li>
<li>Nepal received 1,158,459 foreign tourists in 2025.</li>
</ol>
<p>Which of them are correct?</p>
`,options:[`1 only`,`1 and 3 only`,`2 and 3 only`,`1, 2 and 3`],answer:1,explanation:`Statement 2 is wrong. Nepal stayed on the grey list after the reviews of June and October 2026.`},{id:`T8`,label:`Pattern-Based – Reconstructed`,stem:`<p>Arrange these events of 2026 in order of time, the earliest first.</p>
<ol>
<li>Bhote Koshi flood</li>
<li>Two weekly public holidays announced</li>
<li>Nagdhunga tunnel opened</li>
<li>Budget for 2083/84 presented</li>
</ol>
`,options:[`2, 3, 4, 1`,`4, 2, 3, 1`,`2, 4, 3, 1`,`2, 4, 1, 3`],answer:2,explanation:`The holidays were announced on 5 April, the budget came on 29 May, the tunnel opened on 27 July and the flood struck on 26 August 2026.`},{id:`T9`,label:`Expected – Practice`,stem:`<p>The war that began on 28 February 2026 was fought by the United States and Israel against which country?</p>
`,options:[`Iran`,`Iraq`,`Syria`,`Yemen`],answer:0,explanation:`Iran. Supreme Leader Ali Khamenei was killed, and Iran closed the Strait of Hormuz.`},{id:`T10`,label:`Pattern-Based – Reconstructed`,stem:`<p>Match the meeting of 2026 with its place.</p>
<div class="tw"><table>
<thead>
<tr>
<th>Meeting</th>
<th>Place</th>
</tr>
</thead>
<tbody>
<tr>
<td>A. G7 summit</td>
<td>1. New Delhi</td>
</tr>
<tr>
<td>B. 18th BRICS summit</td>
<td>2. Miami</td>
</tr>
<tr>
<td>C. Climate conference COP31</td>
<td>3. Évian</td>
</tr>
<tr>
<td>D. G20 summit</td>
<td>4. Antalya</td>
</tr>
</tbody>
</table></div>
`,options:[`A-1, B-3, C-4, D-2`,`A-3, B-1, C-4, D-2`,`A-3, B-1, C-2, D-4`,`A-4, B-1, C-3, D-2`],answer:1,explanation:`G7 at Évian in France, BRICS at New Delhi, COP31 at Antalya in Türkiye, and the G20 at Miami in December.`},{id:`T11`,label:`Pattern-Based – Reconstructed`,stem:`<p>Fill in the blank. On 3 June 2026 the General Assembly elected Austria, Kyrgyzstan, Portugal, Trinidad and Tobago and ______ to the Security Council for 2027–2028.</p>
`,options:[`Denmark`,`Somalia`,`Pakistan`,`Zimbabwe`],answer:3,explanation:`Zimbabwe. Denmark, Somalia and Pakistan are among the five members they replace.`},{id:`T12`,label:`Expected – Practice`,stem:`<p>Who became Prime Minister of Bangladesh on 17 February 2026?</p>
`,options:[`Khalilur Rahman`,`Muhammad Yunus`,`Tarique Rahman`,`Sheikh Hasina`],answer:2,explanation:`Tarique Rahman of the Bangladesh Nationalist Party, which won the election of 12 February 2026. Khalilur Rahman, also of Bangladesh, is President of the 81st session of the General Assembly.`},{id:`T13`,label:`Pattern-Based – Reconstructed`,stem:`<p>Consider these statements.</p>
<ol>
<li>An outbreak of hantavirus on a cruise ship was reported to the World Health Organization in May 2026.</li>
<li>The astronauts of Artemis II landed on the Moon.</li>
<li>Nepal counted 429 tigers in 2026.</li>
</ol>
<p>Which of them are correct?</p>
`,options:[`1 and 3 only`,`1 and 2 only`,`2 and 3 only`,`1, 2 and 3`],answer:0,explanation:`Statement 2 is wrong. Artemis II flew round the Moon and came back; it did not land.`},{id:`T14`,label:`Expected – Practice`,stem:`<p>Which country topped the medal table of the Winter Olympics of 2026?</p>
`,options:[`United States`,`Norway`,`Italy`,`Germany`],answer:1,explanation:`Norway, with 18 gold medals, a record for the Winter Games. The United States was second; Italy was the host.`},{id:`T15`,label:`Pattern-Based – Reconstructed`,stem:`<p>Match the person with the achievement.</p>
<div class="tw"><table>
<thead>
<tr>
<th>Person</th>
<th>Achievement</th>
</tr>
</thead>
<tbody>
<tr>
<td>A. Kami Rita Sherpa</td>
<td>1. Golden Boot of the FIFA World Cup 2026</td>
</tr>
<tr>
<td>B. Dipendra Singh Airee</td>
<td>2. Bronze medal in karate at the 20th Asian Games</td>
</tr>
<tr>
<td>C. Tenzing Sherpa</td>
<td>3. 32nd ascent of Sagarmatha</td>
</tr>
<tr>
<td>D. Kylian Mbappé</td>
<td>4. Player of the match against Scotland in the T20 World Cup</td>
</tr>
</tbody>
</table></div>
`,options:[`A-3, B-2, C-4, D-1`,`A-4, B-3, C-2, D-1`,`A-3, B-4, C-1, D-2`,`A-3, B-4, C-2, D-1`],answer:3,explanation:`Kami Rita Sherpa made his 32nd ascent; Airee was player of the match against Scotland; Tenzing Sherpa won bronze in karate; Mbappé won the Golden Boot with 10 goals.`},{id:`T16`,label:`Pattern-Based – Reconstructed`,stem:`<p>Fill in the blank. The runner-up in both of the first two seasons of the Nepal Premier League was ______.</p>
`,options:[`Sudurpaschim Royals`,`Janakpur Bolts`,`Lumbini Lions`,`Biratnagar Kings`],answer:0,explanation:`Sudurpaschim Royals were runners-up to Janakpur Bolts in the first season and to Lumbini Lions in the second.`},{id:`T17`,label:`Expected – Practice`,stem:`<p>Who won the men's Ballon d'Or of 2026?</p>
`,options:[`Ousmane Dembélé`,`Kylian Mbappé`,`Harry Kane`,`Rodri`],answer:2,explanation:`Harry Kane of England. Dembélé won in 2025. Among women, Alexia Putellas won for the third time.`},{id:`T18`,label:`Pattern-Based – Reconstructed`,stem:`<p>Three of these persons won a Nobel Prize in 2026. Which one did <strong>not</strong>?</p>
`,options:[`Anne Carson`,`M. John Harrison`,`Navi Pillay`,`Francis Halzen`],answer:1,explanation:`M. John Harrison won the Booker Prize of 2026. Carson won the Nobel Prize in Literature, Pillay the Peace Prize and Halzen the prize in Physics.`},{id:`T19`,label:`Expected – Practice`,stem:`<p>Who wrote <em>Taiwan Travelogue</em>, the book that won the International Booker Prize of 2026?</p>
`,options:[`Banu Mushtaq`,`David Szalay`,`Lin King`,`Yáng Shuāng-zǐ`],answer:3,explanation:`Yáng Shuāng-zǐ of Taiwan. Lin King translated the book into English. Banu Mushtaq won the International Booker Prize of 2025 and David Szalay the Booker Prize of 2025.`},{id:`T20`,label:`Pattern-Based – Reconstructed`,stem:`<p>Consider these statements.</p>
<ol>
<li>Aryatara Shakya was installed as the Kumari of Kathmandu in Ashoj 2082.</li>
<li>Nirmal Purja died in an avalanche on Sagarmatha.</li>
<li>Kumar Nagarkoti is Chancellor of the Nepal Academy.</li>
</ol>
<p>Which of them are correct?</p>
`,options:[`1 only`,`1 and 2 only`,`1 and 3 only`,`1, 2 and 3`],answer:2,explanation:`Statement 2 is wrong. Nirmal Purja died on Broad Peak in Pakistan, on 30 July 2026.`},{id:`T21`,label:`Pattern-Based – Reconstructed`,stem:`<p>Match the province with its budget for 2083/84, in Rs billion.</p>
<div class="tw"><table>
<thead>
<tr>
<th>Province</th>
<th>Budget</th>
</tr>
</thead>
<tbody>
<tr>
<td>A. Bagmati</td>
<td>1. 41.13</td>
</tr>
<tr>
<td>B. Madhesh</td>
<td>2. 35.40</td>
</tr>
<tr>
<td>C. Gandaki</td>
<td>3. 66.93</td>
</tr>
<tr>
<td>D. Karnali</td>
<td>4. 33.00</td>
</tr>
</tbody>
</table></div>
`,options:[`A-3, B-4, C-1, D-2`,`A-3, B-1, C-4, D-2`,`A-1, B-3, C-4, D-2`,`A-3, B-1, C-2, D-4`],answer:1,explanation:`Bagmati 66.93 (the largest), Madhesh 41.13, Gandaki 33.00 (the smallest) and Karnali 35.40.`},{id:`T22`,label:`Expected – Practice`,stem:`<p>In which district was the earthquake of 23 Bhadra 2083 centred?</p>
`,options:[`Mustang`,`Jajarkot`,`Dolakha`,`Gorkha`],answer:0,explanation:`Mustang, near Lo Manthang; the magnitude was 4.9 and no one was killed. Jajarkot was struck in 2080.`},{id:`T23`,label:`Pattern-Based – Reconstructed`,stem:`<p>Fill in the blank. The United Nations has named 2027 the International Year of ______.</p>
`,options:[`Cooperatives`,`Glaciers' Preservation`,`the Woman Farmer`,`Sustainable and Resilient Tourism`],answer:3,explanation:`Sustainable and Resilient Tourism. Cooperatives and Glaciers' Preservation were years of 2025; the Woman Farmer is a year of 2026.`},{id:`T24`,label:`Pattern-Based – Reconstructed`,stem:`<p>Match the day with its theme in 2026.</p>
<div class="tw"><table>
<thead>
<tr>
<th>Day</th>
<th>Theme</th>
</tr>
</thead>
<tbody>
<tr>
<td>A. World Health Day</td>
<td>1. &quot;Innovate Today. Nourish Tomorrow.&quot;</td>
</tr>
<tr>
<td>B. World Tourism Day</td>
<td>2. &quot;Together for health. Stand with science.&quot;</td>
</tr>
<tr>
<td>C. International Day of Yoga</td>
<td>3. &quot;Yoga for Healthy Ageing&quot;</td>
</tr>
<tr>
<td>D. World Food Day</td>
<td>4. &quot;Digital Agenda and Artificial Intelligence to Redesign Tourism&quot;</td>
</tr>
</tbody>
</table></div>
`,options:[`A-2, B-3, C-4, D-1`,`A-1, B-4, C-3, D-2`,`A-2, B-4, C-3, D-1`,`A-2, B-4, C-1, D-3`],answer:2,explanation:`Health Day: &quot;Together for health. Stand with science.&quot; Tourism Day: &quot;Digital Agenda and Artificial Intelligence to Redesign Tourism&quot;. Yoga: &quot;Yoga for Healthy Ageing&quot;. Food Day: &quot;Innovate Today. Nourish Tomorrow.&quot;`},{id:`T25`,label:`Pattern-Based – Reconstructed`,stem:`<p>Consider these statements about the days of Nepal.</p>
<ol>
<li>Gen Z Martyrs' Day falls on 23 Bhadra.</li>
<li>Constitution Day falls on 3 Ashoj.</li>
<li>Civil Service Day falls on 15 Jestha.</li>
</ol>
<p>Which of them are correct?</p>
`,options:[`1 only`,`1 and 2 only`,`2 and 3 only`,`1, 2 and 3`],answer:1,explanation:`Statement 3 is wrong. Civil Service Day is 22 Bhadra; 15 Jestha is Republic Day.`}]}]},{num:10,title:`Koshi Province`,nep:`कोशी प्रदेश`,slug:`part-14-chapter-10-koshi-province`,topics:[{id:`10.1`,title:`Profile of the province (प्रदेशको परिचय)`,questions:[{id:`Q 10.1.1`,label:`Expected – Practice`,stem:`<p>Koshi Province has 137 local levels. How many of them are rural municipalities (गाउँपालिका)?</p>
`,options:[`46`,`79`,`88`,`91`],answer:2,explanation:`88. The 137 are 1 metropolitan city, 2 sub-metropolitan cities, 46 municipalities and 88 rural municipalities.`},{id:`Q 10.1.2`,label:`Pattern-Based – Reconstructed`,stem:`<p>Consider these statements about the naming of Koshi Province.</p>
<ol>
<li>The Provincial Assembly passed the name on 17 Falgun 2079.</li>
<li>It was the last of the seven provinces to receive a name.</li>
<li>A simple majority of the members present is enough to name a province.</li>
</ol>
<p>Which of them are correct?</p>
`,options:[`1 and 2 only`,`2 and 3 only`,`1 only`,`1, 2 and 3`],answer:0,explanation:`Statement 3 is wrong. Article 295 (2) asks for two-thirds of all the members of the Provincial Assembly — 62 of 93 in Koshi. The name received 82 votes.`},{id:`Q 10.1.3`,label:`Pattern-Based – Reconstructed`,stem:`<p>Match the district with its headquarters.</p>
<div class="tw"><table>
<thead>
<tr>
<th>District</th>
<th>Headquarters</th>
</tr>
</thead>
<tbody>
<tr>
<td>A. Taplejung</td>
<td>1. Gaighat</td>
</tr>
<tr>
<td>B. Sankhuwasabha</td>
<td>2. Phungling</td>
</tr>
<tr>
<td>C. Udayapur</td>
<td>3. Myanglung</td>
</tr>
<tr>
<td>D. Terhathum</td>
<td>4. Khandbari</td>
</tr>
</tbody>
</table></div>
`,options:[`A–2, B–4, C–3, D–1`,`A–4, B–2, C–1, D–3`,`A–3, B–4, C–1, D–2`,`A–2, B–4, C–1, D–3`],answer:3,explanation:`Taplejung–Phungling, Sankhuwasabha–Khandbari, Udayapur–Gaighat, Terhathum–Myanglung.`},{id:`Q 10.1.4`,label:`Expected – Practice`,stem:`<p>Which district of Koshi Province has the largest area?</p>
`,options:[`Solukhumbu`,`Taplejung`,`Sankhuwasabha`,`Udayapur`],answer:1,explanation:`Taplejung, 3,646 sq km. Sankhuwasabha (3,480) and Solukhumbu (3,312) follow. The three mountain districts are the three largest.`},{id:`Q 10.1.5`,label:`Pattern-Based – Reconstructed`,stem:`<p>Three of these districts lie in Koshi Province. Which one is <strong>not</strong> in it?</p>
`,options:[`Okhaldhunga`,`Udayapur`,`Saptari`,`Khotang`],answer:2,explanation:`Saptari is in Madhesh Province. Saptari and Siraha belonged to the old Eastern Development Region, which is why they are often placed in Koshi by mistake.`}]},{id:`10.2`,title:`Physical geography (भौतिक भूगोल)`,questions:[{id:`Q 10.2.1`,label:`Expected – Practice`,stem:`<p>In which Himalayan range (हिमशृङ्खला) do Sagarmatha, Lhotse, Cho Oyu and Makalu stand?</p>
`,options:[`Kumbhakarna`,`Mahalangur`,`Rolwaling`,`Janak`],answer:1,explanation:`Mahalangur. Kanchenjunga and Jannu stand in the Kumbhakarna range, further east.`},{id:`Q 10.2.2`,label:`Pattern-Based – Reconstructed`,stem:`<p>Match the protected area with the district or districts in which it lies.</p>
<div class="tw"><table>
<thead>
<tr>
<th>Protected area</th>
<th>District</th>
</tr>
</thead>
<tbody>
<tr>
<td>A. Sagarmatha National Park</td>
<td>1. Taplejung</td>
</tr>
<tr>
<td>B. Makalu Barun National Park</td>
<td>2. Sunsari, Saptari and Udayapur</td>
</tr>
<tr>
<td>C. Kanchenjunga Conservation Area</td>
<td>3. Solukhumbu</td>
</tr>
<tr>
<td>D. Koshi Tappu Wildlife Reserve</td>
<td>4. Sankhuwasabha and Solukhumbu</td>
</tr>
</tbody>
</table></div>
`,options:[`A–3, B–1, C–4, D–2`,`A–4, B–3, C–1, D–2`,`A–3, B–4, C–2, D–1`,`A–3, B–4, C–1, D–2`],answer:3,explanation:`Sagarmatha–Solukhumbu; Makalu Barun–Sankhuwasabha and Solukhumbu; Kanchenjunga–Taplejung; Koshi Tappu–Sunsari, Saptari and Udayapur.`},{id:`Q 10.2.3`,label:`Expected – Practice`,stem:`<p>At which place do the Sunkoshi, the Arun and the Tamor meet to form the Saptakoshi?</p>
`,options:[`Tribeni, above Chatara`,`Devghat`,`Dolalghat`,`Bhimnagar`],answer:0,explanation:`Tribeni, where Dhankuta, Bhojpur and Udayapur meet. Devghat is on the Narayani; Dolalghat is where the Indrawati joins the Sunkoshi; the Koshi Barrage is near Bhimnagar.`},{id:`Q 10.2.4`,label:`Pattern-Based – Reconstructed`,stem:`<p>Consider these statements about the wetlands of Koshi Province.</p>
<ol>
<li>Koshi Tappu was Nepal's first Ramsar site, listed in 1987.</li>
<li>Mai Pokhari, a Ramsar site, lies in Ilam.</li>
<li>The Gokyo lakes, a Ramsar site, lie in Sankhuwasabha.</li>
</ol>
<p>Which of them are correct?</p>
`,options:[`1 only`,`2 and 3 only`,`1 and 2 only`,`1, 2 and 3`],answer:2,explanation:`Statement 3 is wrong. The Gokyo lakes are in Solukhumbu.`},{id:`Q 10.2.5`,label:`Expected – Practice`,stem:`<p>The Tinjure–Milke–Jaljale ridge, known for its rhododendron forest, lies on the borders of which three districts?</p>
`,options:[`Terhathum, Sankhuwasabha and Taplejung`,`Ilam, Panchthar and Jhapa`,`Bhojpur, Khotang and Solukhumbu`,`Dhankuta, Sunsari and Morang`],answer:0,explanation:`Terhathum, Sankhuwasabha and Taplejung. The ridge is called the &quot;capital of rhododendron&quot;.`}]},{id:`10.3`,title:`History and archaeology (इतिहास र पुरातत्त्व)`,questions:[{id:`Q 10.3.1`,label:`Expected – Practice`,stem:`<p>By what name is the oath of 1774 between the Gorkha state and the Limbu chiefs remembered?</p>
`,options:[`The Treaty of Betrawati`,`The copper-plate grant`,`The Treaty of Sugauli`,`The salt-water (नुन-पानी) treaty`],answer:3,explanation:`The salt-water treaty, sworn at Bijayapur. The Limbu chiefs accepted the king of Gorkha and kept their kipat land.`},{id:`Q 10.3.2`,label:`Pattern-Based – Reconstructed`,stem:`<p>Arrange these events in order of time, the earliest first.</p>
<ol>
<li>Biratnagar Jute Mill is founded</li>
<li>The Mechi becomes the eastern boundary of Nepal</li>
<li>The Koshi Agreement is signed with India</li>
<li>The province is named Koshi</li>
</ol>
`,options:[`1, 2, 3, 4`,`2, 1, 3, 4`,`2, 3, 1, 4`,`3, 2, 1, 4`],answer:1,explanation:`The Mechi boundary dates from 1816; the mill from 1936; the agreement from 1954; the name from 2023 (17 Falgun 2079).`},{id:`Q 10.3.3`,label:`Expected – Practice`,stem:`<p>Which town was the regional centre of the old Eastern Development Region?</p>
`,options:[`Biratnagar`,`Dharan`,`Dhankuta`,`Ilam`],answer:2,explanation:`Dhankuta. Biratnagar became a capital only with the province.`},{id:`Q 10.3.4`,label:`Pattern-Based – Reconstructed`,stem:`<p>Fill in the blank. The old Eastern Development Region had 16 districts. Fourteen of them form Koshi Province; the other two, ______, are in Madhesh Province.</p>
`,options:[`Siraha and Saptari`,`Saptari and Sunsari`,`Siraha and Udayapur`,`Dhanusha and Mahottari`],answer:0,explanation:`Siraha and Saptari, which belonged to the old Sagarmatha Zone.`},{id:`Q 10.3.5`,label:`Expected – Practice`,stem:`<p>The Kichakbadh site, where excavation found old brick structures, lies in which district?</p>
`,options:[`Morang`,`Jhapa`,`Sunsari`,`Udayapur`],answer:1,explanation:`Jhapa, near Bhadrapur. Tradition links the place with the Mahabharata.`}]},{id:`10.4`,title:`Society and culture (समाज र संस्कृति)`,questions:[{id:`Q 10.4.1`,label:`Expected – Practice`,stem:`<p>How many languages, besides Nepali, did Koshi Province bring into government use from 25 Kartik 2083?</p>
`,options:[`13`,`2`,`7`,`11`],answer:0,explanation:`Thirteen. The Language Commission had recommended two of them, Maithili and Limbu. The day chosen was the birth anniversary of Mahaguru Phalgunanda. 🔄`},{id:`Q 10.4.2`,label:`Pattern-Based – Reconstructed`,stem:`<p>Match the holy place with its district.</p>
<div class="tw"><table>
<thead>
<tr>
<th>Place</th>
<th>District</th>
</tr>
</thead>
<tbody>
<tr>
<td>A. Pathibhara Devi</td>
<td>1. Khotang</td>
</tr>
<tr>
<td>B. Halesi Mahadev</td>
<td>2. Sunsari</td>
</tr>
<tr>
<td>C. Barahakshetra</td>
<td>3. Taplejung</td>
</tr>
<tr>
<td>D. Mai Pokhari</td>
<td>4. Ilam</td>
</tr>
</tbody>
</table></div>
`,options:[`A–3, B–2, C–1, D–4`,`A–1, B–3, C–2, D–4`,`A–3, B–1, C–2, D–4`,`A–4, B–1, C–2, D–3`],answer:2,explanation:`Pathibhara–Taplejung; Halesi–Khotang; Barahakshetra–Sunsari; Mai Pokhari–Ilam.`},{id:`Q 10.4.3`,label:`Expected – Practice`,stem:`<p>About what share of the people of Koshi Province follow the Kirat religion, by the Census of 2078?</p>
`,options:[`About 3 percent`,`About 17 percent`,`About 9 percent`,`About 33 percent`],answer:1,explanation:`About 17 percent. About 3 percent is the figure for the whole country, and about 9 percent is the share of Buddhists in the province.`},{id:`Q 10.4.4`,label:`Pattern-Based – Reconstructed`,stem:`<p>Which of these pairs is <strong>wrongly</strong> matched?</p>
`,options:[`Sakela — Rai`,`Chyabrung — Limbu`,`Mani Rimdu — Sherpa`,`Dhan Nach — Sherpa`],answer:3,explanation:`Dhan Nach is a dance of the Limbu.`},{id:`Q 10.4.5`,label:`Expected – Practice`,stem:`<p>Mahaguru Phalgunanda, the reformer of Kirat society, was born in which district?</p>
`,options:[`Panchthar`,`Taplejung`,`Dhankuta`,`Ilam`],answer:3,explanation:`Ilam, at Chukchinamba, on 25 Kartik 1942 BS. He was declared a national hero on 16 Mangsir 2066.`}]},{id:`10.5`,title:`Economy (अर्थतन्त्र)`,questions:[{id:`Q 10.5.1`,label:`Expected – Practice`,stem:`<p>About what share of Nepal's tea is grown in Koshi Province, as reported for 2081/82?</p>
`,options:[`About 60 percent`,`About 99 percent`,`About 75 percent`,`About 85 percent`],answer:1,explanation:`About 99 percent (99.2 percent as reported). About 75 percent is the share of Jhapa district alone.`},{id:`Q 10.5.2`,label:`Pattern-Based – Reconstructed`,stem:`<p>Consider these statements about electricity in Koshi Province at the end of Ashad 2083.</p>
<ol>
<li>Installed capacity was about 994 megawatts.</li>
<li>Solukhumbu had the largest capacity of any district.</li>
<li>The Arun III project was already giving 900 megawatts.</li>
</ol>
<p>Which of them are correct?</p>
`,options:[`1 and 2 only`,`1 only`,`2 and 3 only`,`1, 2 and 3`],answer:0,explanation:`Statement 3 is wrong. Arun III was 75.81 percent built; its target is Poush 2085. 🔄`},{id:`Q 10.5.3`,label:`Expected – Practice`,stem:`<p>The Integrated Check Post at Biratnagar, opened in January 2020, faces which Indian town?</p>
`,options:[`Raxaul`,`Panitanki`,`Jayanagar`,`Jogbani`],answer:3,explanation:`Jogbani, in Bihar. Raxaul faces Birgunj, Panitanki faces Kakarbhitta, and Jayanagar is the Indian end of the railway to Janakpur.`},{id:`Q 10.5.4`,label:`Pattern-Based – Reconstructed`,stem:`<p>Match the highway with the place where it begins in Koshi Province.</p>
<div class="tw"><table>
<thead>
<tr>
<th>Highway</th>
<th>Starting point</th>
</tr>
</thead>
<tbody>
<tr>
<td>A. Mahendra (East–West) Highway</td>
<td>1. Bahundangi, Jhapa</td>
</tr>
<tr>
<td>B. Mid-Hill (Pushpalal) Highway</td>
<td>2. Biratnagar, Morang</td>
</tr>
<tr>
<td>C. Madan Bhandari Highway</td>
<td>3. Chiyo Bhanjyang, Panchthar</td>
</tr>
<tr>
<td>D. Koshi Highway</td>
<td>4. Kakarbhitta, Jhapa</td>
</tr>
</tbody>
</table></div>
`,options:[`A–4, B–1, C–3, D–2`,`A–2, B–3, C–1, D–4`,`A–4, B–3, C–1, D–2`,`A–1, B–3, C–4, D–2`],answer:2,explanation:`Mahendra–Kakarbhitta; Mid-Hill–Chiyo Bhanjyang; Madan Bhandari–Bahundangi; Koshi–Biratnagar.`},{id:`Q 10.5.5`,label:`Expected – Practice`,stem:`<p>Where and when was the first Koshi Province Investment Summit held?</p>
`,options:[`Biratnagar, Baisakh 2082`,`Dharan, Baisakh 2081`,`Itahari, Kartik 2082`,`Biratnagar, Ashad 2083`],answer:0,explanation:`Biratnagar, 18–19 Baisakh 2082 (1–2 May 2025). Memoranda were signed for 46 projects worth Rs 152.16 billion. 🔄`}]},{id:`10.6`,title:`Government and institutions (प्रदेश सरकार र संस्था)`,questions:[{id:`Q 10.6.1`,label:`Expected – Practice`,stem:`<p>How many members has the Provincial Assembly of Koshi, and how many of them are elected by first-past-the-post?</p>
`,options:[`87 and 52`,`93 and 37`,`93 and 56`,`110 and 66`],answer:2,explanation:`93 members: 56 first-past-the-post (two for each of the 28 House constituencies) and 37 proportional.`},{id:`Q 10.6.2`,label:`Pattern-Based – Reconstructed`,stem:`<p>Consider these statements about the government of Koshi Province in Kartik 2083.</p>
<ol>
<li>The Chief Minister is Hikmat Kumar Karki of the CPN (UML).</li>
<li>The Nepali Congress left the government in Shrawan 2083.</li>
<li>The Chief Minister won a vote of confidence on 8 Bhadra 2083 with 57 votes.</li>
</ol>
<p>Which of them are correct?</p>
`,options:[`1 only`,`1 and 2 only`,`2 and 3 only`,`1, 2 and 3`],answer:3,explanation:`All three are correct. The Nepali Communist Party joined the government on 1 Bhadra 2083, and the vote was 57 to 22. 🔄`},{id:`Q 10.6.3`,label:`Expected – Practice`,stem:`<p>The second periodic plan of Koshi Province covers which years?</p>
`,options:[`2081/82 to 2085/86`,`2076/77 to 2080/81`,`2080/81 to 2084/85`,`2078/79 to 2082/83`],answer:0,explanation:`2081/82 to 2085/86, the same years as the national Sixteenth Plan. The first plan covered 2076/77 to 2080/81.`},{id:`Q 10.6.4`,label:`Pattern-Based – Reconstructed`,stem:`<p>Fill in the blank. The budget of Koshi Province for 2083/84, presented on 1 Ashad 2083, is about Rs ______ billion.</p>
`,options:[`35.88`,`40.45`,`66.93`,`32.46`],answer:1,explanation:`Rs 40.45 billion. Rs 35.88 billion was the budget of 2082/83, and Rs 66.93 billion is Bagmati's budget. 🔄`},{id:`Q 10.6.5`,label:`Expected – Practice`,stem:`<p>Who became the first Province Chief (प्रदेश प्रमुख) of the province now called Koshi, in Magh 2074?</p>
`,options:[`Somnath Adhikari`,`Parshuram Khapung`,`Sher Dhan Rai`,`Govinda Subba`],answer:3,explanation:`Govinda Subba. Somnath Adhikari was the second and Parshuram Khapung the third. Sher Dhan Rai was the first Chief Minister.`}]},{id:`10.7`,title:`The province in numbers and superlatives; fact sheet (तथ्याङ्क, विशेषता र तथ्य-पत्र)`,questions:[{id:`Q 10.7.1`,label:`Expected – Practice`,stem:`<p>In area, where does Koshi stand among the seven provinces?</p>
`,options:[`Second, after Karnali`,`First`,`Third, after Karnali and Lumbini`,`Fourth`],answer:0,explanation:`Second. Karnali has 27,984 sq km and Koshi 25,905 sq km; Lumbini (22,288 sq km) is third.`},{id:`Q 10.7.2`,label:`Pattern-Based – Reconstructed`,stem:`<p>Three of these statements about Koshi Province are true. Which one is <strong>not</strong> true?</p>
`,options:[`It has the most districts of any province.`,`It has the largest population of any province.`,`It has the most local levels of any province.`,`It has the second-largest share of the national economy.`],answer:1,explanation:`Bagmati has the largest population. Koshi is fourth, with 4,961,412 people.`},{id:`Q 10.7.3`,label:`Expected – Practice`,stem:`<p>What was the population density of Koshi Province in the Census of 2078?</p>
`,options:[`60 persons per sq km`,`138 persons per sq km`,`192 persons per sq km`,`301 persons per sq km`],answer:2,explanation:`192, a little below the national figure of 198. The other figures belong to Karnali, Sudurpashchim and Bagmati.`},{id:`Q 10.7.4`,label:`Pattern-Based – Reconstructed`,stem:`<p>Match the number with what it counts in Koshi Province.</p>
<div class="tw"><table>
<thead>
<tr>
<th>Number</th>
<th>What it counts</th>
</tr>
</thead>
<tbody>
<tr>
<td>A. 14</td>
<td>1. Seats in the Provincial Assembly</td>
</tr>
<tr>
<td>B. 28</td>
<td>2. Districts</td>
</tr>
<tr>
<td>C. 93</td>
<td>3. Local levels</td>
</tr>
<tr>
<td>D. 137</td>
<td>4. Constituencies of the House of Representatives</td>
</tr>
</tbody>
</table></div>
`,options:[`A–2, B–1, C–4, D–3`,`A–4, B–2, C–1, D–3`,`A–2, B–4, C–3, D–1`,`A–2, B–4, C–1, D–3`],answer:3,explanation:`14 districts; 28 House constituencies; 93 Assembly seats; 137 local levels.`},{id:`Q 10.7.5`,label:`Expected – Practice`,stem:`<p>Which is the least populous district of Koshi Province in the Census of 2078?</p>
`,options:[`Solukhumbu`,`Terhathum`,`Taplejung`,`Okhaldhunga`],answer:1,explanation:`Terhathum, with about 89,000 people. It is also the smallest district in area (679 sq km).`}]},{id:`T`,title:`End-of-chapter test — Top 25`,questions:[{id:`T1`,label:`Expected – Practice`,stem:`<p>On which date did the Provincial Assembly make Biratnagar the permanent capital of the province?</p>
`,options:[`3 Magh 2074`,`17 Falgun 2079`,`23 Baisakh 2076`,`3 Ashoj 2072`],answer:2,explanation:`23 Baisakh 2076 (6 May 2019). On 3 Magh 2074 the Government of Nepal named Biratnagar the temporary seat; 17 Falgun 2079 is the day of naming.`},{id:`T2`,label:`Pattern-Based – Reconstructed`,stem:`<p>Fill in the blank. The name &quot;Koshi&quot; was passed by the Provincial Assembly with ______ votes for and 4 against.</p>
`,options:[`82`,`62`,`93`,`57`],answer:0,explanation:`82. Two-thirds of the 93 members, the number the Constitution asks for, is 62.`},{id:`T3`,label:`Expected – Practice`,stem:`<p>Which two cities of Koshi Province are sub-metropolitan cities?</p>
`,options:[`Biratnagar and Dharan`,`Itahari and Damak`,`Dharan and Birtamod`,`Itahari and Dharan`],answer:3,explanation:`Itahari and Dharan, both in Sunsari. Biratnagar is a metropolitan city; Damak and Birtamod are municipalities.`},{id:`T4`,label:`Pattern-Based – Reconstructed`,stem:`<p>Consider these statements about the boundaries of Koshi Province.</p>
<ol>
<li>It touches three Indian states: Sikkim, West Bengal and Bihar.</li>
<li>Three of its districts touch China.</li>
<li>It touches Bagmati Province but not Madhesh Province.</li>
</ol>
<p>Which of them are correct?</p>
`,options:[`1 only`,`1 and 2 only`,`2 and 3 only`,`1, 2 and 3`],answer:1,explanation:`Statement 3 is wrong. Udayapur and Sunsari touch Madhesh Province.`},{id:`T5`,label:`Expected – Practice`,stem:`<p>Which river forms the eastern boundary of Koshi Province and of Nepal?</p>
`,options:[`Kankai`,`Tista`,`Mechi`,`Tamor`],answer:2,explanation:`The Mechi, since the Treaty of Sugauli. The Tista was the limit before 1816.`},{id:`T6`,label:`Pattern-Based – Reconstructed`,stem:`<p>Arrange these peaks of Koshi Province from the highest to the lowest.</p>
<ol>
<li>Lhotse</li>
<li>Kanchenjunga</li>
<li>Cho Oyu</li>
<li>Makalu</li>
</ol>
`,options:[`2, 1, 4, 3`,`1, 2, 4, 3`,`2, 4, 1, 3`,`2, 1, 3, 4`],answer:0,explanation:`Kanchenjunga 8,586 m; Lhotse 8,516 m; Makalu 8,463 m; Cho Oyu 8,201 m.`},{id:`T7`,label:`Expected – Practice`,stem:`<p>About how many wild water buffalo (अर्ना) were counted in Koshi Tappu Wildlife Reserve in 2021?</p>
`,options:[`63`,`498`,`355`,`752`],answer:1,explanation:`498. The count of 1976 was 63.`},{id:`T8`,label:`Pattern-Based – Reconstructed`,stem:`<p>Which of these pairs is <strong>wrongly</strong> matched?</p>
`,options:[`Imja lake — Solukhumbu`,`Hyatrung waterfall — Terhathum`,`Salpa Pokhari — Bhojpur`,`Tiptala pass — Sankhuwasabha`],answer:3,explanation:`Tiptala is in Taplejung, above Olangchung Gola. The pass of Sankhuwasabha is Kimathanka.`},{id:`T9`,label:`Expected – Practice`,stem:`<p>In which years did Gorkha win the Sen kingdoms of Chaudandi and Bijayapur?</p>
`,options:[`1744–1745`,`1768–1769`,`1773–1774`,`1814–1816`],answer:2,explanation:`1773–1774. The Kathmandu Valley was won in 1768–1769; 1814–1816 are the years of the war with the East India Company.`},{id:`T10`,label:`Pattern-Based – Reconstructed`,stem:`<p>Consider these statements about the history of the province.</p>
<ol>
<li>The Biratnagar Jute Mill is called the first modern factory of Nepal.</li>
<li>The workers' strike at the mill began on 21 Falgun 2003.</li>
<li>The Chhintang incident of 2036 BS took place in Ilam.</li>
</ol>
<p>Which of them are correct?</p>
`,options:[`1 and 2 only`,`1 only`,`2 and 3 only`,`1, 2 and 3`],answer:0,explanation:`Statement 3 is wrong. Chhintang is in Dhankuta.`},{id:`T11`,label:`Expected – Practice`,stem:`<p>What was the common land of the Limbu clans called, which they kept after 1774?</p>
`,options:[`Birta`,`Guthi`,`Jagir`,`Kipat`],answer:3,explanation:`Kipat (किपट). Birta was a grant to a person, guthi is trust land and jagir was land given in place of pay.`},{id:`T12`,label:`Expected – Practice`,stem:`<p>Which is the largest caste or ethnic group of Koshi Province in the Census of 2078?</p>
`,options:[`Rai`,`Chhetri`,`Brahman (Hill)`,`Limbu`],answer:1,explanation:`Chhetri, about 15 percent. Brahman (Hill), Rai and Limbu follow.`},{id:`T13`,label:`Pattern-Based – Reconstructed`,stem:`<p>Fill in the blank. ______, of Solukhumbu, was the first Nepali woman to climb Sagarmatha and is a national hero.</p>
`,options:[`Lhakpa Sherpa`,`Mira Rai`,`Pasang Lhamu Sherpa`,`Pemba Doma Sherpa`],answer:2,explanation:`Pasang Lhamu Sherpa, who reached the summit on 10 Baisakh 2050 (22 April 1993) and died on the way down.`},{id:`T14`,label:`Expected – Practice`,stem:`<p>Dhaka cloth and the khukuri are special products of which two hill districts of Koshi Province, in that order?</p>
`,options:[`Bhojpur and Terhathum`,`Terhathum and Bhojpur`,`Dhankuta and Khotang`,`Ilam and Panchthar`],answer:1,explanation:`Dhaka cloth of Terhathum and the khukuri of Bhojpur.`},{id:`T15`,label:`Pattern-Based – Reconstructed`,stem:`<p>Match each item with the district that leads the province in it.</p>
<div class="tw"><table>
<thead>
<tr>
<th>Item</th>
<th>District</th>
</tr>
</thead>
<tbody>
<tr>
<td>A. Tea, by weight</td>
<td>1. Taplejung</td>
</tr>
<tr>
<td>B. Large cardamom</td>
<td>2. Jhapa</td>
</tr>
<tr>
<td>C. Limestone for cement</td>
<td>3. Solukhumbu</td>
</tr>
<tr>
<td>D. Installed hydropower</td>
<td>4. Udayapur</td>
</tr>
</tbody>
</table></div>
`,options:[`A–2, B–1, C–4, D–3`,`A–1, B–2, C–4, D–3`,`A–2, B–1, C–3, D–4`,`A–4, B–1, C–2, D–3`],answer:0,explanation:`Tea–Jhapa; cardamom–Taplejung; limestone–Udayapur; hydropower–Solukhumbu (349.8 megawatts in Ashad 2083). 🔄`},{id:`T16`,label:`Expected – Practice`,stem:`<p>Which sector gave about half (49.8 percent) of the output of Koshi Province in 2082/83?</p>
`,options:[`Agriculture`,`Industry`,`Remittance`,`Services`],answer:3,explanation:`Services. Agriculture gave 32.5 percent and industry 17.7 percent. Remittance is not a sector of output. 🔄`},{id:`T17`,label:`Expected – Practice`,stem:`<p>How much installed power does the second periodic plan of Koshi Province aim at by 2085/86?</p>
`,options:[`900 megawatts`,`994 megawatts`,`2,200 megawatts`,`22,350 megawatts`],answer:2,explanation:`2,200 megawatts. Arun III is 900 megawatts; 994 megawatts were installed in Ashad 2083; 22,350 megawatts is the usual estimate of the Koshi basin's potential.`},{id:`T18`,label:`Pattern-Based – Reconstructed`,stem:`<p>Consider these statements about the second periodic plan of Koshi Province.</p>
<ol>
<li>The Province Planning Commission released it in Shrawan 2081.</li>
<li>It aims at average growth of 7.55 percent a year.</li>
<li>It aims to bring poverty down to 12 percent.</li>
</ol>
<p>Which of them are correct?</p>
`,options:[`1, 2 and 3`,`1 only`,`1 and 2 only`,`2 and 3 only`],answer:0,explanation:`All three are correct. The plan was released on 31 Shrawan 2081 (15 August 2024); it also aims at income of USD 1,645 per person.`},{id:`T19`,label:`Expected – Practice`,stem:`<p>How many ministries has the Government of Koshi Province, besides the Office of the Chief Minister and Council of Ministers?</p>
`,options:[`7`,`8`,`11`,`18`],answer:1,explanation:`Eight. Eleven is the number of members of the Council of Ministers formed on 1 Bhadra 2083; eighteen is the largest number the Constitution allows. 🔄`},{id:`T20`,label:`Expected – Practice`,stem:`<p>At which three places does the High Court of Biratnagar have benches?</p>
`,options:[`Dharan, Ilam and Diktel`,`Dhankuta, Bhadrapur and Salleri`,`Rajbiraj, Ilam and Okhaldhunga`,`Dhankuta, Ilam and Okhaldhunga`],answer:3,explanation:`Dhankuta, Ilam and Okhaldhunga. Rajbiraj is a bench of the High Court of Janakpur.`},{id:`T21`,label:`Pattern-Based – Reconstructed`,stem:`<p>Arrange these Chief Ministers in the order in which they first took office.</p>
<ol>
<li>Rajendra Kumar Rai</li>
<li>Sher Dhan Rai</li>
<li>Hikmat Kumar Karki</li>
<li>Bhim Acharya</li>
</ol>
`,options:[`2, 1, 4, 3`,`4, 2, 1, 3`,`2, 4, 1, 3`,`2, 4, 3, 1`],answer:2,explanation:`Sher Dhan Rai (Falgun 2074), Bhim Acharya (Bhadra 2078), Rajendra Kumar Rai (Kartik 2078), Hikmat Kumar Karki (Poush 2079).`},{id:`T22`,label:`Expected – Practice`,stem:`<p>Parshuram Khapung, whose term ended on 24 Kartik 2083, is remembered for which &quot;first&quot;?</p>
`,options:[`The first Chief Minister of the province`,`The first Province Chief in Nepal to complete a five-year term`,`The first Speaker of the Provincial Assembly`,`The first Province Chief of the province`],answer:1,explanation:`He completed five years as Province Chief. The first Province Chief of the province was Govinda Subba. 🔄`},{id:`T23`,label:`Pattern-Based – Reconstructed`,stem:`<p>Three of these statements about the Provincial Assembly of Koshi are true. Which one is <strong>not</strong> true?</p>
`,options:[`Its term ends in Mangsir 2083.`,`A majority of all its members is 47.`,`Two-thirds of all its members is 62.`,`It was elected on 4 Mangsir 2079.`],answer:0,explanation:`The five-year term ends on 4 Mangsir 2084 (19 November 2027).`},{id:`T24`,label:`Expected – Practice`,stem:`<p>The Policy and Programme of Koshi Province for 2083/84 announced a &quot;Koshi Province Visit Year&quot;. Which period does it cover?</p>
`,options:[`Baisakh 2083 to Chaitra 2083`,`Shrawan 2083 to Ashad 2084`,`Magh 2083 to Poush 2084`,`Shrawan 2083 to Ashad 2085`],answer:3,explanation:`Shrawan 2083 to Ashad 2085: two fiscal years, 2083/84 and 2084/85. 🔄`},{id:`T25`,label:`Pattern-Based – Reconstructed`,stem:`<p>Consider these statements about disasters in Koshi Province.</p>
<ol>
<li>The earthquake of 5 Bhadra 2045 had its centre in Udayapur.</li>
<li>The embankment of the Koshi broke at Kusaha, Sunsari, on 2 Bhadra 2065.</li>
<li>The Dig Tsho glacial lake flood of 2042 BS took place in Taplejung.</li>
</ol>
<p>Which of them are correct?</p>
`,options:[`1 only`,`2 and 3 only`,`1 and 2 only`,`1, 2 and 3`],answer:2,explanation:`Statement 3 is wrong. Dig Tsho is in Solukhumbu; the flood came on 20 Shrawan 2042 (4 August 1985).`}]}]},{num:11,title:`Madhesh Province`,nep:`मधेश प्रदेश`,slug:`part-15-chapter-11-madhesh-province`,topics:[{id:`11.1`,title:`Profile of the province (प्रदेशको परिचय)`,questions:[{id:`Q 11.1.1`,label:`Expected – Practice`,stem:`<p>Madhesh Province has 136 local levels. How many of them are municipalities (नगरपालिका), leaving out the metropolitan and sub-metropolitan cities?</p>
`,options:[`59`,`64`,`73`,`77`],answer:2,explanation:`73. The 136 are 1 metropolitan city, 3 sub-metropolitan cities, 73 municipalities and 59 rural municipalities. 77 is the number of all three kinds of town together.`},{id:`Q 11.1.2`,label:`Pattern-Based – Reconstructed`,stem:`<p>Consider these statements about the naming of Madhesh Province.</p>
<ol>
<li>The Provincial Assembly decided the name and the capital on the same day, 3 Magh 2078.</li>
<li>The name received 80 votes and the capital 78 votes.</li>
<li>The name took effect only after the Federal Parliament approved it.</li>
</ol>
<p>Which of them are correct?</p>
`,options:[`1 and 2 only`,`2 and 3 only`,`1 and 3 only`,`1, 2 and 3`],answer:0,explanation:`Statement 3 is wrong. Under Article 295 (2) the Provincial Assembly itself names the province by a two-thirds majority; the Federal Parliament has no part in it.`},{id:`Q 11.1.3`,label:`Expected – Practice`,stem:`<p>Which district of Madhesh Province has the largest number of local levels?</p>
`,options:[`Rautahat`,`Dhanusha`,`Saptari`,`Sarlahi`],answer:3,explanation:`Sarlahi has 20 local levels: 11 municipalities and 9 rural municipalities. Rautahat, Dhanusha and Saptari have 18 each.`},{id:`Q 11.1.4`,label:`Pattern-Based – Reconstructed`,stem:`<p>Match the districts with their headquarters.</p>
<ol>
<li>Mahottari — A. Gaur</li>
<li>Sarlahi — B. Jaleshwar</li>
<li>Rautahat — C. Kalaiya</li>
<li>Bara — D. Malangwa</li>
</ol>
`,options:[`1-B, 2-A, 3-D, 4-C`,`1-B, 2-D, 3-A, 4-C`,`1-D, 2-B, 3-C, 4-A`,`1-C, 2-D, 3-A, 4-B`],answer:1,explanation:`Mahottari–Jaleshwar; Sarlahi–Malangwa; Rautahat–Gaur; Bara–Kalaiya.`},{id:`Q 11.1.5`,label:`Expected – Practice`,stem:`<p>Which is the largest district of Madhesh Province by area?</p>
`,options:[`Saptari`,`Parsa`,`Sarlahi`,`Bara`],answer:0,explanation:`Saptari, 1,363 sq km. Parsa (1,353 sq km) is a close second. Mahottari (1,002 sq km) is the smallest.`}]},{id:`11.2`,title:`Physical geography (भौतिक भूगोल)`,questions:[{id:`Q 11.2.1`,label:`Expected – Practice`,stem:`<p>Which river forms the boundary between Sarlahi and Rautahat districts?</p>
`,options:[`Kamala`,`Bagmati`,`Lal Bakaiya`,`Ratu`],answer:1,explanation:`The Bagmati. The Kamala separates Siraha from Dhanusha.`},{id:`Q 11.2.2`,label:`Pattern-Based – Reconstructed`,stem:`<p>Consider these statements about Parsa National Park.</p>
<ol>
<li>It was a wildlife reserve from 1984 and became a national park in 2017.</li>
<li>Its area is 627.39 sq km.</li>
<li>It lies in Parsa and Bara districts of Madhesh Province and in Makwanpur district of Bagmati Province.</li>
</ol>
<p>Which of them are correct?</p>
`,options:[`1 only`,`1 and 2 only`,`2 and 3 only`,`1, 2 and 3`],answer:3,explanation:`All three are correct. The park was enlarged from 499 to 627.39 sq km in 2015.`},{id:`Q 11.2.3`,label:`Expected – Practice`,stem:`<p>On 7 Shrawan 2082 the Government of Nepal declared all eight districts of Madhesh Province a disaster crisis zone. Which hazard was the cause?</p>
`,options:[`Drought`,`Flood`,`Cold wave`,`Windstorm`],answer:0,explanation:`Drought. The monsoon rain failed in the province, wells dried and paddy could not be planted. The declaration was for three months.`},{id:`Q 11.2.4`,label:`Pattern-Based – Reconstructed`,stem:`<p>Fill in the blank. The ______ river separates Siraha district from Dhanusha district.</p>
`,options:[`Balan`,`Ratu`,`Kamala`,`Koshi`],answer:2,explanation:`The Kamala, a second-grade river that rises in the Mahabharat range.`},{id:`Q 11.2.5`,label:`Expected – Practice`,stem:`<p>Which of these rivers of Madhesh Province is a snow-fed river of the first grade?</p>
`,options:[`Kamala`,`Bagmati`,`Lakhandehi`,`Koshi`],answer:3,explanation:`The Koshi, on the eastern edge of the province. The Kamala and Bagmati rise in the Mahabharat range; the Lakhandehi rises in the Chure.`}]},{id:`11.3`,title:`History and archaeology (इतिहास र पुरातत्त्व)`,questions:[{id:`Q 11.3.1`,label:`Expected – Practice`,stem:`<p>Who was shot dead at Lahan on 5 Magh 2063 and is remembered as the first martyr of the Madhesh movement?</p>
`,options:[`Ramesh Mahato`,`Durgananda Jha`,`Gajendra Narayan Singh`,`Upendra Yadav`],answer:0,explanation:`Ramesh Mahato. Durgananda Jha was executed in 2020 BS for the Janakpur bomb case; Upendra Yadav led the Madheshi Janadhikar Forum.`},{id:`Q 11.3.2`,label:`Pattern-Based – Reconstructed`,stem:`<p>Arrange these events in order of time, earliest first.</p>
<ol>
<li>The 22-point agreement with the Madheshi Janadhikar Forum</li>
<li>The naming of Madhesh Province</li>
<li>The death of Ramesh Mahato at Lahan</li>
<li>The eight-point agreement with the United Democratic Madheshi Front</li>
</ol>
`,options:[`1, 3, 4, 2`,`3, 4, 1, 2`,`3, 1, 4, 2`,`1, 4, 3, 2`],answer:2,explanation:`Magh 2063, Bhadra 2064, Falgun 2064, Magh 2078.`},{id:`Q 11.3.3`,label:`Expected – Practice`,stem:`<p>In which year did Rana Prime Minister Bir Shamsher found the town of Birgunj?</p>
`,options:[`1847`,`1897`,`1927`,`1937`],answer:1,explanation:`1897. The place was earlier called Gahawa. 1847 is the year of the Alau Parva, 1927 of the first railway and 1937 of the Janakpur line.`},{id:`Q 11.3.4`,label:`Pattern-Based – Reconstructed`,stem:`<p>Which pair is matched <strong>wrongly</strong>?</p>
`,options:[`Karnat dynasty — Simraungadh`,`Alau Parva — Parsa`,`Durgananda Jha — Janakpur bomb case`,`Ramesh Mahato — Gaur`],answer:3,explanation:`Ramesh Mahato was killed at Lahan in Siraha. Gaur, in Rautahat, was the place of the clash of 7 Chaitra 2063.`},{id:`Q 11.3.5`,label:`Expected – Practice`,stem:`<p>The 22-point agreement of 13 Bhadra 2064 was signed between the Government of Nepal and which organisation?</p>
`,options:[`United Democratic Madheshi Front`,`Madheshi Janadhikar Forum, Nepal`,`Nepal Sadbhavana Party`,`Janamat Party`],answer:1,explanation:`The Madheshi Janadhikar Forum, Nepal, led by Upendra Yadav. The eight-point agreement of Falgun 2064 was with the United Democratic Madheshi Front.`}]},{id:`11.4`,title:`Society and culture (समाज र संस्कृति)`,questions:[{id:`Q 11.4.1`,label:`Expected – Practice`,stem:`<p>Which language stands third among the mother tongues of Madhesh Province, after Maithili and Bhojpuri?</p>
`,options:[`Nepali`,`Tharu`,`Urdu`,`Bajjika`],answer:3,explanation:`Bajjika, about 18.4 percent. Nepali is fourth with about 5.8 percent.`},{id:`Q 11.4.2`,label:`Pattern-Based – Reconstructed`,stem:`<p>Match the festivals with their descriptions.</p>
<ol>
<li>Jur Sital — A. Worship of the setting and rising sun, in Kartik</li>
<li>Chhath — B. The Maithili new year, in Baisakh</li>
<li>Bibaha Panchami — C. The wedding of Ram and Sita, in Mangsir</li>
<li>Jitiya — D. A fast kept by mothers for their children, in Ashoj</li>
</ol>
`,options:[`1-A, 2-B, 3-C, 4-D`,`1-B, 2-A, 3-C, 4-D`,`1-B, 2-D, 3-A, 4-C`,`1-D, 2-A, 3-B, 4-C`],answer:1,explanation:`Jur Sital is the new year, Chhath the sun festival, Bibaha Panchami the wedding festival of Janakpurdham and Jitiya the mothers' fast.`},{id:`Q 11.4.3`,label:`Expected – Practice`,stem:`<p>The Gadhimai fair, held every five years, takes place in which district?</p>
`,options:[`Parsa`,`Rautahat`,`Bara`,`Sarlahi`],answer:2,explanation:`Bara, at Bariyarpur in Mahagadhimai Municipality. The last fair was in Mangsir 2081.`},{id:`Q 11.4.4`,label:`Pattern-Based – Reconstructed`,stem:`<p>Consider these statements about the Janaki Temple of Janakpurdham.</p>
<ol>
<li>It was completed in 1967 BS.</li>
<li>It was built by a queen of Tikamgarh in India.</li>
<li>It is built in the pagoda style.</li>
</ol>
<p>Which of them are correct?</p>
`,options:[`1 and 2 only`,`2 and 3 only`,`1 and 3 only`,`1, 2 and 3`],answer:0,explanation:`Statement 3 is wrong. The temple is in a mixed Hindu–Mughal style with domes; it is also called the Naulakha Mandir.`},{id:`Q 11.4.5`,label:`Expected – Practice`,stem:`<p>Which campaign did Chief Minister Lalbabu Raut begin in 2075 BS for the education and safety of girls?</p>
`,options:[`Saksham Chhori`,`Chhori Buhari Chhatrabritti`,`Beti Padhau, Beti Bachau`,`Bank Khata Chhoriko`],answer:2,explanation:`&quot;Beti Padhau, Beti Bachau&quot;. It gives an education insurance to girls born from 1 Magh 2075 and bicycles to girls of Class 8.`}]},{id:`11.5`,title:`Economy (अर्थतन्त्र)`,questions:[{id:`Q 11.5.1`,label:`Expected – Practice`,stem:`<p>According to the preliminary estimate of the National Statistics Office for 2082/83, what was the gross domestic product per person of Madhesh Province?</p>
`,options:[`USD 834`,`USD 934`,`USD 1,108`,`USD 1,208`],answer:1,explanation:`USD 934, the lowest of the seven provinces. USD 1,108 is Karnali's figure and USD 1,208 Lumbini's.`},{id:`Q 11.5.2`,label:`Pattern-Based – Reconstructed`,stem:`<p><strong>Assertion (A):</strong> The economy of Madhesh Province grew by only 1.31 percent in 2082/83, the slowest of the seven provinces.</p>
<p><strong>Reason (R):</strong> Farm output in the province was estimated to fall in that year, after the drought of 2082.</p>
`,options:[`Both A and R are true, and R is the correct explanation of A`,`Both A and R are true, but R is not the correct explanation of A`,`A is true, but R is false`,`A is false, but R is true`],answer:0,explanation:`Farming is more than a third of the provincial economy, so the fall in farm output pulled the whole growth rate down from 4.43 to 1.31 percent.`},{id:`Q 11.5.3`,label:`Expected – Practice`,stem:`<p>The Special Economic Zone of Madhesh Province is at Simara. In which district does it lie?</p>
`,options:[`Parsa`,`Rautahat`,`Dhanusha`,`Bara`],answer:3,explanation:`Bara. Jitpur Simara is one of the two sub-metropolitan cities of Bara; the other is Kalaiya.`},{id:`Q 11.5.4`,label:`Pattern-Based – Reconstructed`,stem:`<p>Three of these places are on the railway line from Jaynagar that is now in use. Which one is the odd one out?</p>
`,options:[`Janakpur`,`Kurtha`,`Simara`,`Bijalpura`],answer:2,explanation:`Simara, in Bara, has an airport and a Special Economic Zone but is not on the Jaynagar–Janakpur–Kurtha–Bijalpura line.`},{id:`Q 11.5.5`,label:`Expected – Practice`,stem:`<p>Which highway from the hills ends at Bardibas in Mahottari district?</p>
`,options:[`B.P. Highway`,`Tribhuvan Highway`,`Prithvi Highway`,`Araniko Highway`],answer:0,explanation:`The B.P. Highway. The Tribhuvan Highway reaches the plain at Birgunj.`}]},{id:`11.6`,title:`Government and institutions (प्रदेश सरकार र संस्था)`,questions:[{id:`Q 11.6.1`,label:`Expected – Practice`,stem:`<p>Who was appointed Chief Minister of Madhesh Province on 19 Mangsir 2082 under Article 168 (2)?</p>
`,options:[`Satish Kumar Singh`,`Jitendra Prasad Sonal`,`Krishna Prasad Yadav`,`Saroj Kumar Yadav`],answer:2,explanation:`Krishna Prasad Yadav of the Nepali Congress, the sixth Chief Minister, backed by 77 of the 104 sitting members.`},{id:`Q 11.6.2`,label:`Pattern-Based – Reconstructed`,stem:`<p>Consider these statements about the budget of Madhesh Province for 2083/84.</p>
<ol>
<li>Its total is about Rs 41.14 billion.</li>
<li>It was presented on 1 Ashad 2083 by Yuvaraj Bhattarai.</li>
<li>Capital spending is larger than recurrent spending.</li>
</ol>
<p>Which of them are correct?</p>
`,options:[`1 only`,`1 and 2 only`,`2 and 3 only`,`1, 2 and 3`],answer:3,explanation:`All three are correct. Capital spending is about Rs 26.48 billion and recurrent spending about Rs 14.66 billion.`},{id:`Q 11.6.3`,label:`Expected – Practice`,stem:`<p>Which party won the most seats in the Madhesh Provincial Assembly in the election of 4 Mangsir 2079?</p>
`,options:[`CPN (UML)`,`Nepali Congress`,`Janata Samajbadi Party`,`Janamat Party`],answer:0,explanation:`The CPN (UML) won 23 of the 107 seats; the Nepali Congress won 22 and the Janata Samajbadi Party 16.`},{id:`Q 11.6.4`,label:`Pattern-Based – Reconstructed`,stem:`<p>Arrange these Chief Ministers of Madhesh Province in the order in which they first took office.</p>
<ol>
<li>Satish Kumar Singh</li>
<li>Lalbabu Raut</li>
<li>Jitendra Prasad Sonal</li>
<li>Saroj Kumar Yadav of Bara</li>
</ol>
`,options:[`2, 1, 4, 3`,`2, 4, 1, 3`,`4, 2, 1, 3`,`2, 4, 3, 1`],answer:1,explanation:`Lalbabu Raut (2074), Saroj Kumar Yadav of Bara (2079), Satish Kumar Singh (2081), Jitendra Prasad Sonal (2082).`},{id:`Q 11.6.5`,label:`Expected – Practice`,stem:`<p>What is the vision of the second periodic plan of Madhesh Province (2081/82–2085/86)?</p>
`,options:[`&quot;स्वच्छ, सुखी र समुन्नत प्रदेश&quot;`,`&quot;समृद्ध प्रदेश, सुखी नागरिक&quot;`,`&quot;समृद्ध लुम्बिनी: खुसी नागरिक&quot;`,`&quot;आत्मनिर्भर र समृद्ध मधेश, सुखी मधेशी&quot;`],answer:3,explanation:`A self-reliant and prosperous Madhesh, happy Madheshi people. The other three are the visions of Koshi, Gandaki and Lumbini.`}]},{id:`11.7`,title:`The province in numbers and superlatives; fact sheet (तथ्याङ्क, विशेषता र तथ्य-पत्र)`,questions:[{id:`Q 11.7.1`,label:`Expected – Practice`,stem:`<p>In which of these does Madhesh Province stand first among the seven provinces?</p>
`,options:[`Number of wards`,`Number of local levels`,`Population`,`Number of districts`],answer:0,explanation:`Madhesh has 1,271 wards, the most. Koshi has the most local levels and districts, and Bagmati the most people.`},{id:`Q 11.7.2`,label:`Pattern-Based – Reconstructed`,stem:`<p>Consider these statements about Madhesh Province.</p>
<ol>
<li>It is the smallest province by area.</li>
<li>It has the largest population of the seven provinces.</li>
<li>It has the highest density of population.</li>
</ol>
<p>Which of them are correct?</p>
`,options:[`1 and 2 only`,`1 and 3 only`,`2 and 3 only`,`1, 2 and 3`],answer:1,explanation:`Statement 2 is wrong. Bagmati has 6,116,866 people, 2,266 more than Madhesh.`},{id:`Q 11.7.3`,label:`Expected – Practice`,stem:`<p>Which was the most populous district of Madhesh Province in the Census of 2078?</p>
`,options:[`Sarlahi`,`Rautahat`,`Dhanusha`,`Bara`],answer:2,explanation:`Dhanusha, with 867,747 people. Sarlahi (862,470) was a close second.`},{id:`Q 11.7.4`,label:`Pattern-Based – Reconstructed`,stem:`<p>Match the districts with the facts.</p>
<ol>
<li>Parsa — A. Most municipalities (16)</li>
<li>Rautahat — B. Smallest area</li>
<li>Mahottari — C. The only metropolitan city</li>
<li>Sarlahi — D. Most local levels (20)</li>
</ol>
`,options:[`1-A, 2-C, 3-B, 4-D`,`1-C, 2-B, 3-A, 4-D`,`1-D, 2-A, 3-B, 4-C`,`1-C, 2-A, 3-B, 4-D`],answer:3,explanation:`Birgunj Metropolitan City is in Parsa; Rautahat has 16 municipalities; Mahottari is the smallest district; Sarlahi has 20 local levels.`},{id:`Q 11.7.5`,label:`Expected – Practice`,stem:`<p>How many constituencies of the House of Representatives does each district of Madhesh Province have?</p>
`,options:[`3`,`4`,`5`,`8`],answer:1,explanation:`Four in each of the eight districts, 32 in all. Each district has eight direct seats in the Provincial Assembly.`}]},{id:`T`,title:`End-of-chapter test — Top 25`,questions:[{id:`T1`,label:`Expected – Practice`,stem:`<p>On which date did the Provincial Assembly give the province the name &quot;Madhesh&quot; and make Janakpurdham its capital?</p>
`,options:[`3 Ashoj 2072`,`3 Magh 2074`,`3 Magh 2078`,`17 Falgun 2079`],answer:2,explanation:`3 Magh 2078 (17 January 2022). 3 Ashoj 2072 is the day the province was formed; 3 Magh 2074 is the day Janakpur was named the temporary seat.`},{id:`T2`,label:`Expected – Practice`,stem:`<p>The eight districts of Madhesh Province came from which three former zones?</p>
`,options:[`Sagarmatha, Janakpur and Narayani`,`Koshi, Sagarmatha and Janakpur`,`Janakpur, Narayani and Bagmati`,`Sagarmatha, Narayani and Lumbini`],answer:0,explanation:`Sagarmatha gave Saptari and Siraha; Janakpur gave Dhanusha, Mahottari and Sarlahi; Narayani gave Rautahat, Bara and Parsa.`},{id:`T3`,label:`Pattern-Based – Reconstructed`,stem:`<p>Fill in the blank. The two sub-metropolitan cities of Bara district are Kalaiya and ______.</p>
`,options:[`Birgunj`,`Jitpur Simara`,`Janakpurdham`,`Gaur`],answer:1,explanation:`Jitpur Simara. Birgunj is a metropolitan city in Parsa; Janakpurdham is the sub-metropolitan city of Dhanusha.`},{id:`T4`,label:`Expected – Practice`,stem:`<p>What is the area of Madhesh Province, the smallest of the seven provinces?</p>
`,options:[`19,539 sq km`,`20,300 sq km`,`25,905 sq km`,`9,661 sq km`],answer:3,explanation:`9,661 sq km, about 6.6 percent of Nepal. The other figures are the areas of Sudurpashchim, Bagmati and Koshi.`},{id:`T5`,label:`Pattern-Based – Reconstructed`,stem:`<p>Consider these statements about the position of Madhesh Province.</p>
<ol>
<li>Every district of the province touches India.</li>
<li>No district of the province touches China.</li>
<li>The province has two mountain districts.</li>
</ol>
<p>Which of them are correct?</p>
`,options:[`1 only`,`2 and 3 only`,`1 and 2 only`,`1, 2 and 3`],answer:2,explanation:`Statement 3 is wrong. All eight districts are Terai districts.`},{id:`T6`,label:`Expected – Practice`,stem:`<p>In which year did the Parsa Wildlife Reserve become Parsa National Park?</p>
`,options:[`1984`,`2017`,`2010`,`1976`],answer:1,explanation:`2017. It had been a wildlife reserve since 1984. Koshi Tappu, set up in 1976, is still a wildlife reserve.`},{id:`T7`,label:`Pattern-Based – Reconstructed`,stem:`<p>Match the old sites with their districts.</p>
<ol>
<li>Simraungadh — A. Bara</li>
<li>Dhanushadham — B. Dhanusha</li>
<li>Murtiya — C. Sarlahi</li>
<li>Salhesh garden — D. Siraha</li>
</ol>
`,options:[`1-A, 2-B, 3-C, 4-D`,`1-B, 2-A, 3-D, 4-C`,`1-A, 2-B, 3-D, 4-C`,`1-C, 2-B, 3-A, 4-D`],answer:0,explanation:`Simraungadh is in Bara, Dhanushadham in Dhanusha, Murtiya in Sarlahi and the Salhesh garden in Siraha.`},{id:`T8`,label:`Expected – Practice`,stem:`<p>Who founded the Karnat dynasty of Simraungadh in 1097 AD?</p>
`,options:[`Harisimhadeva`,`Mukunda Sen`,`Lohang Sen`,`Nanyadeva`],answer:3,explanation:`Nanyadeva. Harisimhadeva was the last king of the dynasty; he fled in 1324.`},{id:`T9`,label:`Pattern-Based – Reconstructed`,stem:`<p>Four &quot;firsts&quot; are given below with a name. Which name is matched <strong>wrongly</strong>?</p>
`,options:[`First Chief Minister of the province — Lalbabu Raut`,`First Province Chief — Ratneshwar Lal Kayastha`,`First Speaker of the Assembly — Ram Chandra Mandal`,`First President of Nepal — Dr Ram Baran Yadav`],answer:2,explanation:`The first Speaker was Saroj Kumar Yadav. Ram Chandra Mandal was the Speaker of the second Assembly, removed on 3 Mangsir 2082.`},{id:`T10`,label:`Expected – Practice`,stem:`<p>Who has been the Province Chief of Madhesh Province since 25 Kartik 2082?</p>
`,options:[`Surendra Labh Karna`,`Sumitra Subedi Bhandari`,`Hari Shankar Mishra`,`Rajesh Jha`],answer:0,explanation:`Dr Surendra Labh Karna, the sixth Province Chief. He followed Sumitra Subedi Bhandari. 🔄`},{id:`T11`,label:`Expected – Practice`,stem:`<p>Under which clause of Article 168 was Saroj Kumar Yadav of the CPN (UML) sworn in as Chief Minister on 24 Kartik 2082?</p>
`,options:[`Clause (1)`,`Clause (2)`,`Clause (5)`,`Clause (3)`],answer:3,explanation:`Clause (3), as leader of the largest party in the Assembly. Krishna Prasad Yadav was later appointed under clause (2).`},{id:`T12`,label:`Pattern-Based – Reconstructed`,stem:`<p>Consider these statements about the second Provincial Assembly of Madhesh.</p>
<ol>
<li>Its election was held on 4 Mangsir 2079.</li>
<li>It first met on 18 Poush 2079.</li>
<li>The largest party won 54 seats.</li>
</ol>
<p>Which of them are correct?</p>
`,options:[`1 only`,`1 and 2 only`,`2 and 3 only`,`1, 2 and 3`],answer:1,explanation:`Statement 3 is wrong. The largest party, the CPN (UML), won only 23 seats; 54 is the number needed for a majority.`},{id:`T13`,label:`Expected – Practice`,stem:`<p>In which dance of Mithila do women carry clay pots with lamps on their heads at Dashain?</p>
`,options:[`Jat-Jatin`,`Domkach`,`Jhijhiya`,`Sama Chakewa`],answer:2,explanation:`Jhijhiya. Jat-Jatin is danced from the full moon of Shrawan to that of Bhadra; Sama Chakewa is a festival of Kartik.`},{id:`T14`,label:`Expected – Practice`,stem:`<p>The temples of Chhinnamasta Bhagawati and Kankalini are in which district?</p>
`,options:[`Saptari`,`Siraha`,`Mahottari`,`Bara`],answer:0,explanation:`Saptari. Jaleshwar Mahadev is in Mahottari and Gadhimai in Bara.`},{id:`T15`,label:`Pattern-Based – Reconstructed`,stem:`<p>Three of these universities are in Madhesh Province. Which one is the odd one out?</p>
`,options:[`Rajarshi Janak University`,`Purbanchal University`,`Madhesh Agricultural University`,`Madhesh University`],answer:1,explanation:`Purbanchal University is in Koshi Province. Rajarshi Janak University is at Janakpurdham, Madhesh Agricultural University in Saptari and Madhesh University in Parsa.`},{id:`T16`,label:`Expected – Practice`,stem:`<p>What share of the people of Madhesh Province follow Islam, according to the Census of 2078?</p>
`,options:[`5.09 percent`,`8.21 percent`,`2.2 percent`,`13.3 percent`],answer:3,explanation:`13.3 percent, the largest share in any province. 5.09 percent is the share in Nepal as a whole.`},{id:`T17`,label:`Expected – Practice`,stem:`<p>Which crop is linked with Lalbandi of Sarlahi district?</p>
`,options:[`Mango`,`Tobacco`,`Tomato`,`Jute`],answer:2,explanation:`Tomato. Mango is linked with Saptari and Siraha; jute belongs to Koshi Province.`},{id:`T18`,label:`Pattern-Based – Reconstructed`,stem:`<p>Fill in the blank. The Integrated Check Post at ______, opened in 2018, was the first in Nepal.</p>
`,options:[`Biratnagar`,`Birgunj`,`Bhairahawa`,`Nepalgunj`],answer:1,explanation:`Birgunj, the largest customs point of Nepal.`},{id:`T19`,label:`Expected – Practice`,stem:`<p>Through which irrigation system is the water of the Sunkoshi–Marin Diversion designed to reach the fields of Madhesh Province?</p>
`,options:[`The Bagmati irrigation canals`,`The Koshi Western Canal`,`The Chandra Canal`,`The Narayani irrigation system`],answer:0,explanation:`The tunnel drops the water into the Marin stream, which joins the Bagmati; the Bagmati canals then carry it to Bara, Rautahat, Sarlahi, Mahottari and Dhanusha.`},{id:`T20`,label:`Pattern-Based – Reconstructed`,stem:`<p>Consider these statements about the economy of Madhesh Province in 2082/83.</p>
<ol>
<li>Its growth was the lowest of the seven provinces.</li>
<li>Its GDP per person was the lowest of the seven provinces.</li>
<li>Its economy was the smallest of the seven provinces.</li>
</ol>
<p>Which of them are correct?</p>
`,options:[`1 only`,`2 and 3 only`,`1, 2 and 3`,`1 and 2 only`],answer:3,explanation:`Statement 3 is wrong. With 13.1 percent of GDP Madhesh is the fourth economy; the smallest is Karnali (4.2 percent). 🔄`},{id:`T21`,label:`Expected – Practice`,stem:`<p>Which body prepared the second periodic plan of Madhesh Province?</p>
`,options:[`National Planning Commission`,`Province Public Service Commission`,`Province Policy and Planning Commission`,`Ministry of Home, Communication and Law`],answer:2,explanation:`The Province Policy and Planning Commission (प्रदेश नीति तथा योजना आयोग).`},{id:`T22`,label:`Expected – Practice`,stem:`<p>Where is the office of the Province Public Service Commission of Madhesh Province?</p>
`,options:[`Janakpurdham`,`Birgunj`,`Rajbiraj`,`Bardibas`],answer:0,explanation:`Janakpurdham, the capital. The Commission works under Article 244 and a provincial Act certified on 4 Ashoj 2076.`},{id:`T23`,label:`Pattern-Based – Reconstructed`,stem:`<p>Arrange these districts from east to west.</p>
<ol>
<li>Rautahat</li>
<li>Siraha</li>
<li>Mahottari</li>
<li>Parsa</li>
</ol>
`,options:[`2, 1, 3, 4`,`2, 3, 1, 4`,`3, 2, 1, 4`,`2, 3, 4, 1`],answer:1,explanation:`Siraha, Mahottari, Rautahat, Parsa. The full order is Saptari, Siraha, Dhanusha, Mahottari, Sarlahi, Rautahat, Bara, Parsa.`},{id:`T24`,label:`Pattern-Based – Reconstructed`,stem:`<p>Match the persons with what they are known for.</p>
<ol>
<li>Dr Ram Baran Yadav — A. First President of Nepal</li>
<li>Durgananda Jha — B. Janakpur bomb case of 2018 BS</li>
<li>Gajendra Narayan Singh — C. Nepal Sadbhavana movement</li>
<li>Vidyapati — D. Maithili poet</li>
</ol>
`,options:[`1-B, 2-A, 3-C, 4-D`,`1-A, 2-C, 3-B, 4-D`,`1-D, 2-B, 3-C, 4-A`,`1-A, 2-B, 3-C, 4-D`],answer:3,explanation:`Each is matched in order.`},{id:`T25`,label:`Expected – Practice`,stem:`<p>How many of the 32 House of Representatives seats of Madhesh Province did the Rastriya Swatantra Party win in the election of 21 Falgun 2082?</p>
`,options:[`16`,`24`,`30`,`32`],answer:2,explanation:`30. The Nepali Congress won one seat, in Bara; one result was under dispute when the tally was reported. 🔄`}]}]}]},i={title:`Geography Master Bank`,nep:`भूगोल — अतिरिक्त अभ्यास`,status:`draft_pending_verification`,subject:`Geography`,language:`en`,questions:[{id:`GEO-EN-001`,batch:1,stem:`Which is the highest mountain in the world, located on the Nepal–China border?`,options:[`Kanchenjunga`,`Lhotse`,`Mount Everest (Sagarmatha)`,`Makalu`],answer:2,explanation:`Mount Everest, 8,848.86 m (2020 survey), is the highest peak in the world.`},{id:`GEO-EN-002`,batch:1,stem:`How many of the world's 14 peaks above 8,000 m lie in Nepal?`,options:[`5`,`8`,`10`,`14`],answer:1,explanation:`Eight of the fourteen 8,000-metre peaks lie in Nepal.`},{id:`GEO-EN-003`,batch:1,stem:`Nepal is the only country in the world with which kind of national flag?`,options:[`Circular`,`Triangular`,`Non-rectangular`,`Square`],answer:2,explanation:`Nepal's flag is made of two stacked triangles and is the only non-rectangular national flag.`},{id:`GEO-EN-004`,batch:1,stem:`What is the capital of Nepal?`,options:[`Pokhara`,`Kathmandu`,`Lalitpur`,`Bhaktapur`],answer:1,explanation:`Kathmandu is the capital of Nepal.`},{id:`GEO-EN-005`,batch:1,stem:`How many provinces does Nepal have under the federal structure?`,options:[`5`,`6`,`7`,`8`],answer:2,explanation:`Nepal has seven provinces under the 2015 Constitution.`},{id:`GEO-EN-006`,batch:1,stem:`Which physical region of Nepal is the lowest and lies along the Indian border?`,options:[`Terai`,`Siwalik`,`Mahabharat`,`High Himal`],answer:0,explanation:`The Terai is the southern plain region of Nepal, lying along the Indian border.`},{id:`GEO-EN-007`,batch:1,stem:`Which range is the southernmost hill range of Nepal, also called Churia?`,options:[`Mahabharat`,`Siwalik`,`High Himal`,`Mid-hills`],answer:1,explanation:`The Siwalik range, also called Churia, is the outermost hill range.`},{id:`GEO-EN-008`,batch:1,stem:`Which is the longest river lying entirely within Nepal?`,options:[`Koshi`,`Gandaki`,`Karnali`,`Mahakali`],answer:2,explanation:`The Karnali is the longest river that flows entirely within Nepal.`},{id:`GEO-EN-009`,batch:1,stem:`Which is the largest lake in Nepal?`,options:[`Phewa`,`Rara`,`Tilicho`,`Gosaikunda`],answer:1,explanation:`Rara Lake in Mugu district is the largest lake in Nepal.`},{id:`GEO-EN-010`,batch:1,stem:`Phewa Lake is located near which city?`,options:[`Pokhara`,`Chitwan`,`Dhangadhi`,`Biratnagar`],answer:0,explanation:`Phewa Lake is beside Pokhara, in Gandaki Province.`},{id:`GEO-EN-011`,batch:1,stem:`Which was the first national park established in Nepal?`,options:[`Sagarmatha`,`Chitwan`,`Bardia`,`Langtang`],answer:1,explanation:`Chitwan National Park was established in 1973 as Nepal's first national park.`},{id:`GEO-EN-012`,batch:1,stem:`Lumbini, the birthplace of which religious founder, lies in Nepal?`,options:[`Confucius`,`Gautama Buddha`,`Guru Nanak`,`Mahavira`],answer:1,explanation:`Lumbini is the birthplace of Gautama Buddha.`},{id:`GEO-EN-013`,batch:1,stem:`In which district is Sagarmatha National Park located?`,options:[`Solukhumbu`,`Taplejung`,`Mustang`,`Dolpa`],answer:0,explanation:`Sagarmatha National Park lies in Solukhumbu district.`},{id:`GEO-EN-014`,batch:1,stem:`Which is the largest protected area in Nepal?`,options:[`Shey Phoksundo National Park`,`Chitwan National Park`,`Annapurna Conservation Area`,`Rara National Park`],answer:2,explanation:`The Annapurna Conservation Area is the largest protected area in Nepal.`},{id:`GEO-EN-015`,batch:1,stem:`What is the national flower of Nepal?`,options:[`Rose`,`Lotus`,`Rhododendron (Lali Gurans)`,`Marigold`],answer:2,explanation:`The rhododendron, locally called Lali Gurans, is Nepal's national flower.`},{id:`GEO-EN-016`,batch:1,stem:`What is the national bird of Nepal?`,options:[`Danphe (Impeyan pheasant)`,`Crow`,`Eagle`,`Peacock`],answer:0,explanation:`The Danphe, or Impeyan pheasant, is Nepal's national bird.`},{id:`GEO-EN-017`,batch:1,stem:`What is the national tree of Nepal?`,options:[`Sal`,`Chilaune`,`Rhododendron`,`Deodar`],answer:1,explanation:`The Chilaune (Schima wallichii) is Nepal's national tree.`},{id:`GEO-EN-018`,batch:1,stem:`Which country lies to the north of Nepal?`,options:[`India`,`China`,`Bhutan`,`Bangladesh`],answer:1,explanation:`China, specifically Tibet, lies to the north of Nepal.`},{id:`GEO-EN-019`,batch:1,stem:`Nepal shares its longest border with which country?`,options:[`China`,`India`,`Bhutan`,`Bangladesh`],answer:1,explanation:`Nepal shares most of its borders with India, to the south, east and west.`},{id:`GEO-EN-020`,batch:1,stem:`Mount Kanchenjunga lies on the border of Nepal and which country?`,options:[`Bhutan`,`India`,`China`,`Pakistan`],answer:1,explanation:`Kanchenjunga lies on the Nepal–India border, in Sikkim.`},{id:`GEO-EN-021`,batch:1,stem:`Which is the second-highest peak in Nepal?`,options:[`Lhotse`,`Kanchenjunga`,`Makalu`,`Dhaulagiri`],answer:1,explanation:`Kanchenjunga, at 8,586 m, is the second-highest peak in Nepal after Everest.`},{id:`GEO-EN-022`,batch:1,stem:`Mount Dhaulagiri, the seventh-highest peak in the world, is located in which province?`,options:[`Gandaki`,`Karnali`,`Lumbini`,`Bagmati`],answer:0,explanation:`Dhaulagiri lies in Gandaki Province.`},{id:`GEO-EN-023`,batch:1,stem:`Mount Makalu lies in which province?`,options:[`Koshi`,`Bagmati`,`Madhesh`,`Sudurpashchim`],answer:0,explanation:`Makalu, the fifth-highest peak in the world, lies in Koshi Province.`},{id:`GEO-EN-024`,batch:1,stem:`Mount Manaslu lies in which district?`,options:[`Gorkha`,`Mustang`,`Rasuwa`,`Dolakha`],answer:0,explanation:`Manaslu lies in Gorkha district.`},{id:`GEO-EN-025`,batch:1,stem:`The Kali Gandaki gorge lies between which two peaks?`,options:[`Everest and Lhotse`,`Dhaulagiri and Annapurna`,`Makalu and Kanchenjunga`,`Manaslu and Ganesh`],answer:1,explanation:`The Kali Gandaki gorge runs between Dhaulagiri and Annapurna.`},{id:`GEO-EN-026`,batch:1,stem:`What is the approximate total area of Nepal?`,options:[`100,000 sq km`,`147,181 sq km`,`200,000 sq km`,`90,000 sq km`],answer:1,explanation:`Nepal covers approximately 147,181 sq km.`},{id:`GEO-EN-027`,batch:1,stem:`How many districts does Nepal have?`,options:[`65`,`75`,`77`,`80`],answer:2,explanation:`Nepal has 77 districts.`},{id:`GEO-EN-028`,batch:1,stem:`Where is the lowest point of Nepal, Kechana Kalan, located?`,options:[`Jhapa`,`Ilam`,`Dhanusha`,`Kailali`],answer:0,explanation:`Kechana Kalan in Jhapa district is generally cited as Nepal's lowest point.`},{id:`GEO-EN-029`,batch:1,stem:`Which monsoon brings most of Nepal's annual rainfall?`,options:[`Northeast monsoon`,`Southwest monsoon`,`Western disturbance`,`Pre-monsoon`],answer:1,explanation:`The southwest monsoon, which blows from June to September, brings most of Nepal's rain.`},{id:`GEO-EN-030`,batch:1,stem:`What is Mount Everest called in Nepali?`,options:[`Sagarmatha`,`Gaurishankar`,`Chomolungma`,`Dhaulagiri`],answer:0,explanation:`Sagarmatha is the Nepali name for Everest. Chomolungma is the Tibetan name.`},{id:`GEO-EN-031`,batch:1,stem:`Which river is known as the 'Sorrow of Bihar'?`,options:[`Koshi`,`Gandaki`,`Bagmati`,`Karnali`],answer:0,explanation:`The Koshi is often called the Sorrow of Bihar because of its frequent floods.`},{id:`GEO-EN-032`,batch:1,stem:`Which major city does the Bagmati River flow through?`,options:[`Kathmandu`,`Pokhara`,`Biratnagar`,`Janakpur`],answer:0,explanation:`The Bagmati flows through Kathmandu and its valley.`},{id:`GEO-EN-033`,batch:1,stem:`Which animal is the emblem of Chitwan National Park?`,options:[`Snow leopard`,`One-horned rhinoceros`,`Red panda`,`Lion`],answer:1,explanation:`The one-horned rhinoceros is a flagship species of Chitwan National Park.`},{id:`GEO-EN-034`,batch:1,stem:`Rara National Park is mainly located in which districts?`,options:[`Mugu and Jumla`,`Dolpa and Mustang`,`Taplejung and Ilam`,`Kaski and Lamjung`],answer:0,explanation:`Rara National Park spans Mugu and Jumla districts.`},{id:`GEO-EN-035`,batch:1,stem:`Langtang National Park lies in which district?`,options:[`Rasuwa`,`Solukhumbu`,`Manang`,`Mustang`],answer:0,explanation:`Langtang National Park lies in Rasuwa district.`},{id:`GEO-EN-036`,batch:1,stem:`What is the capital of Koshi Province?`,options:[`Biratnagar`,`Janakpur`,`Hetauda`,`Pokhara`],answer:0,explanation:`Biratnagar is the capital of Koshi Province.`},{id:`GEO-EN-037`,batch:1,stem:`What is the capital of Madhesh Province?`,options:[`Janakpur`,`Biratnagar`,`Hetauda`,`Birgunj`],answer:0,explanation:`Janakpur is the capital of Madhesh Province.`},{id:`GEO-EN-038`,batch:1,stem:`What is the capital of Bagmati Province?`,options:[`Kathmandu`,`Hetauda`,`Bharatpur`,`Dhangadhi`],answer:1,explanation:`Hetauda is the capital of Bagmati Province.`},{id:`GEO-EN-039`,batch:1,stem:`What is the capital of Gandaki Province?`,options:[`Pokhara`,`Baglung`,`Gorkha`,`Damauli`],answer:0,explanation:`Pokhara is the capital of Gandaki Province.`},{id:`GEO-EN-040`,batch:1,stem:`What is the capital of Karnali Province?`,options:[`Birendranagar (Surkhet)`,`Jumla`,`Dailekh`,`Dhangadhi`],answer:0,explanation:`Birendranagar, in Surkhet district, is the capital of Karnali Province.`},{id:`GEO-EN-041`,batch:1,stem:`What is the capital of Sudurpashchim Province?`,options:[`Dhangadhi`,`Godawari`,`Mahendranagar`,`Silgadhi`],answer:1,explanation:`Godawari is the capital of Sudurpashchim Province.`},{id:`GEO-EN-042`,batch:1,stem:`What is the capital of Lumbini Province?`,options:[`Butwal`,`Deukhuri (Ghorahi)`,`Tansen`,`Bhairahawa`],answer:1,explanation:`Deukhuri (Ghorahi) is the capital of Lumbini Province.`},{id:`GEO-EN-043`,batch:1,stem:`Which mountain is the highest peak fully inside Nepal's Gandaki province?`,options:[`Annapurna I`,`Makalu`,`Lhotse`,`Cho Oyu`],answer:0,explanation:`Annapurna I, at 8,091 m, is the highest peak in Gandaki Province.`},{id:`GEO-EN-044`,batch:1,stem:`In which district is the sacred lake Gosaikunda located?`,options:[`Rasuwa`,`Dolakha`,`Mustang`,`Manang`],answer:0,explanation:`Gosaikunda lake lies in Rasuwa district.`},{id:`GEO-EN-045`,batch:1,stem:`Which is the fourth-highest peak in the world, next to Everest?`,options:[`Lhotse`,`Makalu`,`Cho Oyu`,`Manaslu`],answer:0,explanation:`Lhotse, at 8,516 m, is the fourth-highest peak in the world.`},{id:`GEO-EN-046`,batch:1,stem:`Cho Oyu, the sixth-highest peak in the world, lies on the border of Nepal and which country?`,options:[`China`,`India`,`Bhutan`,`Pakistan`],answer:0,explanation:`Cho Oyu lies on the Nepal–China (Tibet) border.`},{id:`GEO-EN-047`,batch:1,stem:`Which is the largest city of Nepal by population?`,options:[`Kathmandu`,`Pokhara`,`Biratnagar`,`Lalitpur`],answer:0,explanation:`Kathmandu Metropolitan City is the most populous city in Nepal.`},{id:`GEO-EN-048`,batch:1,stem:`The Terai region is mainly known for which economic activity?`,options:[`Mining`,`Agriculture`,`Fishing only`,`Tourism`],answer:1,explanation:`The fertile Terai plains are Nepal's main agricultural belt.`},{id:`GEO-EN-049`,batch:1,stem:`Sagarmatha National Park was inscribed as a UNESCO World Heritage Site in which year?`,options:[`1970`,`1979`,`1985`,`1997`],answer:1,explanation:`Sagarmatha National Park was inscribed in 1979.`},{id:`GEO-EN-050`,batch:1,stem:`Lumbini was inscribed as a UNESCO World Heritage Site in which year?`,options:[`1979`,`1990`,`1997`,`2000`],answer:2,explanation:`Lumbini was inscribed in 1997.`},{id:`GEO-EN-051`,batch:2,stem:`Sapta Koshi refers to how many major rivers that join to form the Koshi system?`,options:[`Five`,`Nine`,`Seven`,`Eleven`],answer:2,explanation:`Seven rivers join to form the Sapta Koshi system.`},{id:`GEO-EN-052`,batch:2,stem:`Which river forms much of Nepal's western border with India?`,options:[`Mahakali`,`Karnali`,`Bagmati`,`Kankai`],answer:0,explanation:`The Mahakali forms the western border with India.`},{id:`GEO-EN-053`,batch:2,stem:`In India, the Narayani river of Nepal is known as which river?`,options:[`Ganga`,`Gandak`,`Yamuna`,`Kosi`],answer:1,explanation:`The Narayani is called the Gandak in India.`},{id:`GEO-EN-054`,batch:2,stem:`In which district is Mount Ama Dablam located?`,options:[`Taplejung`,`Mustang`,`Dolpa`,`Solukhumbu`],answer:3,explanation:`Ama Dablam lies in the Khumbu region of Solukhumbu district.`},{id:`GEO-EN-055`,batch:2,stem:`In which district is Mount Machhapuchhre (Fishtail) located?`,options:[`Gorkha`,`Lamjung`,`Kaski`,`Parbat`],answer:2,explanation:`Machhapuchhre is located in Kaski district near Pokhara.`},{id:`GEO-EN-056`,batch:2,stem:`In which district is Tilicho Lake located?`,options:[`Mustang`,`Mugu`,`Dolpa`,`Manang`],answer:3,explanation:`Tilicho Lake lies in Manang district.`},{id:`GEO-EN-057`,batch:2,stem:`In which district is Phoksundo Lake located?`,options:[`Dolpa`,`Mugu`,`Jumla`,`Humla`],answer:0,explanation:`Phoksundo Lake lies in Dolpa district.`},{id:`GEO-EN-058`,batch:2,stem:`Which is the largest province of Nepal by area?`,options:[`Koshi`,`Lumbini`,`Karnali`,`Sudurpashchim`],answer:2,explanation:`Karnali is the largest province by area.`},{id:`GEO-EN-059`,batch:2,stem:`Which is the smallest province of Nepal by area?`,options:[`Madhesh`,`Bagmati`,`Lumbini`,`Gandaki`],answer:0,explanation:`Madhesh is the smallest province by area.`},{id:`GEO-EN-060`,batch:2,stem:`Which is the most populous province of Nepal?`,options:[`Madhesh`,`Koshi`,`Lumbini`,`Bagmati`],answer:3,explanation:`Bagmati has the largest population of the seven provinces.`},{id:`GEO-EN-061`,batch:2,stem:`The birthplace of Gautama Buddha lies in which province?`,options:[`Gandaki`,`Karnali`,`Lumbini`,`Bagmati`],answer:2,explanation:`Lumbini, the birthplace of Gautama Buddha, lies in Lumbini Province.`},{id:`GEO-EN-062`,batch:2,stem:`Chitwan National Park lies in which province?`,options:[`Madhesh`,`Bagmati`,`Gandaki`,`Lumbini`],answer:1,explanation:`Chitwan National Park is in Bagmati Province.`},{id:`GEO-EN-063`,batch:2,stem:`Mount Kanchenjunga lies in which province?`,options:[`Koshi`,`Sudurpashchim`,`Madhesh`,`Karnali`],answer:0,explanation:`Kanchenjunga lies in Taplejung district of Koshi Province.`},{id:`GEO-EN-064`,batch:2,stem:`Bardia National Park lies in which province?`,options:[`Karnali`,`Lumbini`,`Sudurpashchim`,`Gandaki`],answer:1,explanation:`Bardia National Park is in Lumbini Province.`},{id:`GEO-EN-065`,batch:2,stem:`Shuklaphanta National Park lies in which province?`,options:[`Sudurpashchim`,`Karnali`,`Lumbini`,`Madhesh`],answer:0,explanation:`Shuklaphanta National Park is in Sudurpashchim Province.`},{id:`GEO-EN-066`,batch:2,stem:`Mustang district lies in which province?`,options:[`Karnali`,`Lumbini`,`Gandaki`,`Koshi`],answer:2,explanation:`Mustang district is part of Gandaki Province.`},{id:`GEO-EN-067`,batch:2,stem:`Dolpa district lies in which province?`,options:[`Gandaki`,`Sudurpashchim`,`Lumbini`,`Karnali`],answer:3,explanation:`Dolpa district is part of Karnali Province.`},{id:`GEO-EN-068`,batch:2,stem:`Sagarmatha (Everest) lies in which province?`,options:[`Bagmati`,`Koshi`,`Karnali`,`Gandaki`],answer:1,explanation:`Everest lies in Solukhumbu district of Koshi Province.`},{id:`GEO-EN-069`,batch:2,stem:`Kathmandu district lies in which province?`,options:[`Koshi`,`Gandaki`,`Madhesh`,`Bagmati`],answer:3,explanation:`Kathmandu district is in Bagmati Province.`},{id:`GEO-EN-070`,batch:2,stem:`Ilam district lies in which province?`,options:[`Madhesh`,`Koshi`,`Bagmati`,`Karnali`],answer:1,explanation:`Ilam district is part of Koshi Province.`},{id:`GEO-EN-071`,batch:2,stem:`Dhanusha district lies in which province?`,options:[`Koshi`,`Lumbini`,`Madhesh`,`Gandaki`],answer:2,explanation:`Dhanusha district, home to Janakpur, is in Madhesh Province.`},{id:`GEO-EN-072`,batch:2,stem:`Kapilvastu district lies in which province?`,options:[`Lumbini`,`Karnali`,`Madhesh`,`Sudurpashchim`],answer:0,explanation:`Kapilvastu district is part of Lumbini Province.`},{id:`GEO-EN-073`,batch:2,stem:`Humla district lies in which province?`,options:[`Karnali`,`Sudurpashchim`,`Gandaki`,`Lumbini`],answer:0,explanation:`Humla district is part of Karnali Province.`},{id:`GEO-EN-074`,batch:2,stem:`Darchula district lies in which province?`,options:[`Karnali`,`Lumbini`,`Sudurpashchim`,`Koshi`],answer:2,explanation:`Darchula district is part of Sudurpashchim Province.`},{id:`GEO-EN-075`,batch:2,stem:`Parsa district lies in which province?`,options:[`Bagmati`,`Madhesh`,`Lumbini`,`Koshi`],answer:1,explanation:`Parsa district is part of Madhesh Province.`},{id:`GEO-EN-076`,batch:2,stem:`The town of Kakarbhitta, a major border point, lies in which district?`,options:[`Jhapa`,`Morang`,`Sunsari`,`Kailali`],answer:0,explanation:`Kakarbhitta is in Jhapa district.`},{id:`GEO-EN-077`,batch:2,stem:`Birgunj, a major trade town, lies in which district?`,options:[`Bara`,`Rautahat`,`Parsa`,`Sarlahi`],answer:2,explanation:`Birgunj is in Parsa district.`},{id:`GEO-EN-078`,batch:2,stem:`Bhairahawa, a major border town, lies in which district?`,options:[`Kapilvastu`,`Nawalparasi`,`Palpa`,`Rupandehi`],answer:3,explanation:`Bhairahawa is in Rupandehi district.`},{id:`GEO-EN-079`,batch:2,stem:`Which mountain range forms Nepal's northern border with Tibet?`,options:[`Himalaya`,`Mahabharat`,`Siwalik`,`Vindhya`],answer:0,explanation:`The Great Himalaya range forms Nepal's northern boundary.`},{id:`GEO-EN-080`,batch:2,stem:`Which physical region of Nepal has the highest population density?`,options:[`High Himal`,`High Mountain`,`Terai`,`Siwalik`],answer:2,explanation:`The Terai has the highest population density of Nepal's regions.`},{id:`GEO-EN-081`,batch:2,stem:`Who were the first two people confirmed to reach the summit of Mount Everest in 1953?`,options:[`Reinhold Messner and Peter Habeler`,`Tenzing Norgay and Edmund Hillary`,`George Mallory and Andrew Irvine`,`Edmund Hillary alone`],answer:1,explanation:`Tenzing Norgay and Edmund Hillary reached the summit on 29 May 1953.`},{id:`GEO-EN-082`,batch:2,stem:`Annapurna I was first climbed in 1950 by an expedition from which country?`,options:[`Switzerland`,`France`,`Japan`,`Britain`],answer:1,explanation:`The French expedition led by Maurice Herzog climbed Annapurna I in 1950.`},{id:`GEO-EN-083`,batch:2,stem:`Namche Bazaar, the main trading town of the Khumbu region, is in which district?`,options:[`Khotang`,`Taplejung`,`Solukhumbu`,`Bhojpur`],answer:2,explanation:`Namche Bazaar is in Solukhumbu district.`},{id:`GEO-EN-084`,batch:2,stem:`Jomsom, the headquarters of the Annapurna trekking route, is in which district?`,options:[`Manang`,`Mustang`,`Dolpa`,`Humla`],answer:1,explanation:`Jomsom is in Mustang district.`},{id:`GEO-EN-085`,batch:2,stem:`In which district is Mount Dhaulagiri located?`,options:[`Baglung`,`Myagdi`,`Parbat`,`Kaski`],answer:1,explanation:`Dhaulagiri lies in Myagdi district.`},{id:`GEO-EN-086`,batch:2,stem:`Nepal is landlocked. Which port city in India is commonly used for Nepal's sea trade?`,options:[`Mumbai`,`Chennai`,`Karachi`,`Kolkata`],answer:3,explanation:`Kolkata port is commonly used for Nepal's sea trade.`},{id:`GEO-EN-087`,batch:2,stem:`Biratnagar, the largest industrial city of Koshi Province, is in which district?`,options:[`Sunsari`,`Jhapa`,`Saptari`,`Morang`],answer:3,explanation:`Biratnagar is in Morang district.`},{id:`GEO-EN-088`,batch:2,stem:`Dhangadhi, a major city of Sudurpashchim Province, is in which district?`,options:[`Kanchanpur`,`Doti`,`Kailali`,`Bajhang`],answer:2,explanation:`Dhangadhi is in Kailali district.`},{id:`GEO-EN-089`,batch:2,stem:`Nepalgunj, a major city in western Nepal, is in which district?`,options:[`Bardiya`,`Kailali`,`Dang`,`Banke`],answer:3,explanation:`Nepalgunj is in Banke district.`},{id:`GEO-EN-090`,batch:2,stem:`Hetauda, the capital of Bagmati Province, is in which district?`,options:[`Chitwan`,`Dhading`,`Sindhupalchok`,`Makwanpur`],answer:3,explanation:`Hetauda is in Makwanpur district.`},{id:`GEO-EN-091`,batch:2,stem:`Bharatpur, a major city of Chitwan district, is in which province?`,options:[`Bagmati`,`Gandaki`,`Madhesh`,`Lumbini`],answer:0,explanation:`Bharatpur is in Chitwan district of Bagmati Province.`},{id:`GEO-EN-092`,batch:2,stem:`Taplejung district is located in which province?`,options:[`Madhesh`,`Karnali`,`Koshi`,`Sudurpashchim`],answer:2,explanation:`Taplejung district is part of Koshi Province.`},{id:`GEO-EN-093`,batch:2,stem:`Koshi Tappu Wildlife Reserve is known for wetland wildlife. In which province is it located?`,options:[`Madhesh`,`Lumbini`,`Koshi`,`Bagmati`],answer:2,explanation:`Koshi Tappu Wildlife Reserve is in Sunsari and Saptari districts of Koshi Province.`},{id:`GEO-EN-094`,batch:2,stem:`Jhapa district lies in which province?`,options:[`Madhesh`,`Lumbini`,`Karnali`,`Koshi`],answer:3,explanation:`Jhapa district is part of Koshi Province.`},{id:`GEO-EN-095`,batch:2,stem:`Rupandehi district lies in which province?`,options:[`Lumbini`,`Gandaki`,`Madhesh`,`Koshi`],answer:0,explanation:`Rupandehi district is part of Lumbini Province.`},{id:`GEO-EN-096`,batch:2,stem:`Surkhet district lies in which province?`,options:[`Lumbini`,`Karnali`,`Sudurpashchim`,`Gandaki`],answer:1,explanation:`Surkhet district is part of Karnali Province.`},{id:`GEO-EN-097`,batch:2,stem:`Jumla district lies in which province?`,options:[`Karnali`,`Gandaki`,`Koshi`,`Bagmati`],answer:0,explanation:`Jumla district is part of Karnali Province.`},{id:`GEO-EN-098`,batch:2,stem:`Sindhupalchok district lies in which province?`,options:[`Koshi`,`Madhesh`,`Gandaki`,`Bagmati`],answer:3,explanation:`Sindhupalchok district is part of Bagmati Province.`},{id:`GEO-EN-099`,batch:2,stem:`Lalitpur district lies in which province?`,options:[`Koshi`,`Bagmati`,`Madhesh`,`Lumbini`],answer:1,explanation:`Lalitpur district is part of Bagmati Province.`},{id:`GEO-EN-100`,batch:2,stem:`Bhaktapur district lies in which province?`,options:[`Koshi`,`Bagmati`,`Gandaki`,`Karnali`],answer:1,explanation:`Bhaktapur district is part of Bagmati Province.`},{id:`GEO-EN-101`,batch:3,stem:`Which hill range lies just north of the Siwalik range?`,options:[`Mahabharat`,`High Himal`,`Vindhya`,`Aravalli`],answer:0,explanation:`The Mahabharat range lies between the Siwalik range and the Mid-hills.`},{id:`GEO-EN-102`,batch:3,stem:`Which physical region of Nepal records the highest summer temperatures?`,options:[`High Himal`,`Mid-hills`,`Kathmandu Valley`,`Terai`],answer:3,explanation:`The Terai is the hottest region of Nepal, being the lowest and flattest.`},{id:`GEO-EN-103`,batch:3,stem:`Which season brings the monsoon to Nepal?`,options:[`Winter`,`Summer`,`Spring`,`Autumn`],answer:1,explanation:`The monsoon arrives in Nepal during the summer months, mainly June to September.`},{id:`GEO-EN-104`,batch:3,stem:`Which season follows the monsoon in Nepal?`,options:[`Winter`,`Spring`,`Summer`,`Autumn`],answer:3,explanation:`Autumn follows the monsoon, when skies usually clear.`},{id:`GEO-EN-105`,batch:3,stem:`Which region of Nepal is permanently covered by snow?`,options:[`Terai`,`High Himal`,`Siwalik`,`Mid-hills`],answer:1,explanation:`The High Himal stays snow-covered throughout the year.`},{id:`GEO-EN-106`,batch:3,stem:`Winter rainfall in western Nepal is mainly linked to which weather system?`,options:[`Southwest monsoon`,`Northeast trade winds`,`Cyclone from Bay of Bengal`,`Western disturbance`],answer:3,explanation:`Western disturbances bring winter rain and snow to the Himalaya.`},{id:`GEO-EN-107`,batch:3,stem:`Which region of Nepal lies in a rain shadow and has a dry climate?`,options:[`Terai`,`Chure`,`Mahabharat`,`Mustang`],answer:3,explanation:`Mustang lies north of the main Himalayan range and receives little monsoon rain.`},{id:`GEO-EN-108`,batch:3,stem:`Sal forests are mainly found in which region of Nepal?`,options:[`High Himal`,`High Mountain`,`Terai`,`Mid-hills`],answer:2,explanation:`Sal forests are typical of the lowland Terai and Siwalik belt.`},{id:`GEO-EN-109`,batch:3,stem:`Which crop is mainly grown in the Terai?`,options:[`Potato`,`Tea`,`Apple`,`Rice`],answer:3,explanation:`Rice is the main crop of the Terai plains.`},{id:`GEO-EN-110`,batch:3,stem:`Which district of Nepal is famous for tea gardens?`,options:[`Mustang`,`Ilam`,`Dolpa`,`Rasuwa`],answer:1,explanation:`Ilam district is well known for its tea gardens.`},{id:`GEO-EN-111`,batch:3,stem:`Large cardamom, a major cash crop, is grown mainly in which districts of Nepal?`,options:[`Ilam and Taplejung`,`Chitwan and Bara`,`Mustang and Dolpa`,`Kaski and Parbat`],answer:0,explanation:`Ilam and Taplejung in eastern Nepal are important cardamom-growing districts.`},{id:`GEO-EN-112`,batch:3,stem:`Which trek is famous for sunrise views of Dhaulagiri and Annapurna from Poon Hill?`,options:[`Everest Base Camp trek`,`Ghorepani Poon Hill trek`,`Langtang Valley trek`,`Manaslu Circuit trek`],answer:1,explanation:`Poon Hill, reached via Ghorepani, is famous for mountain sunrise views.`},{id:`GEO-EN-113`,batch:3,stem:`Everest Base Camp trek lies in which district?`,options:[`Khotang`,`Dolakha`,`Solukhumbu`,`Bhojpur`],answer:2,explanation:`The Everest Base Camp route passes through Solukhumbu district.`},{id:`GEO-EN-114`,batch:3,stem:`How many monument zones of Kathmandu Valley are recognised as UNESCO World Heritage Sites?`,options:[`7`,`3`,`5`,`9`],answer:0,explanation:`The Kathmandu Valley has seven cultural monument zones listed as a UNESCO site.`},{id:`GEO-EN-115`,batch:3,stem:`Snow leopards in Nepal are mainly found in which region?`,options:[`Terai`,`High Himalaya and Trans-Himalaya`,`Siwalik`,`Chitwan valley`],answer:1,explanation:`Snow leopards inhabit the high, rugged northern regions of Nepal.`},{id:`GEO-EN-116`,batch:3,stem:`Which line of latitude divides Earth into the Northern and Southern Hemispheres?`,options:[`Tropic of Cancer`,`Prime Meridian`,`Equator`,`Arctic Circle`],answer:2,explanation:`The Equator, at 0 degrees latitude, divides the Northern and Southern Hemispheres.`},{id:`GEO-EN-117`,batch:3,stem:`Which meridian is the reference point for 0 degrees longitude?`,options:[`Meridian at Paris`,`Meridian at Cairo`,`Prime Meridian at Greenwich`,`Meridian at Tokyo`],answer:2,explanation:`The Prime Meridian passes through Greenwich, London, and is at 0 degrees longitude.`},{id:`GEO-EN-118`,batch:3,stem:`Which is the largest island in the world?`,options:[`Madagascar`,`Borneo`,`Greenland`,`Baffin Island`],answer:2,explanation:`Greenland is the largest island in the world.`},{id:`GEO-EN-119`,batch:3,stem:`Which is the largest enclosed body of water on Earth?`,options:[`Caspian Sea`,`Lake Superior`,`Lake Victoria`,`Dead Sea`],answer:0,explanation:`The Caspian Sea is the largest enclosed body of water on Earth.`},{id:`GEO-EN-120`,batch:3,stem:`Which is the smallest continent by area?`,options:[`Australia`,`Antarctica`,`Europe`,`South America`],answer:0,explanation:`Australia is the smallest continent by area.`},{id:`GEO-EN-121`,batch:3,stem:`The Amazon River flows mainly through which country?`,options:[`Peru`,`Colombia`,`Brazil`,`Argentina`],answer:2,explanation:`The Amazon flows mainly through Brazil.`},{id:`GEO-EN-122`,batch:3,stem:`Which is the smallest ocean in the world?`,options:[`Indian Ocean`,`Southern Ocean`,`Arctic Ocean`,`Atlantic Ocean`],answer:2,explanation:`The Arctic Ocean is the smallest and shallowest of the world's oceans.`},{id:`GEO-EN-123`,batch:3,stem:`The Taj Mahal is located in which country?`,options:[`Pakistan`,`Bangladesh`,`Nepal`,`India`],answer:3,explanation:`The Taj Mahal is in Agra, India.`},{id:`GEO-EN-124`,batch:3,stem:`The Great Wall is located in which country?`,options:[`Japan`,`Mongolia`,`China`,`Korea`],answer:2,explanation:`The Great Wall of China is in China.`},{id:`GEO-EN-125`,batch:3,stem:`Which is the largest country in Africa by area?`,options:[`Sudan`,`Libya`,`Democratic Republic of the Congo`,`Algeria`],answer:3,explanation:`Algeria is the largest country in Africa by area.`},{id:`GEO-EN-126`,batch:3,stem:`The Pacific Ring of Fire is known for which natural feature?`,options:[`Glaciers`,`Coral reefs`,`Earthquakes and volcanoes`,`Deserts`],answer:2,explanation:`The Ring of Fire is a belt of frequent earthquakes and volcanic activity around the Pacific.`},{id:`GEO-EN-127`,batch:3,stem:`Which climate zone lies closest to the equator?`,options:[`Polar`,`Temperate`,`Arid`,`Tropical`],answer:3,explanation:`The tropical climate zone lies near the equator.`},{id:`GEO-EN-128`,batch:3,stem:`Which is the highest waterfall in the world?`,options:[`Angel Falls`,`Niagara Falls`,`Victoria Falls`,`Iguazu Falls`],answer:0,explanation:`Angel Falls in Venezuela is the world's highest uninterrupted waterfall.`},{id:`GEO-EN-129`,batch:3,stem:`Which canal connects the Atlantic and Pacific Oceans?`,options:[`Panama Canal`,`Suez Canal`,`Kiel Canal`,`Corinth Canal`],answer:0,explanation:`The Panama Canal links the Atlantic and Pacific Oceans.`},{id:`GEO-EN-130`,batch:3,stem:`Which canal connects the Mediterranean Sea and the Red Sea?`,options:[`Panama Canal`,`Kiel Canal`,`Grand Canal`,`Suez Canal`],answer:3,explanation:`The Suez Canal links the Mediterranean and the Red Sea.`},{id:`GEO-EN-131`,batch:3,stem:`What is the capital of Australia?`,options:[`Sydney`,`Canberra`,`Melbourne`,`Perth`],answer:1,explanation:`Canberra is the capital of Australia.`},{id:`GEO-EN-132`,batch:3,stem:`Machu Picchu, the Inca citadel, is located in which country?`,options:[`Bolivia`,`Ecuador`,`Chile`,`Peru`],answer:3,explanation:`Machu Picchu is in Peru.`},{id:`GEO-EN-133`,batch:3,stem:`Which sea lies between Europe and Africa?`,options:[`Red Sea`,`Caspian Sea`,`Black Sea`,`Mediterranean Sea`],answer:3,explanation:`The Mediterranean Sea lies between Europe and Africa.`},{id:`GEO-EN-134`,batch:3,stem:`Which is the largest continent by area?`,options:[`Africa`,`North America`,`Asia`,`Europe`],answer:2,explanation:`Asia is the largest continent by area and population.`},{id:`GEO-EN-135`,batch:3,stem:`Which is the largest ocean in the world?`,options:[`Pacific Ocean`,`Atlantic Ocean`,`Indian Ocean`,`Arctic Ocean`],answer:0,explanation:`The Pacific Ocean is the largest and deepest ocean.`},{id:`GEO-EN-136`,batch:3,stem:`Which is the largest desert in the world outside the polar regions?`,options:[`Gobi`,`Sahara`,`Kalahari`,`Thar`],answer:1,explanation:`The Sahara is the largest hot desert in the world.`},{id:`GEO-EN-137`,batch:3,stem:`The Indian Ocean lies to the south of which subcontinent?`,options:[`Arabian Peninsula`,`Scandinavia`,`Indian subcontinent`,`Iberian Peninsula`],answer:2,explanation:`The Indian Ocean lies south of the Indian subcontinent.`},{id:`GEO-EN-138`,batch:3,stem:`Mount Kilimanjaro, the highest mountain in Africa, is located in which country?`,options:[`Tanzania`,`Kenya`,`Ethiopia`,`Uganda`],answer:0,explanation:`Mount Kilimanjaro is in Tanzania.`},{id:`GEO-EN-139`,batch:3,stem:`The Mariana Trench, the deepest known point of the ocean, lies in which ocean?`,options:[`Pacific Ocean`,`Atlantic Ocean`,`Indian Ocean`,`Southern Ocean`],answer:0,explanation:`The Mariana Trench is in the western Pacific Ocean.`},{id:`GEO-EN-140`,batch:3,stem:`The Tropic of Cancer lies at approximately what latitude?`,options:[`0 degrees`,`23.5 degrees North`,`66.5 degrees North`,`45 degrees North`],answer:1,explanation:`The Tropic of Cancer lies at about 23.5 degrees North.`},{id:`GEO-EN-141`,batch:3,stem:`Which is the largest country in the world by area?`,options:[`Russia`,`Canada`,`China`,`United States`],answer:0,explanation:`Russia is the largest country in the world by area.`},{id:`GEO-EN-142`,batch:3,stem:`The Himalayas were formed by the collision of which two tectonic plates?`,options:[`Indian and Eurasian plates`,`African and Eurasian plates`,`Pacific and Australian plates`,`North American and Pacific plates`],answer:0,explanation:`The Himalayas formed as the Indian plate collided with the Eurasian plate.`},{id:`GEO-EN-143`,batch:3,stem:`Which is the highest mountain in South America?`,options:[`Chimborazo`,`Huascarán`,`Aconcagua`,`Cotopaxi`],answer:2,explanation:`Aconcagua in Argentina is the highest peak in South America.`},{id:`GEO-EN-144`,batch:3,stem:`Which is the longest continental mountain range in the world?`,options:[`Rockies`,`Andes`,`Urals`,`Alps`],answer:1,explanation:`The Andes is the longest continental mountain range.`},{id:`GEO-EN-145`,batch:3,stem:`Which strait separates Europe and Africa at the Atlantic entrance to the Mediterranean?`,options:[`Strait of Gibraltar`,`Bosphorus`,`Strait of Hormuz`,`Bab-el-Mandeb`],answer:0,explanation:`The Strait of Gibraltar separates Spain from Morocco.`},{id:`GEO-EN-146`,batch:3,stem:`Which country is the largest in South Asia by area?`,options:[`Pakistan`,`Bangladesh`,`Sri Lanka`,`India`],answer:3,explanation:`India is the largest country in South Asia by area.`},{id:`GEO-EN-147`,batch:3,stem:`Which is the smallest country in the world by area?`,options:[`Monaco`,`San Marino`,`Liechtenstein`,`Vatican City`],answer:3,explanation:`Vatican City is the smallest sovereign state in the world.`},{id:`GEO-EN-148`,batch:3,stem:`Which river flows through Cairo?`,options:[`Tigris`,`Nile`,`Euphrates`,`Jordan`],answer:1,explanation:`The Nile flows through Cairo, Egypt.`},{id:`GEO-EN-149`,batch:3,stem:`Mount Fuji, the highest mountain in Japan, is located on which island?`,options:[`Hokkaido`,`Honshu`,`Kyushu`,`Shikoku`],answer:1,explanation:`Mount Fuji lies on Honshu, Japan's largest island.`},{id:`GEO-EN-150`,batch:3,stem:`Which country has the longest coastline in the world?`,options:[`Russia`,`Canada`,`Australia`,`Indonesia`],answer:1,explanation:`Canada has the longest coastline of any country.`},{id:`GEO-EN-151`,batch:4,stem:`Limestone, a key raw material for cement, is widely mined in which country?`,options:[`Bhutan`,`Bangladesh`,`Myanmar`,`Nepal`],answer:3,explanation:`Limestone is extensively quarried in Nepal for cement production.`},{id:`GEO-EN-152`,batch:4,stem:`Which is the largest river system by discharge in Nepal?`,options:[`Koshi`,`Karnali`,`Gandaki`,`Mahakali`],answer:0,explanation:`The Koshi carries the largest volume of water among Nepal's major rivers.`},{id:`GEO-EN-153`,batch:4,stem:`What is the most widely used source of electricity in Nepal?`,options:[`Coal`,`Nuclear power`,`Hydroelectricity`,`Diesel generators`],answer:2,explanation:`Hydropower is Nepal's main source of electricity.`},{id:`GEO-EN-154`,batch:4,stem:`Because Nepal is landlocked, it depends heavily on which neighbour for access to seaports?`,options:[`China`,`India`,`Bhutan`,`Bangladesh`],answer:1,explanation:`Nepal uses Indian ports, mainly Kolkata, for most of its trade.`},{id:`GEO-EN-155`,batch:4,stem:`Chir pine, a valuable conifer, is commonly found in which zone of Nepal?`,options:[`High Himal`,`Terai floodplains`,`Trans-Himalaya`,`Mid-hills and Siwalik`],answer:3,explanation:`Chir pine forests grow in the Siwalik and lower hill zones.`},{id:`GEO-EN-156`,batch:4,stem:`Yarsagumba, a caterpillar fungus valued in traditional medicine, is found in which zone?`,options:[`Terai grasslands`,`Kathmandu Valley`,`High Himalayan meadows`,`Mid-hill terraces`],answer:2,explanation:`Yarsagumba grows in high-altitude alpine meadows.`},{id:`GEO-EN-157`,batch:4,stem:`Traditionally, which goods were carried by traders between Mustang and Tibet?`,options:[`Salt`,`Tea`,`Timber`,`Cotton`],answer:0,explanation:`Salt from Tibet was a major item in the Mustang trade route.`},{id:`GEO-EN-158`,batch:4,stem:`Maize is a major crop in which zone of Nepal?`,options:[`High Himal`,`Mid-hills`,`Terai`,`Siwalik`],answer:1,explanation:`Maize is widely grown on the terraced slopes of the mid-hills.`},{id:`GEO-EN-159`,batch:4,stem:`The 2015 Gorkha earthquake was caused by movement along the boundary of which two tectonic plates?`,options:[`African and Eurasian plates`,`Pacific and Australian plates`,`Indian and Eurasian plates`,`North American and Pacific plates`],answer:2,explanation:`The 2015 Gorkha earthquake occurred on the boundary of the Indian and Eurasian plates.`},{id:`GEO-EN-160`,batch:4,stem:`The epicentre of the 2015 Gorkha earthquake was near which village?`,options:[`Lukla`,`Namche`,`Jomsom`,`Barpak`],answer:3,explanation:`The epicentre was near Barpak in Gorkha district.`},{id:`GEO-EN-161`,batch:4,stem:`Which Himalayan hazard occurs when a glacial lake bursts its natural dam?`,options:[`Glacial lake outburst flood`,`Avalanche of rock`,`Dust storm`,`Drought`],answer:0,explanation:`Glacial lake outburst floods, called GLOFs, are a serious hazard in the Himalaya.`},{id:`GEO-EN-162`,batch:4,stem:`Nepal's rivers are mainly fed by which two sources?`,options:[`Groundwater and desalination`,`Tidal flow and sea spray`,`Snowmelt and monsoon rainfall`,`Volcanic springs and lakes`],answer:2,explanation:`Himalayan rivers rely on snowmelt and seasonal monsoon rain.`},{id:`GEO-EN-163`,batch:4,stem:`Which ecosystem mosaic is typical of Chitwan and Bardia?`,options:[`Alpine tundra`,`Desert scrub`,`Mangrove forest`,`Tall grassland and sal forest`],answer:3,explanation:`Chitwan and Bardia combine tall grasslands with sal forests.`},{id:`GEO-EN-164`,batch:4,stem:`Which fragile hill belt in Nepal faces heavy deforestation and erosion?`,options:[`Chure`,`Mahabharat`,`High Himal`,`Kathmandu Valley`],answer:0,explanation:`The Chure, or Siwalik hills, suffer serious forest loss and erosion.`},{id:`GEO-EN-165`,batch:4,stem:`Oak forests are widespread in which zone of Nepal?`,options:[`Terai`,`Trans-Himalaya`,`Siwalik lowlands`,`Hills`],answer:3,explanation:`Oak forests are characteristic of the middle hill zone.`},{id:`GEO-EN-166`,batch:4,stem:`Which inflow is among the largest sources of foreign currency for Nepal?`,options:[`Foreign aid only`,`Mineral exports`,`Oil revenue`,`Remittances`],answer:3,explanation:`Remittances from Nepalis working abroad are a major income source.`},{id:`GEO-EN-167`,batch:4,stem:`The red panda is most often associated with which part of Nepal?`,options:[`Eastern hill forests`,`Terai grasslands`,`Western deserts`,`Central Valley`],answer:0,explanation:`Red pandas live in high-altitude forests, mainly in eastern Nepal.`},{id:`GEO-EN-168`,batch:4,stem:`Nepal lies within which global biodiversity hotspot?`,options:[`Himalaya`,`Sundaland`,`Caribbean`,`Mediterranean Basin`],answer:0,explanation:`The Himalaya is a recognised global biodiversity hotspot that includes Nepal.`},{id:`GEO-EN-169`,batch:4,stem:`The Narayani River flows through which district famous for its national park?`,options:[`Bardia`,`Chitwan`,`Shuklaphanta`,`Sagarmatha`],answer:1,explanation:`The Narayani flows through Chitwan district.`},{id:`GEO-EN-170`,batch:4,stem:`The Arun River originates in which country?`,options:[`India`,`China`,`Bhutan`,`Bangladesh`],answer:1,explanation:`The Arun rises in Tibet, China, before entering Nepal.`},{id:`GEO-EN-171`,batch:4,stem:`Run-of-river hydropower projects generate power mainly by using which feature?`,options:[`Large storage reservoirs`,`Ocean tides`,`Natural river flow`,`Underground steam`],answer:2,explanation:`Run-of-river plants use the natural flow of the river with little or no storage.`},{id:`GEO-EN-172`,batch:4,stem:`Which sector employs the largest share of Nepal's workforce?`,options:[`Agriculture`,`Manufacturing`,`Mining`,`Information technology`],answer:0,explanation:`Agriculture is the largest source of employment in Nepal.`},{id:`GEO-EN-173`,batch:4,stem:`Nepal's major rivers mainly originate in which mountain region?`,options:[`The Alps`,`The Himalaya`,`The Andes`,`The Rockies`],answer:1,explanation:`The major rivers of Nepal rise in the Himalaya.`},{id:`GEO-EN-174`,batch:4,stem:`The Ganges ultimately drains into which body of water?`,options:[`Arabian Sea`,`Red Sea`,`Bay of Bengal`,`Caspian Sea`],answer:2,explanation:`The Ganges flows into the Bay of Bengal.`},{id:`GEO-EN-175`,batch:4,stem:`Which mountain range runs through central Europe?`,options:[`Pyrenees`,`Urals`,`Alps`,`Carpathians`],answer:2,explanation:`The Alps lie across central Europe.`},{id:`GEO-EN-176`,batch:4,stem:`The Sahel region lies on the southern edge of which desert?`,options:[`Sahara`,`Gobi`,`Kalahari`,`Atacama`],answer:0,explanation:`The Sahel is the transition zone south of the Sahara.`},{id:`GEO-EN-177`,batch:4,stem:`Which country is the largest copper producer in the world?`,options:[`Peru`,`Zambia`,`Canada`,`Chile`],answer:3,explanation:`Chile is the world's largest producer of copper.`},{id:`GEO-EN-178`,batch:4,stem:`Which country is the largest gold producer in the world?`,options:[`South Africa`,`Australia`,`Russia`,`China`],answer:3,explanation:`China is the largest producer of gold in the world.`},{id:`GEO-EN-179`,batch:4,stem:`Which country holds the largest proven oil reserves?`,options:[`Saudi Arabia`,`Venezuela`,`Russia`,`Iran`],answer:1,explanation:`Venezuela holds the largest proven oil reserves.`},{id:`GEO-EN-180`,batch:4,stem:`Which country is the largest producer of coal?`,options:[`China`,`India`,`United States`,`Australia`],answer:0,explanation:`China is the world's largest coal producer.`},{id:`GEO-EN-181`,batch:4,stem:`Which country is the largest producer of tea?`,options:[`India`,`China`,`Sri Lanka`,`Kenya`],answer:1,explanation:`China is the largest tea producer in the world.`},{id:`GEO-EN-182`,batch:4,stem:`Which country is the largest producer of coffee?`,options:[`Colombia`,`Brazil`,`Vietnam`,`Ethiopia`],answer:1,explanation:`Brazil is the world's largest coffee producer.`},{id:`GEO-EN-183`,batch:4,stem:`Which country is the largest producer of natural rubber?`,options:[`Malaysia`,`Indonesia`,`Vietnam`,`Thailand`],answer:3,explanation:`Thailand is the world's largest producer of natural rubber.`},{id:`GEO-EN-184`,batch:4,stem:`Which country is the largest producer of cobalt?`,options:[`Zambia`,`Democratic Republic of the Congo`,`Madagascar`,`South Africa`],answer:1,explanation:`The DRC produces most of the world's cobalt.`},{id:`GEO-EN-185`,batch:4,stem:`Which is the largest tropical rainforest in the world?`,options:[`Congo Basin`,`Amazon`,`Borneo`,`Western Ghats`],answer:1,explanation:`The Amazon rainforest is the largest tropical rainforest.`},{id:`GEO-EN-186`,batch:4,stem:`Which is the second-largest tropical rainforest in the world?`,options:[`Amazon`,`Borneo`,`Sumatra`,`Congo Basin`],answer:3,explanation:`The Congo Basin is the second-largest tropical rainforest.`},{id:`GEO-EN-187`,batch:4,stem:`Which is the world's largest coral reef system?`,options:[`Great Barrier Reef`,`Red Sea Reef`,`Maldives Atoll`,`Belize Barrier Reef`],answer:0,explanation:`The Great Barrier Reef, off Australia, is the largest coral reef system.`},{id:`GEO-EN-188`,batch:4,stem:`Which lake, between Israel and Jordan, is famous for its extreme salinity?`,options:[`Caspian Sea`,`Lake Chad`,`Dead Sea`,`Lake Baikal`],answer:2,explanation:`The Dead Sea is one of the saltiest bodies of water on Earth.`},{id:`GEO-EN-189`,batch:4,stem:`Which lake has dramatically shrunk because of water diversion for irrigation?`,options:[`Lake Superior`,`Aral Sea`,`Lake Titicaca`,`Lake Geneva`],answer:1,explanation:`The Aral Sea has shrunk greatly due to irrigation diversions.`},{id:`GEO-EN-190`,batch:4,stem:`Which biome is characterised by coniferous forests across northern latitudes?`,options:[`Savanna`,`Tundra`,`Taiga or boreal forest`,`Mangrove`],answer:2,explanation:`The taiga, or boreal forest, is the largest land biome of the north.`},{id:`GEO-EN-191`,batch:4,stem:`Which layer of permanently frozen ground is found in Arctic regions?`,options:[`Bedrock`,`Permafrost`,`Loess`,`Laterite`],answer:1,explanation:`Permafrost is ground that stays frozen for at least two years.`},{id:`GEO-EN-192`,batch:4,stem:`Which human-made chemicals have been the main cause of ozone layer damage?`,options:[`Chlorofluorocarbons (CFCs)`,`Carbon dioxide`,`Methane`,`Nitrogen oxides only`],answer:0,explanation:`CFCs broke down stratospheric ozone, and the Montreal Protocol phased them out.`},{id:`GEO-EN-193`,batch:4,stem:`Which gas is the most significant human-caused greenhouse gas?`,options:[`Oxygen`,`Helium`,`Argon`,`Carbon dioxide`],answer:3,explanation:`Carbon dioxide from fossil fuels is the largest human-caused greenhouse gas.`},{id:`GEO-EN-194`,batch:4,stem:`Which energy source is renewable?`,options:[`Coal`,`Natural gas`,`Solar energy`,`Crude oil`],answer:2,explanation:`Solar energy comes from sunlight, which is renewable.`},{id:`GEO-EN-195`,batch:4,stem:`Which is the longest river in Europe?`,options:[`Danube`,`Rhine`,`Volga`,`Dnieper`],answer:2,explanation:`The Volga is the longest river in Europe.`},{id:`GEO-EN-196`,batch:4,stem:`Which is the longest river in Africa?`,options:[`Nile`,`Congo`,`Niger`,`Zambezi`],answer:0,explanation:`The Nile is the longest river in Africa.`},{id:`GEO-EN-197`,batch:4,stem:`Which is the largest salt flat in the world?`,options:[`Salar de Uyuni`,`Death Valley`,`Great Salt Lake`,`Lake Eyre`],answer:0,explanation:`Salar de Uyuni in Bolivia is the largest salt flat in the world.`},{id:`GEO-EN-198`,batch:4,stem:`The Atacama Desert, one of the driest places on Earth, is located in which country?`,options:[`Peru`,`Argentina`,`Chile`,`Bolivia`],answer:2,explanation:`The Atacama Desert lies mainly in northern Chile.`},{id:`GEO-EN-199`,batch:4,stem:`Which gas makes up the largest share of Earth's atmosphere?`,options:[`Oxygen`,`Carbon dioxide`,`Argon`,`Nitrogen`],answer:3,explanation:`Nitrogen makes up about 78 percent of the atmosphere.`},{id:`GEO-EN-200`,batch:4,stem:`Which major Himalayan river carries the largest sediment load into India and Bangladesh?`,options:[`Mahakali`,`Koshi`,`Karnali`,`Narayani`],answer:1,explanation:`The Koshi is well known for heavy sediment and floods downstream.`},{id:`GEO-EN-201`,batch:5,stem:`Which city in Nepal is known as the City of Lakes?`,options:[`Pokhara`,`Janakpur`,`Dhangadhi`,`Biratnagar`],answer:0,explanation:`Pokhara is known for its lakes, especially Phewa Lake.`},{id:`GEO-EN-202`,batch:5,stem:`Which ancient Newar city is known as the City of Devotees?`,options:[`Patan`,`Birgunj`,`Dhulikhel`,`Bhaktapur`],answer:3,explanation:`Bhaktapur is traditionally called the City of Devotees.`},{id:`GEO-EN-203`,batch:5,stem:`Which city in the Kathmandu Valley is known for its traditional arts and crafts?`,options:[`Hetauda`,`Patan (Lalitpur)`,`Dharan`,`Butwal`],answer:1,explanation:`Patan, also called Lalitpur, is famous for its arts and metalwork.`},{id:`GEO-EN-204`,batch:5,stem:`Which temple in Janakpur is dedicated to Sita?`,options:[`Pashupatinath`,`Muktinath`,`Janaki Mandir`,`Swayambhunath`],answer:2,explanation:`Janaki Mandir is a major temple dedicated to Sita in Janakpur.`},{id:`GEO-EN-205`,batch:5,stem:`Muktinath, a sacred temple, is located in which district?`,options:[`Manang`,`Dolpa`,`Mustang`,`Mugu`],answer:2,explanation:`Muktinath lies in Mustang district.`},{id:`GEO-EN-206`,batch:5,stem:`Pashupatinath Temple is located in which city?`,options:[`Kathmandu`,`Pokhara`,`Lalitpur`,`Bhaktapur`],answer:0,explanation:`Pashupatinath Temple is on the banks of the Bagmati River in Kathmandu.`},{id:`GEO-EN-207`,batch:5,stem:`Swayambhunath, also called the Monkey Temple, is located in which city?`,options:[`Patan`,`Kathmandu`,`Pokhara`,`Dhulikhel`],answer:1,explanation:`Swayambhunath stands on a hill west of Kathmandu.`},{id:`GEO-EN-208`,batch:5,stem:`Boudhanath, one of the largest stupas in the world, is located in which city?`,options:[`Lumbini`,`Kathmandu`,`Patan`,`Janakpur`],answer:1,explanation:`Boudhanath is a major Buddhist stupa in Kathmandu.`},{id:`GEO-EN-209`,batch:5,stem:`Tribhuvan International Airport, Nepal's main international airport, is located in which city?`,options:[`Pokhara`,`Biratnagar`,`Bharatpur`,`Kathmandu`],answer:3,explanation:`Tribhuvan International Airport serves Kathmandu.`},{id:`GEO-EN-210`,batch:5,stem:`Which highway links Kathmandu and Pokhara?`,options:[`Mahendra Highway`,`Arniko Highway`,`Prithvi Highway`,`Siddhartha Highway`],answer:2,explanation:`The Prithvi Highway connects Kathmandu with Pokhara.`},{id:`GEO-EN-211`,batch:5,stem:`Which highway runs east to west across the Terai and hills of Nepal?`,options:[`Mahendra Highway`,`Prithvi Highway`,`Arniko Highway`,`Tribhuvan Highway`],answer:0,explanation:`The Mahendra Highway is the main east-west road through the Terai.`},{id:`GEO-EN-212`,batch:5,stem:`Arniko Highway connects Kathmandu with which border point?`,options:[`Birgunj, on the Indian border`,`Kodari, on the Tibet border`,`Bhairahawa, on the Indian border`,`Kakarbhitta, on the Indian border`],answer:1,explanation:`Arniko Highway runs north to the Kodari border crossing with China.`},{id:`GEO-EN-213`,batch:5,stem:`The Kalapani area is a boundary issue between Nepal and which country?`,options:[`India`,`China`,`Bhutan`,`Bangladesh`],answer:0,explanation:`Kalapani is a disputed border area between Nepal and India.`},{id:`GEO-EN-214`,batch:5,stem:`The Sherpa community is mainly associated with which district?`,options:[`Dhading`,`Solukhumbu`,`Parsa`,`Jhapa`],answer:1,explanation:`The Sherpa people are closely linked to the Khumbu area of Solukhumbu.`},{id:`GEO-EN-215`,batch:5,stem:`The Tharu community is mainly found in which region?`,options:[`High Himal`,`Mid-hills`,`Kathmandu Valley`,`Terai`],answer:3,explanation:`The Tharu people are an indigenous community of the Terai.`},{id:`GEO-EN-216`,batch:5,stem:`Gurung and Magar communities are largely found in which region?`,options:[`Terai`,`High Himal`,`Siwalik`,`Hills`],answer:3,explanation:`Gurung and Magar communities live mostly in the hill regions.`},{id:`GEO-EN-217`,batch:5,stem:`The Newar community is associated mainly with which area?`,options:[`Kathmandu Valley`,`Terai`,`Mustang`,`Dolpa`],answer:0,explanation:`The Newar people are the traditional inhabitants of the Kathmandu Valley.`},{id:`GEO-EN-218`,batch:5,stem:`What is the official national language of Nepal?`,options:[`Hindi`,`Maithili`,`Nepali`,`Sanskrit`],answer:2,explanation:`Nepali is the official language of the federal government.`},{id:`GEO-EN-219`,batch:5,stem:`Which religion is the largest in Nepal?`,options:[`Buddhism`,`Islam`,`Christianity`,`Hinduism`],answer:3,explanation:`Hinduism is the largest religion in Nepal by number of followers.`},{id:`GEO-EN-220`,batch:5,stem:`What is the currency of Nepal?`,options:[`Indian rupee`,`Bhutanese ngultrum`,`Nepali rupee`,`Bangladeshi taka`],answer:2,explanation:`The Nepali rupee is the official currency of Nepal.`},{id:`GEO-EN-221`,batch:5,stem:`What is the time zone of Nepal?`,options:[`UTC+05:30`,`UTC+06:00`,`UTC+05:45`,`UTC+05:00`],answer:2,explanation:`Nepal Standard Time is UTC+05:45.`},{id:`GEO-EN-222`,batch:5,stem:`Which calendar is officially used in Nepal alongside the Gregorian calendar?`,options:[`Hijri`,`Chinese lunar`,`Bikram Sambat`,`Julian`],answer:2,explanation:`Bikram Sambat is the official Nepali calendar used alongside the Gregorian calendar.`},{id:`GEO-EN-223`,batch:5,stem:`What is the capital of Japan?`,options:[`Osaka`,`Tokyo`,`Kyoto`,`Nagoya`],answer:1,explanation:`Tokyo is the capital of Japan.`},{id:`GEO-EN-224`,batch:5,stem:`What is the capital of Canada?`,options:[`Toronto`,`Montreal`,`Ottawa`,`Vancouver`],answer:2,explanation:`Ottawa is the capital of Canada.`},{id:`GEO-EN-225`,batch:5,stem:`What is the capital of Brazil?`,options:[`Rio de Janeiro`,`São Paulo`,`Salvador`,`Brasília`],answer:3,explanation:`Brasília became the capital of Brazil in 1960.`},{id:`GEO-EN-226`,batch:5,stem:`What is the capital of Egypt?`,options:[`Alexandria`,`Luxor`,`Giza`,`Cairo`],answer:3,explanation:`Cairo is the capital of Egypt.`},{id:`GEO-EN-227`,batch:5,stem:`What is the capital of Turkey?`,options:[`Istanbul`,`Ankara`,`Izmir`,`Antalya`],answer:1,explanation:`Ankara is the capital of Turkey.`},{id:`GEO-EN-228`,batch:5,stem:`What is the capital of Mongolia?`,options:[`Almaty`,`Ulaanbaatar`,`Bishkek`,`Astana`],answer:1,explanation:`Ulaanbaatar is the capital of Mongolia.`},{id:`GEO-EN-229`,batch:5,stem:`What is the capital of Bhutan?`,options:[`Paro`,`Punakha`,`Bumthang`,`Thimphu`],answer:3,explanation:`Thimphu is the capital of Bhutan.`},{id:`GEO-EN-230`,batch:5,stem:`What is the capital of Bangladesh?`,options:[`Chittagong`,`Sylhet`,`Dhaka`,`Khulna`],answer:2,explanation:`Dhaka is the capital of Bangladesh.`},{id:`GEO-EN-231`,batch:5,stem:`What is the capital of Pakistan?`,options:[`Karachi`,`Islamabad`,`Lahore`,`Peshawar`],answer:1,explanation:`Islamabad is the capital of Pakistan.`},{id:`GEO-EN-232`,batch:5,stem:`What is the capital of Myanmar?`,options:[`Naypyidaw`,`Yangon`,`Mandalay`,`Bagan`],answer:0,explanation:`Naypyidaw is the capital of Myanmar.`},{id:`GEO-EN-233`,batch:5,stem:`What is the capital of Thailand?`,options:[`Bangkok`,`Chiang Mai`,`Phuket`,`Pattaya`],answer:0,explanation:`Bangkok is the capital of Thailand.`},{id:`GEO-EN-234`,batch:5,stem:`What is the capital of Afghanistan?`,options:[`Kabul`,`Kandahar`,`Herat`,`Mazar-i-Sharif`],answer:0,explanation:`Kabul is the capital of Afghanistan.`},{id:`GEO-EN-235`,batch:5,stem:`What is the capital of Iran?`,options:[`Isfahan`,`Shiraz`,`Tabriz`,`Tehran`],answer:3,explanation:`Tehran is the capital of Iran.`},{id:`GEO-EN-236`,batch:5,stem:`What is the capital of Iraq?`,options:[`Basra`,`Baghdad`,`Mosul`,`Erbil`],answer:1,explanation:`Baghdad is the capital of Iraq.`},{id:`GEO-EN-237`,batch:5,stem:`What is the capital of Saudi Arabia?`,options:[`Riyadh`,`Jeddah`,`Mecca`,`Dammam`],answer:0,explanation:`Riyadh is the capital of Saudi Arabia.`},{id:`GEO-EN-238`,batch:5,stem:`What is the capital of Germany?`,options:[`Munich`,`Berlin`,`Hamburg`,`Frankfurt`],answer:1,explanation:`Berlin is the capital of Germany.`},{id:`GEO-EN-239`,batch:5,stem:`What is the capital of Kenya?`,options:[`Mombasa`,`Kisumu`,`Nakuru`,`Nairobi`],answer:3,explanation:`Nairobi is the capital of Kenya.`},{id:`GEO-EN-240`,batch:5,stem:`What is the capital of Nigeria?`,options:[`Abuja`,`Lagos`,`Kano`,`Ibadan`],answer:0,explanation:`Abuja became the capital of Nigeria in 1991.`},{id:`GEO-EN-241`,batch:5,stem:`What is the capital of Argentina?`,options:[`Córdoba`,`Rosario`,`Buenos Aires`,`Mendoza`],answer:2,explanation:`Buenos Aires is the capital of Argentina.`},{id:`GEO-EN-242`,batch:5,stem:`What is the capital of Peru?`,options:[`Cusco`,`Arequipa`,`Trujillo`,`Lima`],answer:3,explanation:`Lima is the capital of Peru.`},{id:`GEO-EN-243`,batch:5,stem:`What is the capital of Chile?`,options:[`Valparaíso`,`Santiago`,`Concepción`,`Antofagasta`],answer:1,explanation:`Santiago is the capital of Chile.`},{id:`GEO-EN-244`,batch:5,stem:`What is the capital of the Philippines?`,options:[`Quezon City`,`Cebu`,`Davao`,`Manila`],answer:3,explanation:`Manila is the capital of the Philippines.`},{id:`GEO-EN-245`,batch:5,stem:`What is the capital of Vietnam?`,options:[`Ho Chi Minh City`,`Da Nang`,`Hanoi`,`Hue`],answer:2,explanation:`Hanoi is the capital of Vietnam.`},{id:`GEO-EN-246`,batch:5,stem:`What is the capital of Morocco?`,options:[`Rabat`,`Casablanca`,`Marrakesh`,`Fez`],answer:0,explanation:`Rabat is the capital of Morocco.`},{id:`GEO-EN-247`,batch:5,stem:`Which country has the largest population in the world as of 2023?`,options:[`India`,`China`,`United States`,`Indonesia`],answer:0,explanation:`India overtook China as the most populous country in 2023, according to the UN.`},{id:`GEO-EN-248`,batch:5,stem:`What is the capital of China?`,options:[`Shanghai`,`Guangzhou`,`Shenzhen`,`Beijing`],answer:3,explanation:`Beijing is the capital of China.`},{id:`GEO-EN-249`,batch:5,stem:`What is the capital of Russia?`,options:[`Saint Petersburg`,`Novosibirsk`,`Moscow`,`Kazan`],answer:2,explanation:`Moscow is the capital of Russia.`},{id:`GEO-EN-250`,batch:5,stem:`Which Nepali city is a major commercial and trade hub on the Indian border in the Terai?`,options:[`Janakpur`,`Hetauda`,`Birgunj`,`Dhangadhi`],answer:2,explanation:`Birgunj in Parsa district is a major trade and industrial centre on the Indian border.`},{id:`GEO-EN-251`,batch:6,stem:`Makalu Barun National Park is mainly located in which district?`,options:[`Taplejung`,`Sankhuwasabha`,`Dolakha`,`Rasuwa`],answer:1,explanation:`Makalu Barun National Park lies largely in Sankhuwasabha district.`},{id:`GEO-EN-252`,batch:6,stem:`Khaptad National Park lies in which province?`,options:[`Karnali`,`Lumbini`,`Gandaki`,`Sudurpashchim`],answer:3,explanation:`Khaptad National Park is in Sudurpashchim Province.`},{id:`GEO-EN-253`,batch:6,stem:`Parsa Wildlife Reserve is located in which district?`,options:[`Bara`,`Parsa`,`Rautahat`,`Sarlahi`],answer:1,explanation:`Parsa Wildlife Reserve is in Parsa district.`},{id:`GEO-EN-254`,batch:6,stem:`Banke National Park is located in which district?`,options:[`Bardiya`,`Banke`,`Kailali`,`Dang`],answer:1,explanation:`Banke National Park is in Banke district.`},{id:`GEO-EN-255`,batch:6,stem:`Shivapuri Nagarjun National Park lies on the edge of which city?`,options:[`Pokhara`,`Biratnagar`,`Kathmandu`,`Janakpur`],answer:2,explanation:`Shivapuri Nagarjun National Park borders Kathmandu.`},{id:`GEO-EN-256`,batch:6,stem:`Begnas Lake is part of which lake group near Pokhara?`,options:[`Pokhara valley lakes`,`Himalayan glacial lakes`,`Terai oxbow lakes`,`Rara group`],answer:0,explanation:`Begnas is one of the lakes in the Pokhara valley.`},{id:`GEO-EN-257`,batch:6,stem:`Thorong La, a high pass on the Annapurna Circuit, is at about what elevation?`,options:[`3,500 m`,`4,200 m`,`5,416 m`,`6,500 m`],answer:2,explanation:`Thorong La is about 5,416 metres high.`},{id:`GEO-EN-258`,batch:6,stem:`Which glacier flows down from the slopes of Mount Everest?`,options:[`Gangotri Glacier`,`Siachen Glacier`,`Baltoro Glacier`,`Khumbu Glacier`],answer:3,explanation:`The Khumbu Glacier descends from the Everest region.`},{id:`GEO-EN-259`,batch:6,stem:`Nepal's northern neighbour, Tibet, lies on which high plateau?`,options:[`Tibetan Plateau`,`Deccan Plateau`,`Colorado Plateau`,`Ethiopian Highlands`],answer:0,explanation:`Tibet lies on the Tibetan Plateau, the highest plateau in the world.`},{id:`GEO-EN-260`,batch:6,stem:`The Terai plain was largely formed by deposits of what material?`,options:[`River alluvium`,`Volcanic ash`,`Glacial ice`,`Coral debris`],answer:0,explanation:`Rivers from the Himalaya deposited sediments that formed the Terai plain.`},{id:`GEO-EN-261`,batch:6,stem:`The Siwalik hills are made mainly of which rock type?`,options:[`Granite`,`Sedimentary rock`,`Marble`,`Basalt`],answer:1,explanation:`The Siwalik hills consist mainly of sedimentary rock.`},{id:`GEO-EN-262`,batch:6,stem:`The Mahabharat range belongs to which Himalayan zone?`,options:[`Tethys Himalaya`,`Trans-Himalaya`,`Lesser Himalaya`,`Brahmaputra plain`],answer:2,explanation:`The Mahabharat range lies in the Lesser Himalaya zone.`},{id:`GEO-EN-263`,batch:6,stem:`Which Himalayan zone contains the highest peaks, including Everest?`,options:[`Siwalik`,`Greater (High) Himalaya`,`Terai`,`Mahabharat`],answer:1,explanation:`The Greater Himalaya zone holds the world's highest peaks.`},{id:`GEO-EN-264`,batch:6,stem:`Which zone of Nepal is known for its terraced farmland on steep slopes?`,options:[`High Himal`,`Terai`,`Mid-hills`,`Chure`],answer:2,explanation:`The mid-hills are famous for terraced agriculture.`},{id:`GEO-EN-265`,batch:6,stem:`Devghat is the confluence where the Trishuli River joins which river?`,options:[`Kali Gandaki`,`Koshi`,`Karnali`,`Mahakali`],answer:0,explanation:`At Devghat, the Trishuli meets the Kali Gandaki, forming the Narayani.`},{id:`GEO-EN-266`,batch:6,stem:`Which river flows through a deep gorge beside Pokhara city?`,options:[`Seti River`,`Bagmati`,`Kankai`,`Rapti`],answer:0,explanation:`The Seti Gorge runs through the centre of Pokhara.`},{id:`GEO-EN-267`,batch:6,stem:`Which river forms Nepal's eastern boundary with India?`,options:[`Mahakali`,`Karnali`,`Mechi River`,`Narayani`],answer:2,explanation:`The Mechi River marks the eastern border with India.`},{id:`GEO-EN-268`,batch:6,stem:`Shey Phoksundo National Park is famous for protecting which rare animal?`,options:[`Giant panda`,`Snow leopard`,`Bengal tiger`,`Asiatic lion`],answer:1,explanation:`Shey Phoksundo is one of the places where snow leopards live in Nepal.`},{id:`GEO-EN-269`,batch:6,stem:`Chandragiri Hills, reached by cable car, lie near which city?`,options:[`Pokhara`,`Bhaktapur`,`Kathmandu`,`Birgunj`],answer:2,explanation:`Chandragiri Hills overlook the Kathmandu Valley.`},{id:`GEO-EN-270`,batch:6,stem:`Nagarkot, popular for Himalayan sunrise views, lies near which city?`,options:[`Pokhara`,`Bhaktapur`,`Janakpur`,`Butwal`],answer:1,explanation:`Nagarkot is a hill station east of Bhaktapur.`},{id:`GEO-EN-271`,batch:6,stem:`Lukla is the gateway airport for which trekking region?`,options:[`Everest region`,`Annapurna region`,`Langtang region`,`Dolpo region`],answer:0,explanation:`Lukla is the main airport for treks to Everest Base Camp.`},{id:`GEO-EN-272`,batch:6,stem:`Sarangkot near Pokhara is known for views of which peaks?`,options:[`Annapurna range`,`Everest range`,`Kanchenjunga range`,`Karakoram range`],answer:0,explanation:`Sarangkot is a popular viewpoint of the Annapurna range.`},{id:`GEO-EN-273`,batch:6,stem:`Which peak near Pokhara is considered sacred and is not permitted to be climbed?`,options:[`Dhaulagiri`,`Ganesh Himal`,`Machhapuchhre`,`Manaslu`],answer:2,explanation:`Machhapuchhre, the Fishtail peak, is considered sacred and climbing it is not permitted.`},{id:`GEO-EN-274`,batch:6,stem:`Which is the largest lake in Africa by area?`,options:[`Lake Victoria`,`Lake Tanganyika`,`Lake Malawi`,`Lake Chad`],answer:0,explanation:`Lake Victoria is the largest lake in Africa.`},{id:`GEO-EN-275`,batch:6,stem:`Mount Olympus, the highest mountain in Greece, is located near which sea?`,options:[`Aegean Sea`,`Adriatic Sea`,`Black Sea`,`Red Sea`],answer:0,explanation:`Mount Olympus rises near the Aegean coast of Greece.`},{id:`GEO-EN-276`,batch:6,stem:`Italy lies on which peninsula?`,options:[`Iberian Peninsula`,`Balkan Peninsula`,`Scandinavian Peninsula`,`Italian Peninsula`],answer:3,explanation:`Italy occupies the Italian Peninsula in southern Europe.`},{id:`GEO-EN-277`,batch:6,stem:`The Sierra Nevada mountain range is located mainly in which US state?`,options:[`Nevada`,`Oregon`,`Colorado`,`California`],answer:3,explanation:`The Sierra Nevada lies mainly in California.`},{id:`GEO-EN-278`,batch:6,stem:`The Ganges delta is shared by which two countries?`,options:[`India and Bangladesh`,`Nepal and India`,`Pakistan and India`,`Myanmar and Bangladesh`],answer:0,explanation:`The Ganges-Brahmaputra delta is shared by India and Bangladesh.`},{id:`GEO-EN-279`,batch:6,stem:`Victoria Falls, on the Zambezi River, lies on the border of Zambia and which country?`,options:[`Botswana`,`Mozambique`,`Malawi`,`Zimbabwe`],answer:3,explanation:`Victoria Falls lies on the border of Zambia and Zimbabwe.`},{id:`GEO-EN-280`,batch:6,stem:`Which is the longest river in Asia?`,options:[`Mekong`,`Yellow River`,`Yangtze`,`Ob`],answer:2,explanation:`The Yangtze is the longest river in Asia.`},{id:`GEO-EN-281`,batch:6,stem:`The city of Baghdad lies on which river?`,options:[`Euphrates`,`Jordan`,`Orontes`,`Tigris`],answer:3,explanation:`Baghdad is built along the Tigris River.`},{id:`GEO-EN-282`,batch:6,stem:`The city of London lies on which river?`,options:[`Severn`,`Mersey`,`Thames`,`Clyde`],answer:2,explanation:`London is built along the Thames.`},{id:`GEO-EN-283`,batch:6,stem:`Which mountain range runs along the boundary between Europe and Asia?`,options:[`Caucasus Mountains`,`Carpathian Mountains`,`Pyrenees`,`Ural Mountains`],answer:3,explanation:`The Ural Mountains are traditionally used as the boundary between Europe and Asia.`},{id:`GEO-EN-284`,batch:6,stem:`Which is the highest mountain in Antarctica?`,options:[`Mount Erebus`,`Mount Kenya`,`Mount Elbrus`,`Vinson Massif`],answer:3,explanation:`Vinson Massif is the highest peak in Antarctica.`},{id:`GEO-EN-285`,batch:6,stem:`Which country is the largest archipelago in the world?`,options:[`Philippines`,`Japan`,`Greece`,`Indonesia`],answer:3,explanation:`Indonesia is the world's largest island country and archipelago.`},{id:`GEO-EN-286`,batch:6,stem:`Which is the deepest lake in the world?`,options:[`Lake Tanganyika`,`Lake Superior`,`Lake Victoria`,`Lake Baikal`],answer:3,explanation:`Lake Baikal in Siberia is the deepest lake on Earth.`},{id:`GEO-EN-287`,batch:6,stem:`Which is the largest freshwater lake by surface area?`,options:[`Lake Superior`,`Lake Michigan`,`Lake Huron`,`Lake Erie`],answer:0,explanation:`Lake Superior is the largest freshwater lake by surface area.`},{id:`GEO-EN-288`,batch:6,stem:`Which continent contains the Antarctic cold desert?`,options:[`Antarctica`,`Africa`,`Australia`,`Asia`],answer:0,explanation:`Antarctica is the largest and coldest desert on Earth.`},{id:`GEO-EN-289`,batch:6,stem:`The Grand Canyon was carved mainly by which river?`,options:[`Mississippi River`,`Rio Grande`,`Colorado River`,`Missouri River`],answer:2,explanation:`The Colorado River carved the Grand Canyon over millions of years.`},{id:`GEO-EN-290`,batch:6,stem:`The Great Rift Valley runs through which continent?`,options:[`Asia`,`South America`,`Africa`,`Australia`],answer:2,explanation:`The Great Rift Valley runs through eastern Africa.`},{id:`GEO-EN-291`,batch:6,stem:`The supercontinent that existed about 300 million years ago is called what?`,options:[`Gondwana only`,`Laurasia only`,`Pangaea`,`Rodinia`],answer:2,explanation:`Pangaea was the supercontinent that later broke apart into continents.`},{id:`GEO-EN-292`,batch:6,stem:`Which active volcano near Naples, Italy, destroyed Pompeii in AD 79?`,options:[`Mount Etna`,`Mount Vesuvius`,`Stromboli`,`Mount Fuji`],answer:1,explanation:`Vesuvius erupted in AD 79 and buried Pompeii.`},{id:`GEO-EN-293`,batch:6,stem:`Mount St. Helens, which erupted in 1980, is located in which US state?`,options:[`Oregon`,`Washington`,`Idaho`,`Alaska`],answer:1,explanation:`Mount St. Helens is in Washington State.`},{id:`GEO-EN-294`,batch:6,stem:`The Atlas Mountains are located mainly in which region of Africa?`,options:[`East Africa`,`Southern Africa`,`Central Africa`,`North-west Africa`],answer:3,explanation:`The Atlas Mountains stretch across Morocco, Algeria and Tunisia.`},{id:`GEO-EN-295`,batch:6,stem:`Which lakes form part of the border between the United States and Canada?`,options:[`Great Salt Lakes`,`Great Lakes`,`Finger Lakes`,`Lake Titicaca`],answer:1,explanation:`The Great Lakes lie along parts of the US-Canada border.`},{id:`GEO-EN-296`,batch:6,stem:`Hudson Bay is located in which country?`,options:[`United States`,`Russia`,`Greenland`,`Canada`],answer:3,explanation:`Hudson Bay is a large inlet in northeastern Canada.`},{id:`GEO-EN-297`,batch:6,stem:`Which is the highest mountain in North America?`,options:[`Mount Logan`,`Mount Whitney`,`Denali`,`Mount Rainier`],answer:2,explanation:`Denali in Alaska is the highest peak in North America.`},{id:`GEO-EN-298`,batch:6,stem:`Which is the highest mountain in Australia's mainland?`,options:[`Mount Townsend`,`Mount Kosciuszko`,`Mount Bartle Frere`,`Ben Lomond`],answer:1,explanation:`Mount Kosciuszko is the highest point on the Australian mainland.`},{id:`GEO-EN-299`,batch:6,stem:`Mount Kenya, the second-highest peak in Africa, is located in which country?`,options:[`Kenya`,`Tanzania`,`Uganda`,`Ethiopia`],answer:0,explanation:`Mount Kenya lies in central Kenya.`},{id:`GEO-EN-300`,batch:6,stem:`Mount Kailash, a sacred peak in Tibet, is revered by which religions?`,options:[`Christianity and Judaism`,`Hinduism, Buddhism, Jainism and Bon`,`Islam and Sikhism`,`Zoroastrianism only`],answer:1,explanation:`Mount Kailash is sacred to Hindus, Buddhists, Jains and followers of Bon.`},{id:`GEO-EN-301`,batch:7,stem:`Dang district lies in which province?`,options:[`Lumbini`,`Gandaki`,`Karnali`,`Madhesh`],answer:0,explanation:`Dang district is part of Lumbini Province.`},{id:`GEO-EN-302`,batch:7,stem:`Rolpa district lies in which province?`,options:[`Karnali`,`Gandaki`,`Bagmati`,`Lumbini`],answer:3,explanation:`Rolpa district is part of Lumbini Province.`},{id:`GEO-EN-303`,batch:7,stem:`Palpa district lies in which province?`,options:[`Gandaki`,`Koshi`,`Lumbini`,`Sudurpashchim`],answer:2,explanation:`Palpa district is part of Lumbini Province.`},{id:`GEO-EN-304`,batch:7,stem:`Bardiya district lies in which province?`,options:[`Karnali`,`Sudurpashchim`,`Madhesh`,`Lumbini`],answer:3,explanation:`Bardiya district is part of Lumbini Province.`},{id:`GEO-EN-305`,batch:7,stem:`Lamjung district lies in which province?`,options:[`Bagmati`,`Lumbini`,`Gandaki`,`Koshi`],answer:2,explanation:`Lamjung district is part of Gandaki Province.`},{id:`GEO-EN-306`,batch:7,stem:`Tanahun district lies in which province?`,options:[`Lumbini`,`Bagmati`,`Madhesh`,`Gandaki`],answer:3,explanation:`Tanahun district is part of Gandaki Province.`},{id:`GEO-EN-307`,batch:7,stem:`Nuwakot district lies in which province?`,options:[`Gandaki`,`Koshi`,`Madhesh`,`Bagmati`],answer:3,explanation:`Nuwakot district is part of Bagmati Province.`},{id:`GEO-EN-308`,batch:7,stem:`Dhading district lies in which province?`,options:[`Gandaki`,`Madhesh`,`Bagmati`,`Lumbini`],answer:2,explanation:`Dhading district is part of Bagmati Province.`},{id:`GEO-EN-309`,batch:7,stem:`Dolakha district lies in which province?`,options:[`Koshi`,`Karnali`,`Gandaki`,`Bagmati`],answer:3,explanation:`Dolakha district is part of Bagmati Province.`},{id:`GEO-EN-310`,batch:7,stem:`Ramechhap district lies in which province?`,options:[`Koshi`,`Bagmati`,`Madhesh`,`Sudurpashchim`],answer:1,explanation:`Ramechhap district is part of Bagmati Province.`},{id:`GEO-EN-311`,batch:7,stem:`Rautahat district lies in which province?`,options:[`Bagmati`,`Koshi`,`Madhesh`,`Lumbini`],answer:2,explanation:`Rautahat district is part of Madhesh Province.`},{id:`GEO-EN-312`,batch:7,stem:`Sarlahi district lies in which province?`,options:[`Bagmati`,`Gandaki`,`Karnali`,`Madhesh`],answer:3,explanation:`Sarlahi district is part of Madhesh Province.`},{id:`GEO-EN-313`,batch:7,stem:`Saptari district lies in which province?`,options:[`Koshi`,`Bagmati`,`Madhesh`,`Lumbini`],answer:2,explanation:`Saptari district is part of Madhesh Province.`},{id:`GEO-EN-314`,batch:7,stem:`Siraha district lies in which province?`,options:[`Madhesh`,`Koshi`,`Lumbini`,`Karnali`],answer:0,explanation:`Siraha district is part of Madhesh Province.`},{id:`GEO-EN-315`,batch:7,stem:`Mahottari district lies in which province?`,options:[`Madhesh`,`Koshi`,`Bagmati`,`Gandaki`],answer:0,explanation:`Mahottari district is part of Madhesh Province.`},{id:`GEO-EN-316`,batch:7,stem:`Dadeldhura district lies in which province?`,options:[`Karnali`,`Sudurpashchim`,`Lumbini`,`Gandaki`],answer:1,explanation:`Dadeldhura district is part of Sudurpashchim Province.`},{id:`GEO-EN-317`,batch:7,stem:`Achham district lies in which province?`,options:[`Karnali`,`Lumbini`,`Sudurpashchim`,`Bagmati`],answer:2,explanation:`Achham district is part of Sudurpashchim Province.`},{id:`GEO-EN-318`,batch:7,stem:`Bajura district lies in which province?`,options:[`Karnali`,`Gandaki`,`Koshi`,`Sudurpashchim`],answer:3,explanation:`Bajura district is part of Sudurpashchim Province.`},{id:`GEO-EN-319`,batch:7,stem:`Salyan district lies in which province?`,options:[`Lumbini`,`Sudurpashchim`,`Karnali`,`Gandaki`],answer:2,explanation:`Salyan district is part of Karnali Province.`},{id:`GEO-EN-320`,batch:7,stem:`Jajarkot district lies in which province?`,options:[`Karnali`,`Gandaki`,`Lumbini`,`Sudurpashchim`],answer:0,explanation:`Jajarkot district is part of Karnali Province.`},{id:`GEO-EN-321`,batch:7,stem:`Okhaldhunga district lies in which province?`,options:[`Bagmati`,`Madhesh`,`Koshi`,`Gandaki`],answer:2,explanation:`Okhaldhunga district is part of Koshi Province.`},{id:`GEO-EN-322`,batch:7,stem:`Bhojpur district lies in which province?`,options:[`Bagmati`,`Koshi`,`Madhesh`,`Lumbini`],answer:1,explanation:`Bhojpur district is part of Koshi Province.`},{id:`GEO-EN-323`,batch:7,stem:`Sankhuwasabha district lies in which province?`,options:[`Koshi`,`Karnali`,`Gandaki`,`Sudurpashchim`],answer:0,explanation:`Sankhuwasabha district is part of Koshi Province.`},{id:`GEO-EN-324`,batch:7,stem:`Panchthar district lies in which province?`,options:[`Koshi`,`Madhesh`,`Lumbini`,`Bagmati`],answer:0,explanation:`Panchthar district is part of Koshi Province.`},{id:`GEO-EN-325`,batch:7,stem:`Sunsari district lies in which province?`,options:[`Madhesh`,`Bagmati`,`Karnali`,`Koshi`],answer:3,explanation:`Sunsari district is part of Koshi Province.`},{id:`GEO-EN-326`,batch:7,stem:`Which continent has the largest number of independent countries?`,options:[`Asia`,`Europe`,`Africa`,`South America`],answer:2,explanation:`Africa has 54 recognised countries, the most of any continent.`},{id:`GEO-EN-327`,batch:7,stem:`Which is the largest country in Central America by area?`,options:[`Nicaragua`,`Honduras`,`Guatemala`,`Panama`],answer:0,explanation:`Nicaragua is the largest country in Central America by area.`},{id:`GEO-EN-328`,batch:7,stem:`The Strait of Malacca separates the Malay Peninsula from which island?`,options:[`Borneo`,`Sumatra`,`Java`,`Sulawesi`],answer:1,explanation:`The Strait of Malacca separates the Malay Peninsula from Sumatra.`},{id:`GEO-EN-329`,batch:7,stem:`The Strait of Hormuz lies between Iran and which country?`,options:[`Iraq`,`Oman`,`Saudi Arabia`,`Kuwait`],answer:1,explanation:`The Strait of Hormuz separates Iran from Oman.`},{id:`GEO-EN-330`,batch:7,stem:`The Bosphorus strait runs through which major city?`,options:[`Ankara`,`Izmir`,`Istanbul`,`Antalya`],answer:2,explanation:`The Bosphorus flows through Istanbul, Turkey.`},{id:`GEO-EN-331`,batch:7,stem:`The Eiffel Tower is located in which country?`,options:[`Belgium`,`France`,`Switzerland`,`Italy`],answer:1,explanation:`The Eiffel Tower is in Paris, France.`},{id:`GEO-EN-332`,batch:7,stem:`The Colosseum is located in which city?`,options:[`Milan`,`Rome`,`Naples`,`Florence`],answer:1,explanation:`The Colosseum is in Rome, Italy.`},{id:`GEO-EN-333`,batch:7,stem:`The Acropolis of Athens is located in which country?`,options:[`Greece`,`Turkey`,`Cyprus`,`Bulgaria`],answer:0,explanation:`The Acropolis stands above Athens, Greece.`},{id:`GEO-EN-334`,batch:7,stem:`The ancient city of Petra is located in which country?`,options:[`Jordan`,`Egypt`,`Syria`,`Israel`],answer:0,explanation:`Petra, carved into rock, is in southern Jordan.`},{id:`GEO-EN-335`,batch:7,stem:`Angkor Wat, the temple complex, is located in which country?`,options:[`Cambodia`,`Thailand`,`Vietnam`,`Myanmar`],answer:0,explanation:`Angkor Wat is in Cambodia.`},{id:`GEO-EN-336`,batch:7,stem:`Christ the Redeemer statue overlooks which city?`,options:[`São Paulo`,`Brasília`,`Rio de Janeiro`,`Salvador`],answer:2,explanation:`The statue stands above Rio de Janeiro, Brazil.`},{id:`GEO-EN-337`,batch:7,stem:`The Statue of Liberty is located in which country?`,options:[`Canada`,`United States`,`United Kingdom`,`France`],answer:1,explanation:`The Statue of Liberty stands in New York Harbor, USA.`},{id:`GEO-EN-338`,batch:7,stem:`The Sydney Opera House is located in which country?`,options:[`New Zealand`,`Australia`,`Canada`,`South Africa`],answer:1,explanation:`The Sydney Opera House is in Australia.`},{id:`GEO-EN-339`,batch:7,stem:`The Great Pyramids of Giza are located in which country?`,options:[`Sudan`,`Egypt`,`Libya`,`Jordan`],answer:1,explanation:`The Giza pyramids lie near Cairo, Egypt.`},{id:`GEO-EN-340`,batch:7,stem:`Stonehenge, the prehistoric stone circle, is located in which country?`,options:[`United Kingdom`,`Ireland`,`Netherlands`,`Germany`],answer:0,explanation:`Stonehenge is in Wiltshire, England, UK.`},{id:`GEO-EN-341`,batch:7,stem:`The Forbidden City is located in which Chinese city?`,options:[`Shanghai`,`Beijing`,`Xi'an`,`Nanjing`],answer:1,explanation:`The Forbidden City is in the centre of Beijing.`},{id:`GEO-EN-342`,batch:7,stem:`Borobudur, a famous Buddhist temple, is located in which country?`,options:[`Thailand`,`Malaysia`,`Indonesia`,`Sri Lanka`],answer:2,explanation:`Borobudur is in Central Java, Indonesia.`},{id:`GEO-EN-343`,batch:7,stem:`The Alhambra palace is located in which country?`,options:[`Portugal`,`Morocco`,`Italy`,`Spain`],answer:3,explanation:`The Alhambra is in Granada, Spain.`},{id:`GEO-EN-344`,batch:7,stem:`Which ocean lies to the west of Australia?`,options:[`Pacific Ocean`,`Indian Ocean`,`Southern Ocean`,`Arctic Ocean`],answer:1,explanation:`The Indian Ocean lies west of Australia.`},{id:`GEO-EN-345`,batch:7,stem:`The Rhine River flows into which sea?`,options:[`North Sea`,`Baltic Sea`,`Black Sea`,`Adriatic Sea`],answer:0,explanation:`The Rhine empties into the North Sea through the Netherlands.`},{id:`GEO-EN-346`,batch:7,stem:`The Danube River flows into which sea?`,options:[`Caspian Sea`,`Baltic Sea`,`Adriatic Sea`,`Black Sea`],answer:3,explanation:`The Danube flows into the Black Sea.`},{id:`GEO-EN-347`,batch:7,stem:`The Mississippi River flows into which body of water?`,options:[`Atlantic Ocean`,`Hudson Bay`,`Gulf of Mexico`,`Caribbean Sea`],answer:2,explanation:`The Mississippi empties into the Gulf of Mexico.`},{id:`GEO-EN-348`,batch:7,stem:`The Amazon River flows into which ocean?`,options:[`Atlantic Ocean`,`Pacific Ocean`,`Indian Ocean`,`Arctic Ocean`],answer:0,explanation:`The Amazon drains into the Atlantic Ocean.`},{id:`GEO-EN-349`,batch:7,stem:`The Mekong River flows into which sea through its delta?`,options:[`Java Sea`,`South China Sea`,`Andaman Sea`,`Sea of Japan`],answer:1,explanation:`The Mekong delta opens into the South China Sea.`},{id:`GEO-EN-350`,batch:7,stem:`Which is the most populous country in Africa?`,options:[`Egypt`,`Ethiopia`,`South Africa`,`Nigeria`],answer:3,explanation:`Nigeria has the largest population of any African country.`},{id:`GEO-EN-351`,batch:8,stem:`What are lines of longitude commonly called?`,options:[`Parallels`,`Isobars`,`Meridians`,`Contours`],answer:2,explanation:`Lines of longitude are called meridians; they run north to south.`},{id:`GEO-EN-352`,batch:8,stem:`Lines of latitude run in which direction?`,options:[`East to west`,`North to south`,`Diagonally`,`Only at the poles`],answer:0,explanation:`Latitude lines run parallel to the equator, east to west.`},{id:`GEO-EN-353`,batch:8,stem:`How long does it take the Earth to complete one rotation on its axis?`,options:[`12 hours`,`365 days`,`30 days`,`24 hours`],answer:3,explanation:`One rotation of the Earth takes about 24 hours, which defines a day.`},{id:`GEO-EN-354`,batch:8,stem:`What is the approximate tilt of Earth's axis?`,options:[`45 degrees`,`23.5 degrees`,`0 degrees`,`90 degrees`],answer:1,explanation:`The Earth's axis is tilted about 23.5 degrees, which causes the seasons.`},{id:`GEO-EN-355`,batch:8,stem:`How many degrees of longitude correspond to a one-hour difference in time?`,options:[`10 degrees`,`30 degrees`,`60 degrees`,`15 degrees`],answer:3,explanation:`The Earth turns 15 degrees of longitude per hour, so each 15 degrees equals one hour.`},{id:`GEO-EN-356`,batch:8,stem:`On which date does the March equinox usually fall?`,options:[`21 June`,`21 September`,`21 December`,`21 March`],answer:3,explanation:`The March equinox usually falls on 20 or 21 March.`},{id:`GEO-EN-357`,batch:8,stem:`On which date does the June solstice usually fall in the Northern Hemisphere?`,options:[`21 March`,`21 September`,`21 December`,`21 June`],answer:3,explanation:`The June solstice, around 21 June, gives the longest day in the Northern Hemisphere.`},{id:`GEO-EN-358`,batch:8,stem:`On which date does the December solstice usually fall in the Northern Hemisphere?`,options:[`21 June`,`21 March`,`21 December`,`21 September`],answer:2,explanation:`The December solstice gives the shortest day in the Northern Hemisphere.`},{id:`GEO-EN-359`,batch:8,stem:`Which map projection was devised by Gerardus Mercator?`,options:[`Robinson projection`,`Peters projection`,`Albers projection`,`Mercator projection`],answer:3,explanation:`The Mercator projection is a cylindrical map projection named after Gerardus Mercator.`},{id:`GEO-EN-360`,batch:8,stem:`Which direction does a compass needle point to?`,options:[`True south`,`Magnetic north`,`Geographic east`,`Celestial west`],answer:1,explanation:`A compass needle aligns with the Earth's magnetic field, pointing to magnetic north.`},{id:`GEO-EN-361`,batch:8,stem:`Contour lines on a topographic map join points of what?`,options:[`Equal rainfall`,`Equal elevation`,`Equal temperature`,`Equal population`],answer:1,explanation:`Contour lines connect points at the same height above sea level.`},{id:`GEO-EN-362`,batch:8,stem:`A map scale expressed as 1:50,000 is what kind of scale?`,options:[`Ratio scale`,`Verbal scale`,`Graphic scale only`,`Linear scale only`],answer:0,explanation:`A ratio scale shows the relationship between map distance and real distance.`},{id:`GEO-EN-363`,batch:8,stem:`Which part of the Earth's crust is generally thinnest?`,options:[`Continental crust`,`Mantle`,`Oceanic crust`,`Core`],answer:2,explanation:`Oceanic crust is thinner than continental crust.`},{id:`GEO-EN-364`,batch:8,stem:`Which layer of the Earth lies directly below the crust?`,options:[`Core`,`Inner core`,`Mantle`,`Atmosphere`],answer:2,explanation:`The mantle lies between the crust and the core.`},{id:`GEO-EN-365`,batch:8,stem:`The Richter scale is used to measure what?`,options:[`Earthquake magnitude`,`Wind speed`,`Rainfall`,`Air pressure`],answer:0,explanation:`The Richter scale measures the magnitude of earthquakes.`},{id:`GEO-EN-366`,batch:8,stem:`Molten rock that reaches the Earth's surface is called what?`,options:[`Magma`,`Lava`,`Tephra`,`Pumice`],answer:1,explanation:`Magma becomes lava once it erupts onto the surface.`},{id:`GEO-EN-367`,batch:8,stem:`Limestone is which type of rock?`,options:[`Sedimentary`,`Igneous`,`Metamorphic`,`Volcanic glass`],answer:0,explanation:`Limestone forms from the accumulation of sediments, mostly calcium carbonate.`},{id:`GEO-EN-368`,batch:8,stem:`Marble is formed from limestone by which process?`,options:[`Erosion`,`Deposition`,`Metamorphism`,`Crystallisation from magma`],answer:2,explanation:`Heat and pressure transform limestone into marble, a metamorphic rock.`},{id:`GEO-EN-369`,batch:8,stem:`Granite is which type of rock?`,options:[`Sedimentary`,`Igneous`,`Metamorphic`,`Clastic`],answer:1,explanation:`Granite forms from cooled magma beneath the surface.`},{id:`GEO-EN-370`,batch:8,stem:`Which latitude receives the most direct sunlight over the year?`,options:[`Tropic of Capricorn`,`Arctic Circle`,`Equator`,`Antarctic Circle`],answer:2,explanation:`The equator receives the most direct sunlight throughout the year.`},{id:`GEO-EN-371`,batch:8,stem:`Which climate type has hot, dry summers and mild, wet winters?`,options:[`Mediterranean climate`,`Tropical rainforest climate`,`Polar climate`,`Desert climate`],answer:0,explanation:`The Mediterranean climate has dry summers and wet winters.`},{id:`GEO-EN-372`,batch:8,stem:`Which warm ocean current flows along the eastern coast of North America and warms Western Europe?`,options:[`Humboldt Current`,`Benguela Current`,`Gulf Stream`,`Kuroshio Current`],answer:2,explanation:`The Gulf Stream carries warm water that moderates the climate of Western Europe.`},{id:`GEO-EN-373`,batch:8,stem:`El Niño is a climate pattern associated with unusual warming of which ocean?`,options:[`Atlantic Ocean`,`Indian Ocean`,`Pacific Ocean`,`Arctic Ocean`],answer:2,explanation:`El Niño involves warming of the central and eastern tropical Pacific Ocean.`},{id:`GEO-EN-374`,batch:8,stem:`A rain shadow forms on the side of a mountain that is what?`,options:[`Facing the prevailing winds`,`Covered by glaciers`,`Sheltered from prevailing winds`,`Nearest to the sea`],answer:2,explanation:`The leeward side of a mountain receives little rain because moist air has dropped its moisture on the windward side.`},{id:`GEO-EN-375`,batch:8,stem:`In the water cycle, what process turns liquid water into vapour?`,options:[`Condensation`,`Evaporation`,`Precipitation`,`Infiltration`],answer:1,explanation:`Evaporation changes liquid water into water vapour.`},{id:`GEO-EN-376`,batch:8,stem:`Which district is the westernmost district of Nepal?`,options:[`Darchula`,`Kanchanpur`,`Dadeldhura`,`Baitadi`],answer:0,explanation:`Darchula, in Sudurpashchim Province, is the westernmost district of Nepal.`},{id:`GEO-EN-377`,batch:8,stem:`Shuklaphanta National Park is located in which district?`,options:[`Kanchanpur`,`Bardiya`,`Banke`,`Kailali`],answer:3,explanation:`Shuklaphanta National Park is in Kailali district.`},{id:`GEO-EN-378`,batch:8,stem:`Mahendranagar, a major city, lies in which province?`,options:[`Karnali`,`Lumbini`,`Madhesh`,`Sudurpashchim`],answer:3,explanation:`Mahendranagar is in Kanchanpur district of Sudurpashchim Province.`},{id:`GEO-EN-379`,batch:8,stem:`Musk deer, a rare Himalayan animal, is mainly found in which zone of Nepal?`,options:[`High Himalaya`,`Terai`,`Siwalik`,`Kathmandu Valley`],answer:0,explanation:`Musk deer live in the high, forested mountains of the Himalaya.`},{id:`GEO-EN-380`,batch:8,stem:`What is Nepal's national animal?`,options:[`Tiger`,`Rhinoceros`,`Yak`,`Cow`],answer:3,explanation:`The cow is the national animal of Nepal.`},{id:`GEO-EN-381`,batch:8,stem:`The Gobi Desert lies mainly in which country?`,options:[`Kazakhstan`,`Afghanistan`,`Pakistan`,`Mongolia`],answer:3,explanation:`The Gobi Desert lies mainly in Mongolia, with part in northern China.`},{id:`GEO-EN-382`,batch:8,stem:`The Thar Desert lies mainly in which country?`,options:[`Pakistan`,`Iran`,`India`,`Afghanistan`],answer:2,explanation:`The Thar Desert is mostly in north-western India.`},{id:`GEO-EN-383`,batch:8,stem:`The Kalahari Desert lies mainly in which country?`,options:[`Botswana`,`Namibia`,`South Africa`,`Zimbabwe`],answer:0,explanation:`The Kalahari covers much of Botswana.`},{id:`GEO-EN-384`,batch:8,stem:`The Namib Desert lies along the coast of which country?`,options:[`Angola`,`Namibia`,`South Africa`,`Botswana`],answer:1,explanation:`The Namib Desert runs along the Atlantic coast of Namibia.`},{id:`GEO-EN-385`,batch:8,stem:`The Great Victoria Desert lies in which country?`,options:[`South Africa`,`Argentina`,`India`,`Australia`],answer:3,explanation:`The Great Victoria Desert is in central-southern Australia.`},{id:`GEO-EN-386`,batch:8,stem:`Lake Titicaca lies on the border between Peru and which country?`,options:[`Chile`,`Bolivia`,`Ecuador`,`Argentina`],answer:1,explanation:`Lake Titicaca is shared by Peru and Bolivia.`},{id:`GEO-EN-387`,batch:8,stem:`The Iguazu Falls lie on the border between Brazil and which country?`,options:[`Paraguay`,`Argentina`,`Uruguay`,`Chile`],answer:1,explanation:`Iguazu Falls straddle the border of Brazil and Argentina.`},{id:`GEO-EN-388`,batch:8,stem:`Niagara Falls lies on the border between the United States and which country?`,options:[`Mexico`,`Canada`,`Russia`,`Greenland`],answer:1,explanation:`Niagara Falls lies between New York State and Ontario, Canada.`},{id:`GEO-EN-389`,batch:8,stem:`Which country borders the Caspian Sea to the south?`,options:[`Russia`,`Kazakhstan`,`Iran`,`Azerbaijan`],answer:2,explanation:`Iran borders the Caspian Sea on its southern shore.`},{id:`GEO-EN-390`,batch:8,stem:`The Sea of Japan lies between Japan and which two other countries?`,options:[`China and Taiwan`,`Vietnam and the Philippines`,`South Korea and Russia`,`Mongolia and Indonesia`],answer:2,explanation:`The Sea of Japan is bordered by Japan, Korea and Russia.`},{id:`GEO-EN-391`,batch:8,stem:`The Arabian Sea lies to the west of which country's coastline?`,options:[`Iran`,`Sri Lanka`,`Bangladesh`,`India`],answer:3,explanation:`The Arabian Sea lies west of the Indian coast and south of Pakistan and Iran.`},{id:`GEO-EN-392`,batch:8,stem:`What is the capital of Greenland?`,options:[`Reykjavik`,`Tórshavn`,`Nuuk`,`Longyearbyen`],answer:2,explanation:`Nuuk is the capital of Greenland.`},{id:`GEO-EN-393`,batch:8,stem:`What is the capital of Iceland?`,options:[`Nuuk`,`Reykjavik`,`Oslo`,`Helsinki`],answer:1,explanation:`Reykjavik is the capital of Iceland.`},{id:`GEO-EN-394`,batch:8,stem:`Which country lies on the equator and has the capital Quito?`,options:[`Colombia`,`Ecuador`,`Peru`,`Brazil`],answer:1,explanation:`Ecuador's capital, Quito, sits near the equator.`},{id:`GEO-EN-395`,batch:8,stem:`What is the capital of Rwanda?`,options:[`Kampala`,`Nairobi`,`Dodoma`,`Kigali`],answer:3,explanation:`Kigali is the capital of Rwanda.`},{id:`GEO-EN-396`,batch:8,stem:`What is the capital of Norway?`,options:[`Oslo`,`Bergen`,`Stockholm`,`Copenhagen`],answer:0,explanation:`Oslo is the capital of Norway.`},{id:`GEO-EN-397`,batch:8,stem:`What is the capital of Sweden?`,options:[`Gothenburg`,`Stockholm`,`Oslo`,`Helsinki`],answer:1,explanation:`Stockholm is the capital of Sweden.`},{id:`GEO-EN-398`,batch:8,stem:`What is the capital of Ethiopia?`,options:[`Addis Ababa`,`Nairobi`,`Asmara`,`Mogadishu`],answer:0,explanation:`Addis Ababa is the capital of Ethiopia.`},{id:`GEO-EN-399`,batch:8,stem:`What is the capital of Ghana?`,options:[`Accra`,`Kumasi`,`Lagos`,`Abidjan`],answer:0,explanation:`Accra is the capital of Ghana.`},{id:`GEO-EN-400`,batch:8,stem:`What is the capital of New Zealand?`,options:[`Auckland`,`Christchurch`,`Dunedin`,`Wellington`],answer:3,explanation:`Wellington is the capital of New Zealand.`}]},a=[{slug:`README`,title:`About this book`,nep:``,kind:`about`,ch:0,file:`README.md`},{slug:`part-01-master-index`,title:`Master Index`,nep:``,kind:`front`,ch:0,file:`part-01-master-index.md`},{slug:`part-02-syllabus-comparison`,title:`Seven-Province Syllabus Comparison and Priority Classification`,nep:``,kind:`front`,ch:0,file:`part-02-syllabus-comparison.md`},{slug:`part-03-study-strategy`,title:`Study Strategy`,nep:``,kind:`front`,ch:0,file:`part-03-study-strategy.md`},{slug:`part-04-chapter-roadmap`,title:`Chapter Roadmap`,nep:``,kind:`front`,ch:0,file:`part-04-chapter-roadmap.md`},{slug:`part-05-chapter-01-geography-of-nepal`,title:`Geography of Nepal`,nep:`नेपालको भूगोल`,kind:`chapter`,ch:1,file:`part-05-chapter-01-geography-of-nepal.md`},{slug:`part-06-chapter-02-history-of-nepal`,title:`History of Nepal`,nep:`नेपालको इतिहास`,kind:`chapter`,ch:2,file:`part-06-chapter-02-history-of-nepal.md`},{slug:`part-07-chapter-03-constitution-of-nepal`,title:`Constitution of Nepal`,nep:`नेपालको संविधान`,kind:`chapter`,ch:3,file:`part-07-chapter-03-constitution-of-nepal.md`},{slug:`part-08-chapter-04-federalism-and-governance`,title:`Federalism and Governance`,nep:`संघीयता र शासन प्रणाली`,kind:`chapter`,ch:4,file:`part-08-chapter-04-federalism-and-governance.md`},{slug:`part-09-chapter-05-economy-and-public-finance`,title:`Economy and Public Finance`,nep:`अर्थतन्त्र र सार्वजनिक वित्त`,kind:`chapter`,ch:5,file:`part-09-chapter-05-economy-and-public-finance.md`},{slug:`part-10-chapter-06-society-culture-heritage`,title:`Society, Culture and Heritage`,nep:`समाज, संस्कृति र सम्पदा`,kind:`chapter`,ch:6,file:`part-10-chapter-06-society-culture-heritage.md`},{slug:`part-11-chapter-07-science-technology-environment`,title:`Science, Technology and Environment`,nep:`विज्ञान, प्रविधि र वातावरण`,kind:`chapter`,ch:7,file:`part-11-chapter-07-science-technology-environment.md`},{slug:`part-12-chapter-08-international-relations`,title:`International Relations and Organisations`,nep:`अन्तर्राष्ट्रिय सम्बन्ध र सङ्गठन`,kind:`chapter`,ch:8,file:`part-12-chapter-08-international-relations.md`},{slug:`part-13-chapter-09-current-affairs`,title:`Current Affairs`,nep:`समसामयिक गतिविधि`,kind:`chapter`,ch:9,file:`part-13-chapter-09-current-affairs.md`},{slug:`part-14-chapter-10-koshi-province`,title:`Koshi Province`,nep:`कोशी प्रदेश`,kind:`chapter`,ch:10,file:`part-14-chapter-10-koshi-province.md`},{slug:`part-15-chapter-11-madhesh-province`,title:`Madhesh Province`,nep:`मधेश प्रदेश`,kind:`chapter`,ch:11,file:`part-15-chapter-11-madhesh-province.md`}],o=r.chapters,s=r.built,c=r.version;function l(e,t,n,r,i){return{key:`${e}:${r.id}`,id:r.id,stem:r.stem,html:i,options:r.options,answer:r.answer,explanation:r.explanation,label:r.label??``,topic:n,chapter:t,batch:r.batch??null,source:e}}var u=o.map(e=>{let t=e.topics.map(t=>{let n=t.id===`T`?t.title:`${t.id}  ${t.title}`;return{id:t.id,title:n,questions:t.questions.map(t=>l(e.title,e.num,n,t,!0))}});return{num:e.num,title:e.title,nep:e.nep,slug:e.slug,topics:t,questions:t.flatMap(e=>e.questions)}}),d=i.questions.map(e=>l(`Geography Master`,null,`Batch ${e.batch??``}`,{...e},!1)),f=a,p=u.reduce((e,t)=>e+t.questions.length,0),m=p+d.length;function h(e){return u.find(t=>t.num===e)}function g(e){return f.find(t=>t.slug===e)}function _(){let e=new Map;for(let t of d)t.batch!=null&&e.set(t.batch,(e.get(t.batch)??0)+1);return[...e.entries()].sort((e,t)=>e[0]-t[0]).map(([e,t])=>({batch:e,count:t}))}function v(e){return e.replace(/<[^>]+>/g,` `).replace(/&nbsp;/g,` `).replace(/&/g,`&`).replace(/</g,`<`).replace(/>/g,`>`).replace(/&#39;/g,`'`).replace(/"/g,`"`).replace(/\s+/g,` `).trim()}function y(e){let t=e.slice();for(let e=t.length-1;e>0;e--){let n=Math.floor(Math.random()*(e+1)),r=t[e];t[e]=t[n],t[n]=r}return t}function b(e,t){let n=[],r=`Practice`;if(e.bank===`geo`){if(r=`Geography Master`,n=d,e.batch){let t=Number(e.batch);n=n.filter(e=>e.batch===t),r=`Geography · batch ${t}`}}else if(e.bank===`mix`){r=`Mixed test`;let t=new Set(e.chs.split(`,`).filter(Boolean));t.has(`geo`)&&(n=n.concat(d));for(let e of u)t.has(String(e.num))&&(n=n.concat(e.questions));if(!t.size)return{error:`Choose at least one chapter.`}}else{let t=h(Number(e.bank));if(!t)return{error:`That set is not in the book.`};if(r=t.title,n=t.questions,e.topic){let i=t.topics.find(t=>t.id===e.topic);if(!i)return{error:`That topic is not in this chapter.`};n=i.questions,r=i.title}}if(e.only===`wrong`){if(n=n.filter(e=>{let n=t[e.key];return!!n&&n.tries>0&&!n.lastCorrect}),r+=` · missed`,!n.length)return{error:`No missed questions in this set yet.`}}else if(e.only===`saved`&&(n=n.filter(e=>t[e.key]?.saved),r+=` · saved`,!n.length))return{error:`No saved questions yet. Bookmark one while you practice.`};return n.length?{title:r,questions:n}:{error:`This set has no questions.`}}function x(e){let t=e.trim().toLowerCase();if(t.length<2)return[];let n=u.flatMap(e=>e.questions).concat(d),r=[];for(let e of n)if(`${v(e.stem)} ${e.options.join(` `)} ${e.source}`.toLowerCase().includes(t)&&r.push(e),r.length===15)break;return r}export{u as a,d as c,f as d,x as f,t as g,n as h,h as i,v as l,m,p as n,b as o,y as p,c as r,_ as s,s as t,g as u};