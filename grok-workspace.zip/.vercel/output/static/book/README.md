# Provincial Public Service Commission — 5th Level (Non-Technical) — Paper I Study Book

**प्रदेश लोक सेवा आयोग · सहायकस्तर पाँचौं तह (अप्राविधिक) · प्रथम पत्र**

A study book for the objective paper — General Knowledge and General Mental Ability Test — written for candidates of all seven provinces: Koshi, Madhesh, Bagmati, Gandaki, Lumbini, Karnali and Sudurpashchim.

| | |
|---|---|
| **Last updated** | 12 November 2026 (26 Kartik 2083 BS). Research began on 10 November 2026. |
| **Written so far** | Parts 1–15: front matter and Chapters 1 to 11 |
| **Next to be written** | Part 16 — Chapter 12: Bagmati Province |
| **Web app** | The same book in a web browser, with practice questions and timed tests; it works without the internet after the first visit: <https://gobindsah9841-max.github.io/loksewa/> (see the folder `web-app`; the site itself is built into the folder `docs`) |
| **Android app** | The same book as an offline app: see the folder `android-app` of this repository |
| **Language** | Simple English, with key terms in Nepali |

---

## 1. Start here

1. Read **Part 2** and find your province. The seven provinces do **not** share one pattern.
2. Read **Part 3** for the marks arithmetic, the study plan and the examination-hall method.
3. Study the chapters in the order of your province's priorities (Part 2, section 2.11).
4. Download the syllabus from your own commission's website and compare it with Part 2. This book is a study aid; the commission's document is the authority.

**Three facts to know before anything else**

- Every province: 50 questions × 2 marks, 45 minutes, **0.4 mark deducted for each wrong answer**.
- General Knowledge : Mental Ability is **30 : 20** in Madhesh, Gandaki, Lumbini, Karnali and Sudurpashchim, **35 : 15** in Koshi and **40 : 10** in Bagmati.
- In **Lumbini** and **Karnali** the objective test is only a screening test. Its marks are not added to the final result.

---

## 2. Progress tracker

| Part | Content | File | Status |
|---|---|---|---|
| 1 | Master Index | [`part-01-master-index.md`](part-01-master-index.md) | ✅ Written |
| 2 | Seven-Province Syllabus Comparison and Priority Classification | [`part-02-syllabus-comparison.md`](part-02-syllabus-comparison.md) | ✅ Written |
| 3 | Study Strategy | [`part-03-study-strategy.md`](part-03-study-strategy.md) | ✅ Written |
| 4 | Chapter Roadmap | [`part-04-chapter-roadmap.md`](part-04-chapter-roadmap.md) | ✅ Written |
| 5 | Chapter 1 — Geography of Nepal | [`part-05-chapter-01-geography-of-nepal.md`](part-05-chapter-01-geography-of-nepal.md) | ✅ Written — 9 topics, 70 MCQs, 14 short-answer questions |
| 6 | Chapter 2 — History of Nepal | [`part-06-chapter-02-history-of-nepal.md`](part-06-chapter-02-history-of-nepal.md) | ✅ Written — 10 topics, 75 MCQs, 15 short-answer questions |
| 7 | Chapter 3 — Constitution of Nepal | [`part-07-chapter-03-constitution-of-nepal.md`](part-07-chapter-03-constitution-of-nepal.md) | ✅ Written — 10 topics, 75 MCQs, 15 short-answer questions |
| 8 | Chapter 4 — Federalism and Governance | [`part-08-chapter-04-federalism-and-governance.md`](part-08-chapter-04-federalism-and-governance.md) | ✅ Written — 8 topics, 65 MCQs, 13 short-answer questions |
| 9 | Chapter 5 — Economy and Public Finance | [`part-09-chapter-05-economy-and-public-finance.md`](part-09-chapter-05-economy-and-public-finance.md) | ✅ Written — 10 topics, 75 MCQs, 15 short-answer questions |
| 10 | Chapter 6 — Society, Culture and Heritage | [`part-10-chapter-06-society-culture-heritage.md`](part-10-chapter-06-society-culture-heritage.md) | ✅ Written — 10 topics, 75 MCQs, 15 short-answer questions |
| 11 | Chapter 7 — Science, Technology and Environment | [`part-11-chapter-07-science-technology-environment.md`](part-11-chapter-07-science-technology-environment.md) | ✅ Written — 10 topics, 75 MCQs, 15 short-answer questions |
| 12 | Chapter 8 — International Relations and Organisations | [`part-12-chapter-08-international-relations.md`](part-12-chapter-08-international-relations.md) | ✅ Written — 10 topics, 75 MCQs, 15 short-answer questions |
| 13 | Chapter 9 — Current Affairs | [`part-13-chapter-09-current-affairs.md`](part-13-chapter-09-current-affairs.md) | ✅ Written — 8 topics, 65 MCQs, 13 short-answer questions |
| 14 | Chapter 10 — Koshi Province | [`part-14-chapter-10-koshi-province.md`](part-14-chapter-10-koshi-province.md) | ✅ Written — 7 topics, 60 MCQs, 12 short-answer questions |
| 15 | Chapter 11 — Madhesh Province | [`part-15-chapter-11-madhesh-province.md`](part-15-chapter-11-madhesh-province.md) | ✅ Written — 7 topics, 60 MCQs, 12 short-answer questions |
| 16 | Chapter 12 — Bagmati Province | `part-16-chapter-12-bagmati-province.md` | ⏳ **Next** |
| 17–20 | Chapters 13–16 — Gandaki, Lumbini, Karnali, Sudurpashchim | see Part 1 | ◻ Pending |
| 21 | Chapter 17 — Public Management and Office Management | `part-21-chapter-17-public-management.md` | ◻ Pending |
| 22 | Chapter 18 — Mental Ability | `part-22-chapter-18-mental-ability.md` | ◻ Pending |
| 23–25 | Chapters 19–21 — Universe and World Geography; World History; Nepali and English | see Part 1 | ◻ Pending |
| 26–28 | Rapid revision capsule; model tests; consolidated references | see Part 1 | ◻ Pending |

**Resume point for CONTINUE:** Part 16, Chapter 12 (Bagmati Province), topic 12.1. The template for the province chapters is in Part 4, section 4.3; Chapters 10 and 11 are the worked models.

**Questions written so far:** 770 MCQs (70 + 75 + 75 + 65 + 75 + 75 + 75 + 75 + 65 + 60 + 60) and 154 short-answer questions (14 + 15 + 15 + 13 + 15 + 15 + 15 + 15 + 13 + 12 + 12). None is presented as a past question.

---

## 3. Commands

| You type | What happens |
|---|---|
| **CONTINUE** | The next pending Part is written, starting exactly at the resume point above. You may add a request, for example "CONTINUE with Mental Ability" or "CONTINUE with the Madhesh chapter". |
| **UPDATE** | Every fact marked 🔄 in the written Parts is checked again against current sources and corrected. The open syllabus items in Part 2, section 2.12 are also re-tried. |
| **MOCK TEST** | A full 50-question test in the official format of the province you name, with answer key, explanations and a score sheet that applies the 0.4 deduction. Until more chapters are written, a test can cover only the chapters that exist (now Geography, History, the Constitution of Nepal, Federalism and Governance, Economy and Public Finance, Society, Culture and Heritage, Science, Technology and Environment, International Relations and Organisations, Current Affairs, Koshi Province and Madhesh Province). |

---

## 4. Layout of every chapter

**Each topic has ten parts**

1. Why it matters
2. Simple explanation
3. Key facts
4. Table
5. Numbers and dates to remember
6. Memory aid
7. Exam traps
8. Province link
9. Practice MCQs (five, each labelled, with answer and explanation)
10. Short-answer question with a model answer

**Each chapter ends with** Quick Revision · Top 20 facts · Top 25 MCQs (none repeated from the topics) · five short-answer questions · common mistakes · status of the facts · references.

---

## 5. Labels and marks

| Mark | Meaning |
|---|---|
| `[PYQ – Verified]` | A question traced to an official question paper or answer key. **Used 0 times** — see section 6. |
| `[Pattern-Based – Reconstructed]` | Written to an official question format (true/false statements, matching, ordering, odd one out, cause and effect, fill in the blank). **Not** a real past question. |
| `[Expected – Practice]` | An original practice question on a point the official syllabus names. |
| 🔄 **UPDATE** | The fact changes with time. Learn it with its date. |
| ⚖️ **DISPUTED** | Published sources disagree. Both versions are given. |

---

## 6. Honesty notes — read these once

**No verified past questions.** No official question paper or answer key of any provincial commission could be opened during this research. This book therefore contains **no** question presented as a past question. Websites and applications that publish "previous year questions" without the paper, set and year were not used.

**The syllabus comparison has gaps.** They are listed in Part 2, sections 2.1 and 2.12. The main ones:

| Province | Gap |
|---|---|
| Madhesh | The official file listed on 24 Mangsir 2082 could not be opened. A third-party copy of the document headed "Province No. 2" (effective 2078/04/27) was read instead. The page with the unit titles could not be read, even on a second attempt on 12 November 2026; the titles are inferred from the identical question allocation of Gandaki and Sudurpashchim. |
| Bagmati | Third-party copies of the 2077/09/12 syllabus were read. The official site was not re-checked for a later revision. Unit counts add to 41 instead of 40. |
| Lumbini | A revision notice dated 2 Ashoj 2083 exists as an image and could not be read. |
| Karnali | The effective date, the pass mark and the unit-wise table were not legible. |
| Koshi | The verbal / quantitative / non-verbal split was not legible. |
| Gandaki | The effective date was blank in the copy read. |

**Two things in this book are the author's reconstruction, not your original wording.** Tell me if they differ from what you asked for, and they will be changed everywhere:

1. the **ten-part layout** of each topic (section 4);
2. the name of the third label, **`[Expected – Practice]`**.

**How facts were checked.** Each chapter ends with a table that separates (a) facts checked against a source during the research, (b) standard reference facts that were cross-checked by arithmetic but not re-opened on an official site, and (c) disputed facts. Government websites could be read only partly, so several current figures rest on press reports that quote the responsible office. These are marked 🔄.

**Dates.** Bikram Sambat and Common Era date pairs after 1975 BS were computed with a calendar-conversion library, not from memory. The library does not cover earlier years, so dates before 1975 BS (mostly in Chapter 2) are standard textbook dates.

**The Constitution.** Chapter 3 was checked Article by Article against public copies of the text — an English translation and the Nepali text. The Nepal Law Commission's own website could not be opened, so the copies are not the official file. Where the two copies differ, the Nepali text is followed and the difference is stated in the chapter.

**Acts and office-holders.** Chapter 4 names many Acts — on local government, fiscal arrangement, good governance, the right to information and the civil service. These Acts were **not** read in full. Their provisions were taken from extracts of the Nepal Law Commission's pages shown in search results and from secondary articles, and a few are standard reference facts that were not re-opened; the table at the end of the chapter says which is which. Names of Chief Ministers, Province Chiefs and heads of commissions come from news reports and encyclopaedia pages, not from the offices' own websites, and they change often.

**Economic figures.** Chapter 5 is full of yearly figures: GDP, growth, trade, remittance, the budget, revenue, debt and interest rates. They were read in news reports and study websites that quote the Economic Survey 2082/83, Nepal Rastra Bank, the Department of Customs and other offices. The official documents were **not** opened. A few reports disagree with one another; the table at the end of the chapter names each case and says which figure was used. Every such figure will be out of date within a year, so it carries the 🔄 mark and its fiscal year.

**Society and culture.** Chapter 6 rests on two kinds of fact. Census figures (population, castes, languages, religions, literacy) are the final results of the Census of 2078, but they were read in news reports and encyclopaedia pages, not in the National Statistics Office's own tables; the province-wise shares in particular are rounded and second-hand. Festivals, dances, instruments, writers, temples and social laws are standard reference facts that were written from general knowledge and not re-opened in an official source this time. The table at the end of the chapter says which is which. One topic, 6.10 Education, was added to the original plan.

**Science, technology and environment.** Chapter 7 mixes two kinds of fact. School science — units, inventors, vitamins, germs, the cell, the six everyday materials, the years of world treaties — is standard reference matter that was written from general knowledge and not re-opened fact by fact. Recent facts — health indicators, cybercrime figures, the tiger count of July 2026, the climate conferences and Nepal's pledges, the Carbon Trade Regulations of 2082, the new names of the ministries — were read in news reports and are marked 🔄. The figures of the **Bhote Koshi flood of 10 Bhadra 2083** are provisional: the count of dead and missing was still changing, and the cause was still being studied, when the chapter was written. The table at the end of the chapter also lists a group of Nepal facts that were written from memory of standard references and should be checked before anyone relies on a single one of them.

**International relations.** Chapter 8 also mixes two kinds of fact. Fixed facts — the founding dates and seats of world bodies, the Charter, the lists of Secretaries-General and summits, treaty dates and signers, the years in which Nepal joined each body — are standard reference matter that was written from general knowledge and not re-opened one by one. Moving facts — office-holders, the number of countries with diplomatic relations (188), Nepal's seats in United Nations bodies, the latest summits, the visits and notes of 2026 — were read in press reports, United Nations news and pages of the Ministry of Foreign Affairs, and are marked 🔄. **Six matters were still open on 11 November 2026** and are listed at the head of the chapter: the next Secretary-General of the United Nations had not been chosen; the Prime Minister's visit to India (planned for 22–25 November) had not taken place; the 16th Secretary-General of SAARC had been appointed but not reported in office; the 49th ASEAN Summit and COP31 were not over; and the war in the Gulf was not settled. Anything the chapter says about these is a statement of that day only.

**Current affairs.** Chapter 9 is made only of moving facts, from May 2025 to 11 November 2026. Most of them rest on one or two press reports or on an encyclopaedia year-page, not on a gazette or an official notice; where reports disagree the chapter says so. Some matters were still open on the day of writing — the Prime Minister's visit to India, the next Secretary-General of the United Nations, COP31, the G20 summit, the war on Iran — and the chapter lists them at its head. It grows old faster than any other chapter: use **UPDATE**, and read a daily newspaper in the last weeks.

**Province chapters.** Chapter 10 (Koshi) is the first of seven. It keeps every figure that Chapters 1 to 9 already give and adds the facts of the province itself. These new facts come mostly from encyclopaedia pages, the provincial government's portal and press reports. The plan document, the budget speech, the census tables and the provincial gazette were **not** read; the planning commission's page shows the plan only in a viewer. District populations and many smaller facts — home districts of peoples, holy places, products, persons — were written from standard references and not re-opened; section F of the chapter lists them. Three matters were open on the day of writing, and the chapter says so: no new Province Chief had been reported after 24 Kartik 2083; the chair of the Province Public Service Commission was vacant; and the press report read does not say where about 14 percent of the budget of 2083/84 goes. Chapter 11 (Madhesh) follows the same method. Its special limits are these: the unit titles of the Madhesh syllabus could not be read, so the chapter cannot quote the wording it serves; the plan file, the budget speech and the provincial portal could not be opened, so the plan's number targets rest on third-party notes; the chapter was written two days before a vote of confidence whose result it cannot give; and a number of historical and local facts were written from memory or taken from general-knowledge books — section F of the chapter lists both groups.

**Weightage.** "Priority" reflects the official number of questions per unit. It is not a count of past papers, and no cut-off marks are quoted.

---

## 7. Verification log

| Date | What was checked | Result |
|---|---|---|
| 10 Nov 2026 | Syllabi of seven provinces | Five official PDFs read (Koshi, Gandaki, Lumbini, Karnali, Sudurpashchim); two third-party copies (Madhesh, Bagmati). Gaps as in section 6. |
| 10 Nov 2026 | Official past papers and answer keys | None found. |
| 10 Nov 2026 | Chapter 1: forest cover, protected areas, Ramsar sites, census totals, snow-leopard estimate, monsoon dates, installed electricity capacity, Dailekh gas reserve | Checked against the sources listed at the end of Chapter 1. |
| 10 Nov 2026 | Chapter 1: structure | 9 topics × 10 parts; 70 MCQs (45 + 25), each with four options, one answer and a label; no repeated question. |
| 10 Nov 2026 | Chapter 1: arithmetic | Districts 77; local levels 753 by type and by province; province populations 29,164,578; province areas 147,181; border districts 27 and 15; province densities recomputed. |
| 11 Nov 2026 | Chapter 2: recent events (movement of Bhadra 2082, interim government, election of 21 Falgun 2082, new Prime Minister) | Checked against published results and news reports listed at the end of Chapter 2. Not checked on the Election Commission's own site. |
| 11 Nov 2026 | Chapter 2: dates | About a hundred BS–AD pairs from 1975 BS onward converted by tool; in each pair the two remembered dates agreed. Dates before 1975 BS are standard textbook dates, not tool-checked. |
| 11 Nov 2026 | Chapter 2: structure and arithmetic | 10 topics × 10 parts; 75 MCQs (50 + 25), each with four options, one answer and a label; every matching and ordering key re-read against the text; seats of 2015 BS add to 109 and seats of 2082 BS add to 275. |
| 11 Nov 2026 | Chapter 3: text of the Constitution | Every Article number and Part range used in the chapter was compared with a full English copy of the text, and the ages, terms, majorities and time limits were read from the same copy; key figures were compared again with the Nepali text. Differences between the two copies that affect the chapter were found in Articles 113, 151 and 289, and the Nepali text was followed. Not checked on the Nepal Law Commission's site. |
| 11 Nov 2026 | Chapter 3: amendments and recent events | Votes and dates of the two amendments, the present Prime Minister, Speaker, Deputy Speaker and Chief Justice, and the constitution-amendment task force were checked against news reports listed at the end of Chapter 3. No report of a third amendment was found in sources dated up to September 2026. |
| 11 Nov 2026 | Chapter 3: structure, dates and arithmetic | 10 topics × 10 parts; 75 MCQs (50 + 25), each with four options, one answer and a label; every matching, ordering and statement key re-read; 41 BS–AD pairs re-computed by tool; constituencies add to 165, Provincial Assembly seats to 550, districts to 77, local levels to 753. |
| 11 Nov 2026 | Chapter 4: text of the Constitution | Articles 56–60, 160–237, 240–251, 269–272, 285, 288, 295 and 302 and Schedules 5 to 9 were read in the English copy; the numbers in about thirty of these Articles were compared with the Nepali text. Every Article number used in the chapter was matched against the Article's title. On Article 232 (4) the two copies differ (majority in Nepali, two thirds in English); the Nepali text is followed. |
| 11 Nov 2026 | Chapter 4: Acts, office-holders and figures for 2083/84 | Provisions of the Local Government Operation Act, the Inter-Governmental Fiscal Arrangement Act, the Good Governance Act and the Right to Information Act were checked through extracts and secondary sources, not the full Acts. Chief Ministers, Province Chiefs, the Chief Election Commissioner, the Public Service Commission, the Federal Civil Service Bill, the budget and grants for 2083/84 and the Corruption Perceptions Index 2025 were checked against news reports dated up to early November 2026. The new Province Chief of Koshi and the new Chairperson of the Public Service Commission could not be confirmed. |
| 11 Nov 2026 | Chapter 4: structure, dates and arithmetic | 8 topics × 10 parts; 65 MCQs (40 + 25), each with four options, one answer and a label; every matching, ordering and statement key re-read; 27 different BS–AD pairs re-computed by tool; grants add to the stated totals; Assembly seats add to 550, wards to 6,743, electoral colleges to 2,056 and directly elected local posts to 35,221. Two questions that repeated Chapter 3 were replaced. |
| 11 Nov 2026 | Chapter 4: late audit | Two points left from the first audit were corrected: the Koshi Province Chief's term is now described as due to end on 24 Kartik 2083, with no successor reported (the news reports were written before that day); and the list of facts not re-opened in an official source was completed. |
| 11 Nov 2026 | Chapter 5: text of the Constitution | Articles 33, 50, 51, 59, 60, 110, 111, 115–125 and 241 were read in the English copy used for Chapters 3 and 4. |
| 11 Nov 2026 | Chapter 5: economic figures, plans, budget, banking, graduation | Checked against news reports and study websites dated up to early November 2026 that quote the Economic Survey 2082/83, the National Statistics Office, Nepal Rastra Bank, the Department of Customs, the Financial Comptroller General Office, the Public Debt Management Office, the Nepal Tourism Board and the United Nations. The official documents were not opened. Reports differ on paddy output, on one remittance figure, on the interest-rate corridor and on the public debt of mid-July 2026; the chapter's status table gives the figure used in each case. The move of graduation from the least-developed-country category to 24 November 2029 (General Assembly, 29 October 2026) was confirmed in five reports. |
| 11 Nov 2026 | Chapter 5: structure, dates and arithmetic | 10 topics × 10 parts; 75 MCQs (50 + 25), each with four options, one answer and a label; every matching, ordering and statement key re-read; 37 different BS–AD pairs re-computed by tool; provincial shares of GDP add to 100; the seven provincial budgets add to about Rs 292 billion; the revenue heads, the trade figures and the count of 105 banks and financial institutions add up; the heads and the sources of the federal budget, as reported, add up to within Rs 0.02 billion of the announced total; no question repeats one from Chapters 1 to 4. |
| 11 Nov 2026 | Chapter 6: text of the Constitution | Articles 3, 4, 6, 7, 9, 24, 26, 29, 31, 32, 38–43, 51 (j), 84, 252–265, 277, 281 and 287 were read in the English copy used for Chapters 3 to 5. |
| 11 Nov 2026 | Chapter 6: census, languages, heroes, awards, heritage, holidays, education | Checked against news reports, encyclopaedia pages and study websites dated up to 11 November 2026. Confirmed in more than one report: 142 castes and ethnic groups, 124 mother tongues, 10 religions and their shares; literacy by sex, province and district; the 18 national heroes; the Madan Puraskar for 2081; the deferral of Tilaurakot in July 2025; the holiday list for 2083, Gen Z Martyrs' Day and the two weekly holidays; Bagmati's official languages. Koshi's 13 official languages rest on one report dated 11 November 2026, and the Madan Puraskar and Jagadamba Shree for 2082 on one report of September 2026. Province-wise shares of castes and languages come from encyclopaedia pages only. Sources disagree on the year the first thirteen national heroes were named, so no year is given. |
| 11 Nov 2026 | Chapter 6: structure, dates and arithmetic | 10 topics × 10 parts; 75 MCQs (50 + 25), each with four options, one answer and a label; every matching, ordering and statement key re-read; 21 different BS–AD pairs re-computed by tool; province populations add to 29,164,578 and their shares to 100; age groups add to 100; the five classes of indigenous nationalities add to 59; no question repeats one from Chapters 1 to 5. |
| 11 Nov 2026 | Chapter 7: syllabus wording | The science and environment units were re-read in the syllabus files of Gandaki, Koshi, Lumbini and Sudurpashchim (official) and Bagmati (third-party copy). Result: the six everyday materials are named by Gandaki, Koshi, Lumbini and Bagmati, not only by Lumbini; Bagmati also names carbon trade and the Sustainable Development Goals. Part 2, section 2.8 was corrected. Karnali's file could not be opened again. |
| 11 Nov 2026 | Chapter 7: recent facts | Checked against United Nations news, a World Bank press release and press reports dated up to 11 November 2026: COP30 and COP31, the temperature record, the third NDC, Sagarmatha Sambaad, the Carbon Trade Regulations of 2082 and the first forest-carbon payment; life expectancy, mortality and malnutrition figures, rubella, measles, health insurance, the vaccine schedule; cybercrime figures and the AI policy; Nepal's satellites, Artemis II and the Nobel Prizes of 2026; the tiger count of 2026; the Population Policy of 2082, migration and urbanisation; the bodies under the disaster Act; the Bhote Koshi flood. Reports differ on the flood's toll and cause, on the day the ministries were regrouped and on the day the AI policy was approved; the chapter says so. |
| 11 Nov 2026 | Corrections to earlier chapters found while researching Chapter 7 | **Chapter 1:** the tiger number was changed from 355 (count of 2022) to **429** (count announced on 29 July 2026) in four places, including practice question T20; a note on the Bhote Koshi flood was added to the glacial-lake facts and to the installed-capacity fact; one ministry name in the references was updated. **Chapter 4:** the ministry for communication is now the Ministry of Information and Communication, and information technology is under the Office of the Prime Minister and Council of Ministers (regrouping of Baisakh 2083). **Chapter 6:** one ministry name in the references was updated. |
| 11 Nov 2026 | Chapter 7: structure, dates and arithmetic | 10 topics × 10 parts; 75 MCQs (50 + 25), each with four options, one answer and a label; every matching, ordering and statement key re-read; 31 different BS–AD pairs re-computed by tool; the five tiger areas add to 429; the protected animals add to 38; the municipalities add to 293; no question repeats one from Chapters 1 to 6. |
| 11 Nov 2026 | Chapter 8: syllabus wording | The second part of the official Lumbini file and of the third-party Bagmati copy was read. Result: Lumbini's sub-units 1.10.2 and 1.10.3 are worded like Gandaki's (United Nations — introduction, organs, specialised agencies and activities; SAARC, BIMSTEC, ASEAN, European Union), and its question row again reads 3 for unit 1.10; Bagmati's unit 1.9 has four sub-units and also names the International Cooperative Alliance. Part 2 was amended on both points. Karnali's and Madhesh's wording was not seen again. |
| 11 Nov 2026 | Chapter 8: recent facts | Checked against United Nations news and media pages, press releases and pages of the Ministry of Foreign Affairs, a release of the Asian Development Bank, pages of the European Commission and the European Central Bank, the text of the MCC compact and press reports dated up to 11 November 2026: the 188 countries with diplomatic relations and the 44 missions; the Prime Minister's address of 24 September 2026; the Foreign Minister's visits to India and China; the Lipulekh notes of 3 May 2026; the election of the General Assembly President and of Security Council members; the straw polls for the next Secretary-General; Nepal's presidency of the Economic and Social Council and its election to the Human Rights Council; the SAARC and BIMSTEC Secretaries-General; Timor-Leste in ASEAN; Bulgaria and the euro; the heads of the World Bank, the Fund, the Asian Development Bank, the ILO, the WHO, UNESCO and the World Trade Organization; the MCC ground-breaking; the Nagdhunga tunnel; the halt on labour approvals for the Gulf. Sources disagree on the number of Nepali peace-keepers and on several exact days; the chapter's status table says how each was handled. The head of the FAO and the fixed facts of the organisations were not re-opened. |
| 11 Nov 2026 | Corrections to earlier parts found while researching Chapter 8 | **Part 2:** the note on Lumbini's units 1.10–1.12 now records the second reading (3-2-2), and the row on international relations in section 2.8 now names the International Cooperative Alliance for Bagmati and Lumbini's wording. **Chapter 7:** the Foreign Minister's name was changed from "Shishir Khanal" to "Shisir Khanal", the spelling used by the Ministry of Foreign Affairs. The facts that Chapter 8 shares with Chapters 1, 2, 3, 5 and 7 (boundary lengths, treaty dates, United Nations membership, Articles 51, 278 and 279, the trade share of India, graduation, the floods) were compared and needed no change. |
| 11 Nov 2026 | Chapter 8: structure, dates and arithmetic | 10 topics × 10 parts; 75 MCQs (50 + 25), each with four options, one answer and a label; every matching, ordering and statement key re-read; 24 different BS–AD pairs re-computed by tool; two questions that repeated questions of Chapter 2 were replaced, after which no question repeats one from Chapters 1 to 7. |
| 11–12 Nov 2026 | Chapter 9: recent facts | Gathered from encyclopaedia year-pages for Nepal (2025 and 2026) and the world (2026), a press time line of the movement of 2082, United Nations pages, a notice of the World Health Organization, a reference page on the Nobel winners of 2026, the Booker Prizes' pages, pages on the cricket and football tournaments, an examination-guide list of days and themes, and press reports dated up to 11 November 2026. Economic figures and provincial budgets were taken from Chapter 5; wildlife and disaster figures from Chapter 7; foreign-relations facts from Chapter 8. Not found and therefore not stated: a new Province Chief of Koshi, a Chairperson of the Public Service Commission, dates for the elections of 2084, a Bill to amend the Constitution, the theme of World Population Day 2026. |
| 12 Nov 2026 | Chapter 9: structure, dates and arithmetic | 8 topics × 10 parts; 65 MCQs (40 + 25), each with four options, one answer and a label; answers spread 16–17–16–16 over (a)–(d); every matching, ordering and statement key re-read; 130 BS–AD pairs re-computed by tool; one question that repeated a question of Chapter 5 was replaced, after which no question repeats one from Chapters 1 to 8. The checks are now a script, `android-app/tools/check_chapter.py`. |
| 12 Nov 2026 | Wording made the same as Chapter 8 | Chapter 9 calls the planned visit to India the Prime Minister's first *bilateral* visit abroad; his first trip abroad was to the United Nations in September 2026. No correction to an earlier Part was needed. |
| 12 Nov 2026 | Chapter 10: syllabus wording | Units 1.5 and 1.10 were read again in the official Koshi file. Unit 1.5 asks for the geographical, social, religious, cultural and economic condition of Koshi Province (2 questions); unit 1.10 names the provincial periodic plan. |
| 12 Nov 2026 | Chapter 10: facts of the province | Checked against the provincial portal, encyclopaedia pages on the province, its Chief Ministers and its Assembly, the planning commission's list of plans and press reports dated up to 12 November 2026: founding, capital and naming (82 votes to 4); the fourteen districts with headquarters, areas and local levels; shares of peoples, languages and religions; the thirteen provincial languages in use from 25 Kartik 2083; the economy of 2082/83, farm shares, installed power (994.0 megawatts in Ashad 2083) and Arun III; the coalition change of Shrawan–Bhadra 2083, the Council of Ministers and the vote of confidence (57 to 22); the three Province Chiefs; both periodic plans; the budget and the Policy and Programme for 2083/84. Not found and therefore not stated: a new Province Chief (searched four times), a new chairperson of the Province Public Service Commission, where about 14 percent of the budget goes. The plan document was not read; district populations and the smaller facts listed in section F of the chapter were not re-opened. |
| 12 Nov 2026 | Corrections to earlier Parts found while researching Chapter 10 | **Chapter 5**, topic 5.6: the Koshi row of the provincial plans gave "स्वच्छ, सुखी र समुन्नत प्रदेश" as the vision of the second plan. It is the province's **long-term** vision, kept since the first plan; the second plan was reported at its release (31 Shrawan 2081) with its own wording, "सुशासित, खुसी, आर्थिक रूपले गतिशील र समुन्नत प्रदेश". The row now gives both, and the status table of Chapter 5 notes the change. **Chapter 6**, topic 6.3: the list of Koshi's provincial languages named twelve of the thirteen; it now names all thirteen, with Rai; the spelling "Tehrathum" was made "Terhathum", as in Chapters 1 and 10. **Chapter 9**, topic 9.7: the change of coalition partner in Koshi (Shrawan–Bhadra 2083) and the vote of confidence of 8 Bhadra 2083 were added to the Koshi facts and to the model answer. **Part 4:** a broken fragment of the old plan for Chapter 9 was removed. The lines on the Koshi Province Chief in Chapters 4 and 9 were compared and needed no change. |
| 12 Nov 2026 | Chapter 10: structure, dates and arithmetic | 7 topics × 10 parts; 60 MCQs (35 + 25), each with four options, one answer and a label; answers spread 15–15–15–15 over (a)–(d); every matching, ordering and statement key re-read; 95 BS–AD pairs re-computed by tool; district areas add to 25,905 sq km, district populations to 4,961,412, local levels to 137 (1 + 2 + 46 + 88), House constituencies to 28, Assembly seats to 93, installed power by district to 977.2 megawatts and the seven provincial budgets to about Rs 292 billion; every rank of Koshi among the provinces in topic 10.7 was compared with the tables of Chapters 1, 4, 5 and 6; one question that repeated a question of Chapter 9 was replaced, after which no question repeats one from Chapters 1 to 9. |
| 12 Nov 2026 | Chapter 11: syllabus wording | The Madhesh syllabus was looked for again. The official page shows the file only in a viewer. In the third-party copy the cover page, the marks table, the first page of Paper II and the two pages on the computer test were read again and agree with Part 2: 50 questions, 30 + 20, eleven general-knowledge units with 1, 2, 4, 1, 2, 4, 3, 3, 3, 2 and 5 questions, 18 questions of Level I and 12 of Level II. The page with the unit titles could not be opened. Result: no unit is set apart for the province; the titles stay unread. |
| 12 Nov 2026 | Chapter 11: facts of the province | Checked against encyclopaedia pages on the province, the districts of Nepal, the Chief Minister, the Governor and the second Assembly, and press reports dated up to 12 November 2026: the naming vote (80 and 78 votes of 99); the eight districts with headquarters, areas and populations; local levels by kind in each district; shares of peoples, languages and religions; seats won in 2074 and 2079; the six Chief Ministers and six Province Chiefs with dates; the removal of the Speaker; the three votes of confidence, the third still to come; the budget of 2083/84 with its sources; the vision and goal of the second plan; the provincial accounts of 2082/83; Parsa National Park; the drought declarations of 2082; the Sunkoshi–Marin Diversion; the two agreements of 2064; the Public Service Commission of the province. **Not opened:** the provincial portal, the plan file, the budget speech. **From memory or from general-knowledge books:** the items listed in section F of the chapter. |
| 12 Nov 2026 | Corrections to earlier Parts found while researching Chapter 11 | **Part 2:** the Madhesh note now records the second reading, and the row "Own province" says that Madhesh has no separate unit. **Part 4:** the Madhesh row of section 4.3 and items 6 and 8 of section 4.7 were brought up to date. **Chapter 5**, topic 5.8: a caution was added under the table of grants — the reported sources of the Madhesh budget reach Rs 41.14 billion without the conditional grant, so the share of 42.8 percent may not compare like with like. No figure of Chapters 1 to 10 was changed. |
| 12 Nov 2026 | Chapter 11: structure, dates and arithmetic | 7 topics × 10 parts; 60 MCQs (35 + 25), each with four options, one answer and a label; 24 of the 60 in the harder forms; answers spread 15–15–15–15 over (a)–(d); every matching, ordering and statement key re-read; 113 BS–AD pairs re-computed by tool; district areas add to 9,661 sq km, district populations to 6,114,600, local levels to 136 (1 + 3 + 73 + 59), House constituencies to 32, seats won in 2074 and in 2079 to 107 each; the five reported sources of the budget add to Rs 41.1386 billion; every rank of Madhesh in topic 11.7 was compared with the tables of Chapters 1, 4, 5 and 6; two end-of-chapter questions that came too close to questions in the topics were replaced. The checker reports no problem; the six stems it lists as "nearly repeated" are the same question forms as in Chapter 10, asked about a different province. |

**Still to research for later chapters:** the heads of the constitutional bodies (the Public Service Commission had only an acting Chairperson); a new Province Chief of Koshi and a new chairperson of its Province Public Service Commission (neither was found on 12 November 2026); the text of Koshi's second periodic plan and of its budget speech; the Madhesh syllabus file, whose unit titles are still unread; the result of the Madhesh vote of confidence of 28 Kartik 2083, the province's ministers and ministries, and the text of its second periodic plan and budget speech; the matters left open in Chapter 9 (the Prime Minister's visit to India, the next Secretary-General of the United Nations, COP31, the G20 summit of December 2026, the war on Iran, the final figures of the Bhote Koshi flood); the official text of the Economic Survey 2082/83, the Budget Speech 2083/84, the Sixteenth Plan and the census tables, which Chapters 4 to 7 used only through news reports; the periodic plans of Bagmati and Sudurpashchim; Karnali's syllabus file republished in Baisakh 2083; for the province chapters, province-wise tables of caste, language and religion and each province's own laws, bodies and plans.

---

## 8. Relation to the application in this repository

The study book is plain Markdown in this folder. **No file of the application (`src/`) was changed.** Two points were noticed in the application's seed data while reading the repository; they are reported here and were left untouched:

- the seeded sample attempts are scored at **1 mark** per correct answer with **0.2** deducted per wrong answer. The 20% ratio agrees with the syllabi, but the official paper gives **2 marks** per question and deducts **0.4**, so the application's scores are on half the official scale;
- some seeded questions are flagged as previous-year questions and name an examination and a year, but no source is given against which this can be checked. One of them states the lowest point of Nepal as a settled fact, although sources disagree (Chapter 1, topic 1.7).

The book can be connected to the application later (a reader page, or the MCQs imported as question seeds). This has not been done.

Separately from that application, the book is published in two forms that are made from these Markdown files and change nothing in `src/`: an Android app (folder `android-app`) and a web app (folder `web-app`, built into the folder `docs` for GitHub Pages).
