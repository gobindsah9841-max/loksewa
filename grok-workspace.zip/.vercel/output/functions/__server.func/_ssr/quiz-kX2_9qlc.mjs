import { i as __toESM } from "../_runtime.mjs";
import { J as require_react, S as require_jsx_runtime, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { r as useProgress } from "./quiz-search-BHTI1vVz.mjs";
import { i as Bookmark } from "../_libs/lucide-react.mjs";
import { a as useHydrated, i as Route$2 } from "./router-B5IjRnlh.mjs";
import { l as plain, o as collectQuestions, p as shuffle } from "./catalog-BzfA9AI0.mjs";
import { t as Page } from "./page-D4NR8KpN.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/quiz-kX2_9qlc.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var LETTERS = [
	"A",
	"B",
	"C",
	"D"
];
function clock(total) {
	const s = Math.max(0, total);
	const m = Math.floor(s / 60);
	const r = s % 60;
	return `${m}:${r < 10 ? "0" : ""}${r}`;
}
function marks(correct, wrong) {
	return Math.round((2 * correct - .4 * wrong) * 10) / 10;
}
function QuizRunner({ title, mode, timed, questions }) {
	const record = useProgress((s) => s.record);
	const toggleSaved = useProgress((s) => s.toggleSaved);
	const addTest = useProgress((s) => s.addTest);
	const records = useProgress((s) => s.records);
	const [items, setItems] = (0, import_react.useState)(questions);
	const [picks, setPicks] = (0, import_react.useState)(() => questions.map(() => -1));
	const [index, setIndex] = (0, import_react.useState)(0);
	const [done, setDone] = (0, import_react.useState)(false);
	const [warn, setWarn] = (0, import_react.useState)(false);
	const [left, setLeft] = (0, import_react.useState)(timed ? questions.length * 54 : 0);
	const [openReview, setOpenReview] = (0, import_react.useState)(0);
	const picksRef = (0, import_react.useRef)(picks);
	const itemsRef = (0, import_react.useRef)(items);
	const recorded = (0, import_react.useRef)(false);
	picksRef.current = picks;
	itemsRef.current = items;
	(0, import_react.useEffect)(() => {
		if (!timed || done || mode !== "exam") return;
		const id = window.setInterval(() => {
			setLeft((value) => value <= 0 ? 0 : value - 1);
		}, 1e3);
		return () => window.clearInterval(id);
	}, [
		timed,
		done,
		mode
	]);
	(0, import_react.useEffect)(() => {
		if (timed && mode === "exam" && !done && left === 0) finish();
	}, [
		left,
		timed,
		mode,
		done
	]);
	function finish() {
		if (recorded.current) return;
		recorded.current = true;
		const current = picksRef.current;
		const list = itemsRef.current;
		let c = 0;
		let w = 0;
		let b = 0;
		current.forEach((pick, i) => {
			const q = list[i];
			if (!q) return;
			if (pick < 0) b += 1;
			else if (pick === q.answer) c += 1;
			else w += 1;
			if (mode === "exam" && pick >= 0) record(q.key, pick === q.answer);
		});
		if (mode === "exam") addTest({
			at: (/* @__PURE__ */ new Date()).toLocaleDateString("en-GB", {
				day: "numeric",
				month: "short"
			}),
			title,
			n: list.length,
			c,
			w,
			b
		});
		setDone(true);
		setOpenReview(0);
	}
	function choose(option) {
		if (done) return;
		if (mode === "practice" && picks[index] >= 0) return;
		const q = items[index];
		if (!q) return;
		setPicks((prev) => {
			const next = prev.slice();
			next[index] = option;
			picksRef.current = next;
			return next;
		});
		if (mode === "practice") record(q.key, option === q.answer);
	}
	function reset(nextItems) {
		const blank = nextItems.map(() => -1);
		recorded.current = false;
		picksRef.current = blank;
		itemsRef.current = nextItems;
		setItems(nextItems);
		setPicks(blank);
		setIndex(0);
		setDone(false);
		setWarn(false);
		setLeft(timed ? nextItems.length * 54 : 0);
	}
	const question = items[index];
	const answered = picks.filter((p) => p >= 0).length;
	const rightSoFar = picks.reduce((n, p, i) => n + (p >= 0 && p === items[i]?.answer ? 1 : 0), 0);
	if (done) {
		let c = 0;
		let w = 0;
		let b = 0;
		picks.forEach((p, i) => {
			if (p < 0) b += 1;
			else if (p === items[i]?.answer) c += 1;
			else w += 1;
		});
		const score = marks(c, w);
		const missed = items.filter((q, i) => picks[i] !== q.answer);
		return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-col gap-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
					className: "rounded-2xl border border-line bg-card px-5 py-6 text-center",
					children: mode === "exam" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "font-display text-4xl text-fg",
						children: [
							score,
							" ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-xl text-muted",
								children: ["/ ", items.length * 2]
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-2 text-sm text-muted",
						children: [
							c,
							" right · ",
							w,
							" wrong · ",
							b,
							" blank. Right answers score 2. A wrong answer costs 0.4. A blank costs nothing."
						]
					})] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "font-display text-4xl text-fg",
						children: [
							c,
							" ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-xl text-muted",
								children: ["of ", items.length]
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm text-muted",
						children: "right on the first try"
					})] })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "min-h-12 rounded-xl bg-crimson font-semibold text-on-crimson",
							onClick: () => reset(shuffle(items)),
							children: "Try these again"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							disabled: !missed.length,
							className: "min-h-12 rounded-xl border border-line bg-card font-semibold text-fg disabled:opacity-40",
							onClick: () => reset(missed),
							children: [
								"Only the ones missed (",
								missed.length,
								")"
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/",
							className: "flex min-h-12 items-center justify-center rounded-xl border border-line font-semibold text-fg",
							children: "Back to the book"
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-xl",
					children: "Review"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "flex flex-col gap-2",
					children: items.map((q, i) => {
						const pick = picks[i] ?? -1;
						const ok = pick === q.answer;
						const blank = pick < 0;
						const open = openReview === i;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "overflow-hidden rounded-xl border border-line bg-card",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								className: "flex w-full items-start gap-3 px-3 py-3 text-left",
								onClick: () => setOpenReview(open ? null : i),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "mt-0.5 grid size-7 shrink-0 place-items-center rounded-full text-sm font-semibold " + (blank ? "bg-surface text-muted" : ok ? "bg-ok-bg text-ok" : "bg-bad-bg text-bad"),
									children: i + 1
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-sm leading-snug",
									children: plain(q.stem)
								})]
							}), open ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QuestionBody, {
								q,
								pick,
								reveal: true,
								locked: true,
								onChoose: () => void 0
							}) : null]
						}, q.key);
					})
				})
			]
		});
	}
	if (!question) return null;
	const pick = picks[index] ?? -1;
	const saved = !!records[question.key]?.saved;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between gap-3 text-sm text-muted",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
					index + 1,
					" of ",
					items.length,
					mode === "practice" ? ` · ${rightSoFar} right` : ` · ${answered} answered`
				] }), timed && mode === "exam" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: left <= 60 ? "font-semibold text-bad" : "font-semibold text-gold",
					children: clock(left)
				}) : null]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "h-1 overflow-hidden rounded-full bg-surface",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "h-full bg-crimson",
					style: { width: `${(index + (pick >= 0 ? 1 : 0)) / items.length * 100}%` }
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm text-gold",
					children: [question.source, question.label ? ` · ${question.label}` : ""]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					"aria-label": saved ? "Remove bookmark" : "Bookmark question",
					"aria-pressed": saved,
					className: "grid size-11 shrink-0 place-items-center rounded-full border border-line",
					onClick: () => toggleSaved(question.key),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bookmark, { className: saved ? "size-5 fill-gold text-gold" : "size-5 text-muted" })
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(QuestionBody, {
				q: question,
				pick,
				reveal: mode === "practice" && pick >= 0,
				locked: mode === "practice" && pick >= 0,
				onChoose: choose
			}),
			mode === "practice" ? pick >= 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "min-h-12 rounded-xl bg-crimson font-semibold text-on-crimson",
				onClick: () => {
					if (index + 1 >= items.length) finish();
					else setIndex(index + 1);
				},
				children: index + 1 >= items.length ? "See the result" : "Next question"
			}) : null : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-3 gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							disabled: index === 0,
							className: "min-h-12 rounded-xl border border-line bg-card font-semibold disabled:opacity-40",
							onClick: () => setIndex(index - 1),
							children: "Back"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							disabled: pick < 0,
							className: "min-h-12 rounded-xl border border-line bg-card font-semibold disabled:opacity-40",
							onClick: () => setPicks((prev) => {
								const next = prev.slice();
								next[index] = -1;
								picksRef.current = next;
								return next;
							}),
							children: "Clear"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							disabled: index + 1 >= items.length,
							className: "min-h-12 rounded-xl border border-line bg-card font-semibold disabled:opacity-40",
							onClick: () => setIndex(index + 1),
							children: "Next"
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid grid-cols-8 gap-1.5",
					children: items.map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setIndex(i),
						className: "h-9 rounded-md text-sm " + (i === index ? "bg-gold font-semibold text-on-gold" : picks[i] >= 0 ? "bg-surface text-fg" : "border border-line text-muted"),
						children: i + 1
					}, i))
				}),
				warn ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "rounded-xl bg-surface px-3 py-3 text-sm text-muted",
					children: [items.length - answered, " still blank. A blank is safer than a guess. Tap finish again to submit."]
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "min-h-12 rounded-xl bg-crimson font-semibold text-on-crimson",
					onClick: () => {
						if (answered < items.length && !warn) {
							setWarn(true);
							return;
						}
						finish();
					},
					children: "Finish the test"
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs leading-relaxed text-muted",
				children: "Practice questions for this book. They are not verified past-paper questions. Check changing figures before the examination."
			})
		]
	});
}
function QuestionBody({ q, pick, reveal, locked, onChoose }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-3",
		children: [
			q.html ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "stem font-display text-xl leading-snug",
				dangerouslySetInnerHTML: { __html: q.stem }
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-display text-xl leading-snug",
				children: q.stem
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-2",
				children: q.options.map((option, i) => {
					const chosen = pick === i;
					const correct = reveal && i === q.answer;
					const wrong = reveal && chosen && i !== q.answer;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						disabled: locked,
						onClick: () => onChoose(i),
						className: "flex min-h-12 items-start gap-3 rounded-xl border px-3 py-3 text-left " + (correct ? "border-ok bg-ok-bg" : wrong ? "border-bad bg-bad-bg" : chosen ? "border-gold bg-card" : "border-line bg-card"),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "mt-0.5 font-semibold text-gold",
							children: LETTERS[i]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "leading-snug",
							children: option
						})]
					}, i);
				})
			}),
			reveal ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-xl px-4 py-3 text-sm leading-relaxed " + (pick === q.answer ? "bg-ok-bg" : "bg-bad-bg"),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "font-semibold",
					children: ["Answer ", LETTERS[q.answer]]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1",
					children: q.explanation
				})]
			}) : null
		]
	});
}
function QuizPage() {
	const search = Route$2.useSearch();
	const hydrated = useHydrated();
	const [pack, setPack] = (0, import_react.useState)(null);
	const sig = [
		search.bank,
		search.mode,
		search.n,
		search.topic,
		search.batch,
		search.only,
		search.chs,
		search.timed
	].join("|");
	(0, import_react.useEffect)(() => {
		if (search.only && !hydrated) return;
		const collected = collectQuestions(search, useProgress.getState().records);
		if ("error" in collected) {
			setPack({
				title: "Practice",
				questions: [],
				error: collected.error
			});
			return;
		}
		const mixed = shuffle(collected.questions);
		const limit = search.n > 0 ? Math.min(search.n, mixed.length) : mixed.length;
		setPack({
			title: collected.title,
			questions: mixed.slice(0, limit),
			error: ""
		});
	}, [sig, search.only ? hydrated : false]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Page, {
		title: pack?.title || "Practice",
		back: search.bank === "mix" ? "/mock" : search.bank === "geo" ? "/bank/geo" : `/bank/${search.bank}`,
		children: [
			!pack ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-muted",
				children: "Preparing questions…"
			}) : null,
			pack && pack.error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-base leading-relaxed",
				children: pack.error
			}) : null,
			pack && !pack.error && pack.questions.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QuizRunner, {
				title: pack.title,
				mode: search.mode,
				timed: search.mode === "exam" && search.timed === 1,
				questions: pack.questions
			}, pack.questions.map((q) => q.key).join("|") + search.mode + String(search.timed)) : null
		]
	});
}
//#endregion
export { QuizPage as component };
