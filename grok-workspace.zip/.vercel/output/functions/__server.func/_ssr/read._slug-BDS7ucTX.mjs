import { i as __toESM } from "../_runtime.mjs";
import { J as require_react, S as require_jsx_runtime, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as Route } from "./router-B5IjRnlh.mjs";
import { u as readBySlug } from "./catalog-BzfA9AI0.mjs";
import { t as Page } from "./page-D4NR8KpN.mjs";
import { t as x } from "../_libs/marked.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/read._slug-BDS7ucTX.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function ReadPage() {
	const { slug } = Route.useParams();
	const meta = readBySlug(slug);
	const [html, setHtml] = (0, import_react.useState)("");
	const [failed, setFailed] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		if (!meta) return;
		let live = true;
		setHtml("");
		setFailed(false);
		(async () => {
			try {
				const res = await fetch(`/book/${meta.file}`);
				if (!res.ok) throw new Error("missing");
				const text = await res.text();
				const parsed = await x.parse(text);
				if (live) setHtml(parsed);
			} catch {
				if (live) setFailed(true);
			}
		})();
		return () => {
			live = false;
		};
	}, [meta]);
	if (!meta) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Page, {
		title: "Not found",
		back: "/",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "That part of the book is missing." })
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Page, {
		title: meta.title,
		back: "/",
		children: [
			meta.kind === "chapter" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/bank/$id",
				params: { id: String(meta.ch) },
				className: "mb-4 flex min-h-12 items-center justify-center rounded-xl bg-crimson font-semibold text-on-crimson",
				children: "Practice this chapter"
			}) : null,
			!html && !failed ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-muted",
				children: "Opening the chapter…"
			}) : null,
			failed ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "This chapter could not be opened." }) : null,
			html ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("article", {
				className: "reading",
				dangerouslySetInnerHTML: { __html: html }
			}) : null
		]
	});
}
//#endregion
export { ReadPage as component };
