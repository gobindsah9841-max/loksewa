import { i as __toESM } from "../_runtime.mjs";
import { J as require_react, S as require_jsx_runtime, b as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as quizSearch, r as useProgress } from "./quiz-search-BHTI1vVz.mjs";
import { a as chapters } from "./catalog-BzfA9AI0.mjs";
import { t as Page } from "./page-D4NR8KpN.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/mock-C9OJmNnC.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var SIZES = [
	10,
	25,
	50
];
function MockPage() {
	const navigate = useNavigate();
	const tests = useProgress((s) => s.tests);
	const [n, setN] = (0, import_react.useState)(25);
	const [timed, setTimed] = (0, import_react.useState)(true);
	const [picked, setPicked] = (0, import_react.useState)(() => ["geo", ...chapters.map((c) => String(c.num))]);
	const [message, setMessage] = (0, import_react.useState)("");
	function toggle(id) {
		setPicked((prev) => prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Page, {
		title: "Timed test",
		back: "/",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm leading-relaxed text-muted",
				children: "A mixed paper from the sets you tick. Marking follows the examination: 2 for a right answer, 0.4 off for a wrong one, nothing for a blank. The real paper is 50 questions in 45 minutes."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mt-5 mb-2 text-sm font-semibold text-gold",
				children: "Number of questions"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-3 gap-2",
				children: SIZES.map((size) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => setN(size),
					className: "min-h-12 rounded-xl border font-semibold " + (n === size ? "border-gold bg-gold text-on-gold" : "border-line bg-card"),
					children: size
				}, size))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mt-5 mb-2 text-sm font-semibold text-gold",
				children: "Time limit"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => setTimed(true),
					className: "min-h-12 rounded-xl border px-2 text-sm font-semibold " + (timed ? "border-gold bg-gold text-on-gold" : "border-line bg-card"),
					children: "54 seconds each"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => setTimed(false),
					className: "min-h-12 rounded-xl border font-semibold " + (!timed ? "border-gold bg-gold text-on-gold" : "border-line bg-card"),
					children: "No limit"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mt-5 mb-2 text-sm font-semibold text-gold",
				children: "Sets"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
				className: "flex flex-col gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "flex min-h-12 items-center gap-3 rounded-xl border border-line bg-card px-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "checkbox",
						checked: picked.includes("geo"),
						onChange: () => toggle("geo"),
						className: "size-5 accent-crimson"
					}), "Geography Master · 400 new"]
				}) }), chapters.map((chapter) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "flex min-h-12 items-center gap-3 rounded-xl border border-line bg-card px-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "checkbox",
						checked: picked.includes(String(chapter.num)),
						onChange: () => toggle(String(chapter.num)),
						className: "size-5"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
						"Chapter ",
						chapter.num,
						" — ",
						chapter.title
					] })]
				}) }, chapter.num))]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "mt-4 min-h-12 w-full rounded-xl bg-crimson font-semibold text-on-crimson",
				onClick: () => {
					if (!picked.length) {
						setMessage("Tick at least one set.");
						return;
					}
					navigate({
						to: "/quiz",
						search: quizSearch({
							bank: "mix",
							mode: "exam",
							n,
							timed: timed ? 1 : 0,
							chs: picked.join(",")
						})
					});
				},
				children: "Start the test"
			}),
			message ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm text-bad",
				children: message
			}) : null,
			tests.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mt-6 mb-2 font-display text-xl",
				children: "Your last tests"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "overflow-x-auto rounded-xl border border-line",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
					className: "w-full border-collapse text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
						className: "text-left text-muted",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-3 py-2 font-medium",
								children: "When"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-3 py-2 font-medium",
								children: "Set"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-3 py-2 font-medium",
								children: "Right"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-3 py-2 font-medium",
								children: "Marks"
							})
						]
					}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: [...tests].reverse().map((test, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
						className: "border-t border-line",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-3 py-2",
								children: test.at
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-3 py-2",
								children: test.title
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
								className: "px-3 py-2",
								children: [
									test.c,
									"/",
									test.n
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
								className: "px-3 py-2",
								children: [
									Math.round((2 * test.c - .4 * test.w) * 10) / 10,
									"/",
									test.n * 2
								]
							})
						]
					}, i)) })]
				})
			})] }) : null
		]
	});
}
//#endregion
export { MockPage as component };
