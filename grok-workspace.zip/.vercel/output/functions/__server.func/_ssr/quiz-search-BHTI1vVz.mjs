import { n as create, t as persist } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/progress-CqCQHDPs.js
var emptyRec = () => ({
	tries: 0,
	correct: 0,
	lastCorrect: false,
	saved: false
});
var useProgress = create()(persist((set, get) => ({
	records: {},
	tests: [],
	theme: "dark",
	record: (key, correct) => {
		const prev = get().records[key] ?? emptyRec();
		set({ records: {
			...get().records,
			[key]: {
				tries: prev.tries + 1,
				correct: prev.correct + (correct ? 1 : 0),
				lastCorrect: correct,
				saved: prev.saved
			}
		} });
	},
	toggleSaved: (key) => {
		const prev = get().records[key] ?? emptyRec();
		set({ records: {
			...get().records,
			[key]: {
				...prev,
				saved: !prev.saved
			}
		} });
	},
	addTest: (row) => set({ tests: [...get().tests, row].slice(-12) }),
	setTheme: (theme) => set({ theme })
}), {
	name: "loksewa-progress-v1",
	skipHydration: true
}));
//#endregion
//#region node_modules/.nitro/vite/services/ssr/assets/quiz-search-BHTI1vVz.js
function quizSearch(over = {}) {
	return {
		bank: "geo",
		mode: "practice",
		n: 20,
		topic: "",
		batch: "",
		only: "",
		chs: "",
		timed: 0,
		...over
	};
}
function asString(value) {
	if (typeof value === "string") return value;
	if (typeof value === "number" && Number.isFinite(value)) return String(value);
	return "";
}
function parseQuizSearch(raw) {
	const mode = raw.mode === "exam" ? "exam" : "practice";
	const only = raw.only === "wrong" || raw.only === "saved" ? raw.only : "";
	const n = Number(raw.n);
	const timed = Number(raw.timed) === 1 ? 1 : 0;
	return quizSearch({
		bank: asString(raw.bank) || "geo",
		mode,
		n: Number.isFinite(n) ? Math.max(0, Math.round(n)) : 20,
		topic: asString(raw.topic),
		batch: asString(raw.batch),
		only,
		chs: asString(raw.chs),
		timed
	});
}
//#endregion
export { quizSearch as n, useProgress as r, parseQuizSearch as t };
