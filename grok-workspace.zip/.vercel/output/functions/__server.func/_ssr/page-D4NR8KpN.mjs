import { S as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { r as useProgress } from "./quiz-search-BHTI1vVz.mjs";
import { n as Sun, r as Moon } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/page-D4NR8KpN.js
var import_jsx_runtime = require_jsx_runtime();
function Page({ title, back, children }) {
	const theme = useProgress((s) => s.theme);
	const setTheme = useProgress((s) => s.setTheme);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen bg-bg text-fg",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
			className: "topbar sticky top-0 z-20 flex items-center gap-2 border-b border-line bg-bg/95 px-3 pb-3 backdrop-blur-sm",
			children: [
				back ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
					href: back,
					"aria-label": "Back",
					className: "grid size-11 place-items-center rounded-full text-fg",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chevron, {})
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "w-2" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "min-w-0 flex-1 truncate font-display text-lg leading-tight",
					children: title
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					"aria-label": theme === "dark" ? "Switch to light" : "Switch to dark",
					className: "grid size-11 place-items-center rounded-full text-gold",
					onClick: () => setTheme(theme === "dark" ? "light" : "dark"),
					children: theme === "dark" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sun, { className: "size-5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Moon, { className: "size-5" })
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
			className: "mx-auto w-full max-w-3xl px-4 pt-4 pb-16",
			children
		})]
	});
}
function Chevron() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
		viewBox: "0 0 24 24",
		className: "size-6",
		"aria-hidden": "true",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			d: "M15 5l-7 7 7 7",
			fill: "none",
			stroke: "currentColor",
			strokeWidth: "2.2",
			strokeLinecap: "round",
			strokeLinejoin: "round"
		})
	});
}
//#endregion
export { Page as t };
