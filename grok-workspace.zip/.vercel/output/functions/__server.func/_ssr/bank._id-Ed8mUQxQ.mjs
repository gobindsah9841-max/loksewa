import { S as require_jsx_runtime, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as quizSearch, r as useProgress } from "./quiz-search-BHTI1vVz.mjs";
import { a as useHydrated, r as Route$1 } from "./router-B5IjRnlh.mjs";
import { c as geographyQuestions, i as chapterByNum, s as geoBatchCounts } from "./catalog-BzfA9AI0.mjs";
import { t as Page } from "./page-D4NR8KpN.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/bank._id-Ed8mUQxQ.js
var import_jsx_runtime = require_jsx_runtime();
function BankPage() {
	const { id } = Route$1.useParams();
	if (id === "geo") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GeoBank, {});
	const chapter = chapterByNum(Number(id));
	if (!chapter) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Page, {
		title: "Not found",
		back: "/",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "That chapter is not in this book." })
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChapterBank, { num: chapter.num });
}
function GeoBank() {
	const batches = geoBatchCounts();
	const hydrated = useHydrated();
	const records = useProgress((s) => s.records);
	const missed = geographyQuestions.filter((q) => records[q.key]?.tries && !records[q.key]?.lastCorrect).length;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Page, {
		title: "Geography Master",
		back: "/",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm leading-relaxed text-muted",
				children: [
					geographyQuestions.length,
					" questions in English, in ",
					batches.length,
					" batches of about 50. This bank is still a draft. If a number disagrees with the geography chapter, learn the chapter."
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 grid gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/quiz",
						search: quizSearch({
							bank: "geo",
							mode: "practice",
							n: 20
						}),
						className: "flex min-h-12 items-center justify-center rounded-xl bg-crimson font-semibold text-on-crimson",
						children: "Practice 20, mixed"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/quiz",
						search: quizSearch({
							bank: "geo",
							mode: "exam",
							n: 50,
							timed: 1
						}),
						className: "flex min-h-12 items-center justify-center rounded-xl border border-line bg-card font-semibold",
						children: "Exam of 50, timed"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/quiz",
						search: quizSearch({
							bank: "geo",
							mode: "practice",
							n: 0
						}),
						className: "flex min-h-12 items-center justify-center rounded-xl border border-line bg-card font-semibold",
						children: ["All ", geographyQuestions.length]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/quiz",
						search: quizSearch({
							bank: "geo",
							mode: "practice",
							n: 0,
							only: "wrong"
						}),
						className: "flex min-h-12 items-center justify-center rounded-xl border border-line bg-card font-semibold",
						children: ["Questions I missed", hydrated ? ` (${missed})` : ""]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mt-6 mb-2 font-display text-xl",
				children: "By batch"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "grid gap-2",
				children: batches.map((batch) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/quiz",
					search: quizSearch({
						bank: "geo",
						mode: "practice",
						n: 0,
						batch: String(batch.batch)
					}),
					className: "flex min-h-14 items-center justify-between rounded-xl border border-line bg-card px-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "font-semibold",
						children: ["Batch ", batch.batch]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "text-sm text-muted",
						children: [batch.count, " questions"]
					})]
				}) }, batch.batch))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/read/$slug",
				params: { slug: "part-05-chapter-01-geography-of-nepal" },
				className: "mt-4 flex min-h-12 items-center justify-center rounded-xl border border-gold text-gold",
				children: "Read the geography chapter"
			})
		]
	});
}
function ChapterBank({ num }) {
	const chapter = chapterByNum(num);
	const hydrated = useHydrated();
	const records = useProgress((s) => s.records);
	const missed = chapter.questions.filter((q) => records[q.key]?.tries && !records[q.key]?.lastCorrect).length;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Page, {
		title: `Chapter ${chapter.num}`,
		back: "/",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-display text-2xl leading-tight",
				children: chapter.title
			}),
			chapter.nep ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-muted",
				children: chapter.nep
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-2 text-sm text-muted",
				children: [chapter.questions.length, " practice questions"]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 grid gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/quiz",
						search: quizSearch({
							bank: String(chapter.num),
							mode: "practice",
							n: 0
						}),
						className: "flex min-h-12 items-center justify-center rounded-xl bg-crimson font-semibold text-on-crimson",
						children: "All questions, mixed"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/quiz",
						search: quizSearch({
							bank: String(chapter.num),
							mode: "practice",
							n: 0,
							only: "wrong"
						}),
						className: "flex min-h-12 items-center justify-center rounded-xl border border-line bg-card font-semibold",
						children: ["Questions I missed", hydrated ? ` (${missed})` : ""]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/read/$slug",
						params: { slug: chapter.slug },
						className: "flex min-h-12 items-center justify-center rounded-xl border border-line bg-card font-semibold",
						children: "Read this chapter"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mt-6 mb-2 font-display text-xl",
				children: "By topic"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "grid gap-2",
				children: chapter.topics.map((topic) => {
					const tried = hydrated ? topic.questions.filter((q) => (records[q.key]?.tries ?? 0) > 0).length : 0;
					const right = hydrated ? topic.questions.filter((q) => records[q.key]?.tries && records[q.key]?.lastCorrect).length : 0;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/quiz",
						search: quizSearch({
							bank: String(chapter.num),
							mode: "practice",
							n: 0,
							topic: topic.id
						}),
						className: "block rounded-xl border border-line bg-card px-4 py-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block font-semibold leading-snug",
							children: topic.title
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "mt-1 block text-sm text-muted",
							children: [
								topic.questions.length,
								" questions",
								tried ? ` · last time ${right} of ${tried} right` : ""
							]
						})]
					}) }, topic.id);
				})
			})
		]
	});
}
//#endregion
export { BankPage as component };
