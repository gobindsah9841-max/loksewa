import { i as __toESM } from "../_runtime.mjs";
import { J as require_react, S as require_jsx_runtime, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as quizSearch, r as useProgress } from "./quiz-search-BHTI1vVz.mjs";
import { n as Sun, r as Moon } from "../_libs/lucide-react.mjs";
import { a as useHydrated } from "./router-B5IjRnlh.mjs";
import { a as chapters, c as geographyQuestions, d as reads, f as searchQuestions, l as plain, m as totalQuestionCount, n as bookQuestionCount, r as bookVersion, t as bookBuilt } from "./catalog-BzfA9AI0.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-obH-3DYK.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var LETTERS = [
	"A",
	"B",
	"C",
	"D"
];
function Home() {
	const hydrated = useHydrated();
	const records = useProgress((s) => s.records);
	const theme = useProgress((s) => s.theme);
	const setTheme = useProgress((s) => s.setTheme);
	const [query, setQuery] = (0, import_react.useState)("");
	const [openKey, setOpenKey] = (0, import_react.useState)(null);
	const tried = (0, import_react.useMemo)(() => {
		if (!hydrated) return [];
		return Object.values(records).filter((r) => r.tries > 0);
	}, [hydrated, records]);
	const accuracy = tried.length ? Math.round(100 * tried.filter((r) => r.lastCorrect).length / tried.length) : 0;
	const hits = (0, import_react.useMemo)(() => searchQuestions(query), [query]);
	const guides = reads.filter((r) => r.kind !== "chapter");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen bg-bg text-fg",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
			className: "topbar mx-auto flex w-full max-w-3xl items-start justify-between gap-4 px-4 pb-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "flag",
					"aria-hidden": "true",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", {})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-semibold tracking-wide text-gold uppercase",
					children: "Paper I · General knowledge"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display text-3xl leading-none",
					children: "Loksewa"
				})] })]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				"aria-label": theme === "dark" ? "Switch to light" : "Switch to dark",
				className: "grid size-11 place-items-center rounded-full border border-line text-gold",
				onClick: () => setTheme(theme === "dark" ? "light" : "dark"),
				children: theme === "dark" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sun, { className: "size-5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Moon, { className: "size-5" })
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
			className: "mx-auto flex w-full max-w-3xl flex-col gap-5 px-4 pt-2 pb-16",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "max-w-xl text-base leading-relaxed text-muted",
					children: [
						"Provincial Public Service Commission, 5th level, non-technical. ",
						chapters.length,
						" study chapters and",
						" ",
						bookQuestionCount.toLocaleString(),
						" book questions, plus ",
						geographyQuestions.length,
						" new geography questions."
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "grid grid-cols-3 gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
							label: "Questions",
							value: totalQuestionCount.toLocaleString()
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
							label: "Tried",
							value: hydrated ? String(tried.length) : "–"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
							label: "Last try",
							value: hydrated && tried.length ? `${accuracy}%` : "–"
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "rounded-2xl border border-line bg-card p-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-semibold tracking-wide text-gold uppercase",
							children: "New bank"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mt-1 font-display text-2xl",
							children: "Geography Master"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-1 text-sm leading-relaxed text-muted",
							children: [
								geographyQuestions.length,
								" English MCQs on Nepal and the world. Draft set — where a figure disagrees with a chapter, trust the chapter. The book was checked on ",
								bookBuilt,
								"."
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-4 grid gap-2 sm:grid-cols-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/quiz",
								search: quizSearch({
									bank: "geo",
									mode: "practice",
									n: 20
								}),
								className: "flex min-h-12 items-center justify-center rounded-xl bg-crimson font-semibold text-on-crimson",
								children: "Practice 20"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/bank/$id",
								params: { id: "geo" },
								className: "flex min-h-12 items-center justify-center rounded-xl border border-line font-semibold",
								children: "Open the bank"
							})]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/mock",
					className: "flex min-h-16 items-center justify-between rounded-2xl border border-line bg-surface px-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "block font-semibold",
						children: "Timed mock test"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-sm text-muted",
						children: "Exam marking: +2 / −0.4"
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-gold",
						children: "Start"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mb-2 font-display text-xl",
					children: "Chapters"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "grid gap-2 sm:grid-cols-2",
					children: chapters.map((chapter) => {
						const triedHere = hydrated ? chapter.questions.filter((q) => (records[q.key]?.tries ?? 0) > 0).length : 0;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/bank/$id",
							params: { id: String(chapter.num) },
							className: "flex h-full flex-col rounded-2xl border border-line bg-card px-4 py-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-xs font-semibold text-gold",
									children: ["Chapter ", chapter.num]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "mt-1 font-semibold leading-snug",
									children: chapter.title
								}),
								chapter.nep ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-sm text-muted",
									children: chapter.nep
								}) : null,
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "mt-2 text-sm text-muted",
									children: [
										chapter.questions.length,
										" questions",
										hydrated && triedHere ? ` · ${triedHere} tried` : ""
									]
								})
							]
						}) }, chapter.num);
					})
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mb-2 font-display text-xl",
					children: "How to use the book"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "grid gap-2",
					children: guides.map((guide) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/read/$slug",
						params: { slug: guide.slug },
						className: "flex min-h-12 items-center rounded-xl border border-line bg-card px-4",
						children: guide.title
					}) }, guide.slug))
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mb-2 font-display text-xl",
						children: "Search"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						value: query,
						onChange: (e) => {
							setQuery(e.target.value);
							setOpenKey(null);
						},
						placeholder: "Search a place, a river, a fact",
						className: "w-full rounded-xl border border-line bg-card px-4 py-3 outline-none",
						"aria-label": "Search questions"
					}),
					query.trim().length >= 2 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
						className: "mt-2 flex flex-col gap-2",
						children: [hits.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
							className: "text-sm text-muted",
							children: "Nothing matches."
						}) : null, hits.map((q) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "rounded-xl border border-line bg-card px-3 py-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs text-gold",
									children: q.source
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 text-sm leading-snug",
									children: plain(q.stem)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "mt-2 text-sm font-semibold text-gold",
									onClick: () => setOpenKey(openKey === q.key ? null : q.key),
									children: openKey === q.key ? "Hide answer" : "Show answer"
								}),
								openKey === q.key ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mt-2 text-sm leading-relaxed text-muted",
									children: [
										LETTERS[q.answer],
										". ",
										q.options[q.answer],
										" — ",
										q.explanation
									]
								}) : null
							]
						}, q.key))]
					}) : null
				] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-xs leading-relaxed text-muted",
					children: [
						"Study book v",
						bookVersion,
						", built ",
						bookBuilt,
						". No question here is a verified past question."
					]
				})
			]
		})]
	});
}
function Stat({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-xl border border-line bg-surface px-3 py-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-display text-2xl leading-none",
			children: value
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-1 text-xs text-muted",
			children: label
		})]
	});
}
//#endregion
export { Home as component };
