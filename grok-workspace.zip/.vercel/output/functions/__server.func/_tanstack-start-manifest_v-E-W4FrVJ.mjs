//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-E-W4FrVJ.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/mock",
			"/quiz",
			"/bank/$id",
			"/read/$slug"
		],
		preloads: [
			"/assets/index-8dfpQ-8n.js",
			"/assets/progress-BN7NQtw-.js",
			"/assets/preload-helper-4sE5kuUf.js",
			"/assets/link-BHqsV3o_.js",
			"/assets/quiz-search-Ix921quP.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-8dfpQ-8n.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-Bf4wo6Rr.js", "/assets/catalog-DqMJ7kQU.js"]
	},
	"/mock": {
		filePath: "/workspace/src/routes/mock.tsx",
		children: void 0,
		preloads: [
			"/assets/mock-D-AEEZ3M.js",
			"/assets/useNavigate-2Ppmzz2J.js",
			"/assets/catalog-DqMJ7kQU.js",
			"/assets/page-Cox5-2mV.js"
		]
	},
	"/quiz": {
		filePath: "/workspace/src/routes/quiz.tsx",
		children: void 0,
		preloads: [
			"/assets/quiz-CKOjRNLC.js",
			"/assets/catalog-DqMJ7kQU.js",
			"/assets/page-Cox5-2mV.js"
		]
	},
	"/bank/$id": {
		filePath: "/workspace/src/routes/bank.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/bank._id-C3dRzatQ.js",
			"/assets/catalog-DqMJ7kQU.js",
			"/assets/page-Cox5-2mV.js"
		]
	},
	"/read/$slug": {
		filePath: "/workspace/src/routes/read.$slug.tsx",
		children: void 0,
		preloads: [
			"/assets/read._slug-fY-kl7sA.js",
			"/assets/catalog-DqMJ7kQU.js",
			"/assets/page-Cox5-2mV.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
