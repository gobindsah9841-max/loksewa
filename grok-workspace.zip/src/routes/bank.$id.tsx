import { createFileRoute, Link } from "@tanstack/react-router";
import { chapterByNum, geoBatchCounts, geographyQuestions } from "@/lib/catalog";
import { useProgress } from "@/lib/progress";
import { quizSearch } from "@/lib/quiz-search";
import { useHydrated } from "@/lib/use-hydrated";
import { Page } from "@/components/page";

export const Route = createFileRoute("/bank/$id")({ component: BankPage });

function BankPage() {
  const { id } = Route.useParams();
  if (id === "geo") return <GeoBank />;
  const chapter = chapterByNum(Number(id));
  if (!chapter) {
    return (
      <Page title="Not found" back="/">
        <p>That chapter is not in this book.</p>
      </Page>
    );
  }
  return <ChapterBank num={chapter.num} />;
}

function GeoBank() {
  const batches = geoBatchCounts();
  const hydrated = useHydrated();
  const records = useProgress((s) => s.records);
  const missed = geographyQuestions.filter((q) => records[q.key]?.tries && !records[q.key]?.lastCorrect).length;

  return (
    <Page title="Geography Master" back="/">
      <p className="text-sm leading-relaxed text-muted">
        {geographyQuestions.length} questions in English, in {batches.length} batches of about 50. This bank is still a
        draft. If a number disagrees with the geography chapter, learn the chapter.
      </p>
      <div className="mt-4 grid gap-2">
        <Link
          to="/quiz"
          search={quizSearch({ bank: "geo", mode: "practice", n: 20 })}
          className="flex min-h-12 items-center justify-center rounded-xl bg-crimson font-semibold text-on-crimson"
        >
          Practice 20, mixed
        </Link>
        <Link
          to="/quiz"
          search={quizSearch({ bank: "geo", mode: "exam", n: 50, timed: 1 })}
          className="flex min-h-12 items-center justify-center rounded-xl border border-line bg-card font-semibold"
        >
          Exam of 50, timed
        </Link>
        <Link
          to="/quiz"
          search={quizSearch({ bank: "geo", mode: "practice", n: 0 })}
          className="flex min-h-12 items-center justify-center rounded-xl border border-line bg-card font-semibold"
        >
          All {geographyQuestions.length}
        </Link>
        <Link
          to="/quiz"
          search={quizSearch({ bank: "geo", mode: "practice", n: 0, only: "wrong" })}
          className="flex min-h-12 items-center justify-center rounded-xl border border-line bg-card font-semibold"
        >
          Questions I missed{hydrated ? ` (${missed})` : ""}
        </Link>
      </div>
      <h2 className="mt-6 mb-2 font-display text-xl">By batch</h2>
      <ul className="grid gap-2">
        {batches.map((batch) => (
          <li key={batch.batch}>
            <Link
              to="/quiz"
              search={quizSearch({ bank: "geo", mode: "practice", n: 0, batch: String(batch.batch) })}
              className="flex min-h-14 items-center justify-between rounded-xl border border-line bg-card px-4"
            >
              <span className="font-semibold">Batch {batch.batch}</span>
              <span className="text-sm text-muted">{batch.count} questions</span>
            </Link>
          </li>
        ))}
      </ul>
      <Link
        to="/read/$slug"
        params={{ slug: "part-05-chapter-01-geography-of-nepal" }}
        className="mt-4 flex min-h-12 items-center justify-center rounded-xl border border-gold text-gold"
      >
        Read the geography chapter
      </Link>
    </Page>
  );
}

function ChapterBank({ num }: { num: number }) {
  const chapter = chapterByNum(num)!;
  const hydrated = useHydrated();
  const records = useProgress((s) => s.records);
  const missed = chapter.questions.filter((q) => records[q.key]?.tries && !records[q.key]?.lastCorrect).length;

  return (
    <Page title={`Chapter ${chapter.num}`} back="/">
      <p className="font-display text-2xl leading-tight">{chapter.title}</p>
      {chapter.nep ? <p className="text-muted">{chapter.nep}</p> : null}
      <p className="mt-2 text-sm text-muted">{chapter.questions.length} practice questions</p>
      <div className="mt-4 grid gap-2">
        <Link
          to="/quiz"
          search={quizSearch({ bank: String(chapter.num), mode: "practice", n: 0 })}
          className="flex min-h-12 items-center justify-center rounded-xl bg-crimson font-semibold text-on-crimson"
        >
          All questions, mixed
        </Link>
        <Link
          to="/quiz"
          search={quizSearch({ bank: String(chapter.num), mode: "practice", n: 0, only: "wrong" })}
          className="flex min-h-12 items-center justify-center rounded-xl border border-line bg-card font-semibold"
        >
          Questions I missed{hydrated ? ` (${missed})` : ""}
        </Link>
        <Link
          to="/read/$slug"
          params={{ slug: chapter.slug }}
          className="flex min-h-12 items-center justify-center rounded-xl border border-line bg-card font-semibold"
        >
          Read this chapter
        </Link>
      </div>
      <h2 className="mt-6 mb-2 font-display text-xl">By topic</h2>
      <ul className="grid gap-2">
        {chapter.topics.map((topic) => {
          const tried = hydrated ? topic.questions.filter((q) => (records[q.key]?.tries ?? 0) > 0).length : 0;
          const right = hydrated
            ? topic.questions.filter((q) => records[q.key]?.tries && records[q.key]?.lastCorrect).length
            : 0;
          return (
            <li key={topic.id}>
              <Link
                to="/quiz"
                search={quizSearch({ bank: String(chapter.num), mode: "practice", n: 0, topic: topic.id })}
                className="block rounded-xl border border-line bg-card px-4 py-3"
              >
                <span className="block font-semibold leading-snug">{topic.title}</span>
                <span className="mt-1 block text-sm text-muted">
                  {topic.questions.length} questions
                  {tried ? ` · last time ${right} of ${tried} right` : ""}
                </span>
              </Link>
            </li>
          );
        })}
      </ul>
    </Page>
  );
}
