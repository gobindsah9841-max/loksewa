import { createFileRoute, Link } from "@tanstack/react-router";
import { marked } from "marked";
import { useEffect, useState } from "react";
import { Page } from "@/components/page";
import { readBySlug } from "@/lib/catalog";

export const Route = createFileRoute("/read/$slug")({ component: ReadPage });

function ReadPage() {
  const { slug } = Route.useParams();
  const meta = readBySlug(slug);
  const [html, setHtml] = useState("");
  const [failed, setFailed] = useState(false);

  useEffect(() => {
    if (!meta) return;
    let live = true;
    setHtml("");
    setFailed(false);
    void (async () => {
      try {
        const res = await fetch(`/book/${meta.file}`);
        if (!res.ok) throw new Error("missing");
        const text = await res.text();
        const parsed = await marked.parse(text);
        if (live) setHtml(parsed);
      } catch {
        if (live) setFailed(true);
      }
    })();
    return () => {
      live = false;
    };
  }, [meta]);

  if (!meta) {
    return (
      <Page title="Not found" back="/">
        <p>That part of the book is missing.</p>
      </Page>
    );
  }

  return (
    <Page title={meta.title} back="/">
      {meta.kind === "chapter" ? (
        <Link
          to="/bank/$id"
          params={{ id: String(meta.ch) }}
          className="mb-4 flex min-h-12 items-center justify-center rounded-xl bg-crimson font-semibold text-on-crimson"
        >
          Practice this chapter
        </Link>
      ) : null}
      {!html && !failed ? <p className="text-muted">Opening the chapter…</p> : null}
      {failed ? <p>This chapter could not be opened.</p> : null}
      {html ? <article className="reading" dangerouslySetInnerHTML={{ __html: html }} /> : null}
    </Page>
  );
}
