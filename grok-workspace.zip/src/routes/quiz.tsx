import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { QuizRunner } from "@/components/quiz-runner";
import { Page } from "@/components/page";
import { collectQuestions, shuffle, type Question } from "@/lib/catalog";
import { useProgress } from "@/lib/progress";
import { parseQuizSearch, type QuizSearch } from "@/lib/quiz-search";
import { useHydrated } from "@/lib/use-hydrated";

export const Route = createFileRoute("/quiz")({
  validateSearch: (raw): QuizSearch => parseQuizSearch(raw as Record<string, unknown>),
  component: QuizPage,
});

function QuizPage() {
  const search = Route.useSearch();
  const hydrated = useHydrated();
  const [pack, setPack] = useState<{ title: string; questions: Question[]; error: string } | null>(null);

  const sig = [
    search.bank,
    search.mode,
    search.n,
    search.topic,
    search.batch,
    search.only,
    search.chs,
    search.timed,
  ].join("|");

  useEffect(() => {
    if (search.only && !hydrated) return;
    const collected = collectQuestions(search, useProgress.getState().records);
    if ("error" in collected) {
      setPack({ title: "Practice", questions: [], error: collected.error });
      return;
    }
    const mixed = shuffle(collected.questions);
    const limit = search.n > 0 ? Math.min(search.n, mixed.length) : mixed.length;
    setPack({ title: collected.title, questions: mixed.slice(0, limit), error: "" });
    // Reshuffle only when the requested set changes, not when progress hydrates for a normal set.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [sig, search.only ? hydrated : false]);

  return (
    <Page title={pack?.title || "Practice"} back={search.bank === "mix" ? "/mock" : search.bank === "geo" ? "/bank/geo" : `/bank/${search.bank}`}>
      {!pack ? <p className="text-muted">Preparing questions…</p> : null}
      {pack && pack.error ? <p className="text-base leading-relaxed">{pack.error}</p> : null}
      {pack && !pack.error && pack.questions.length ? (
        <QuizRunner
          key={pack.questions.map((q) => q.key).join("|") + search.mode + String(search.timed)}
          title={pack.title}
          mode={search.mode}
          timed={search.mode === "exam" && search.timed === 1}
          questions={pack.questions}
        />
      ) : null}
    </Page>
  );
}
