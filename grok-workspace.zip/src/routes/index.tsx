import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { Moon, Sun } from "lucide-react";
import {
  bookBuilt,
  bookQuestionCount,
  bookVersion,
  chapters,
  geographyQuestions,
  reads,
  searchQuestions,
  totalQuestionCount,
  plain,
} from "@/lib/catalog";
import { useProgress } from "@/lib/progress";
import { quizSearch } from "@/lib/quiz-search";
import { useHydrated } from "@/lib/use-hydrated";

export const Route = createFileRoute("/")({ component: Home });

const LETTERS = ["A", "B", "C", "D"];

function Home() {
  const hydrated = useHydrated();
  const records = useProgress((s) => s.records);
  const theme = useProgress((s) => s.theme);
  const setTheme = useProgress((s) => s.setTheme);
  const [query, setQuery] = useState("");
  const [openKey, setOpenKey] = useState<string | null>(null);

  const tried = useMemo(() => {
    if (!hydrated) return [];
    return Object.values(records).filter((r) => r.tries > 0);
  }, [hydrated, records]);
  const accuracy = tried.length
    ? Math.round((100 * tried.filter((r) => r.lastCorrect).length) / tried.length)
    : 0;
  const hits = useMemo(() => searchQuestions(query), [query]);
  const guides = reads.filter((r) => r.kind !== "chapter");

  return (
    <div className="min-h-screen bg-bg text-fg">
      <header className="topbar mx-auto flex w-full max-w-3xl items-start justify-between gap-4 px-4 pb-2">
        <div className="flex items-center gap-3">
          <span className="flag" aria-hidden="true">
            <i />
            <i />
          </span>
          <div>
            <p className="text-xs font-semibold tracking-wide text-gold uppercase">Paper I · General knowledge</p>
            <h1 className="font-display text-3xl leading-none">Loksewa</h1>
          </div>
        </div>
        <button
          type="button"
          aria-label={theme === "dark" ? "Switch to light" : "Switch to dark"}
          className="grid size-11 place-items-center rounded-full border border-line text-gold"
          onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
        >
          {theme === "dark" ? <Sun className="size-5" /> : <Moon className="size-5" />}
        </button>
      </header>

      <main className="mx-auto flex w-full max-w-3xl flex-col gap-5 px-4 pt-2 pb-16">
        <p className="max-w-xl text-base leading-relaxed text-muted">
          Provincial Public Service Commission, 5th level, non-technical. {chapters.length} study chapters and{" "}
          {bookQuestionCount.toLocaleString()} book questions, plus {geographyQuestions.length} new geography questions.
        </p>

        <section className="grid grid-cols-3 gap-2">
          <Stat label="Questions" value={totalQuestionCount.toLocaleString()} />
          <Stat label="Tried" value={hydrated ? String(tried.length) : "–"} />
          <Stat label="Last try" value={hydrated && tried.length ? `${accuracy}%` : "–"} />
        </section>

        <section className="rounded-2xl border border-line bg-card p-4">
          <p className="text-xs font-semibold tracking-wide text-gold uppercase">New bank</p>
          <h2 className="mt-1 font-display text-2xl">Geography Master</h2>
          <p className="mt-1 text-sm leading-relaxed text-muted">
            {geographyQuestions.length} English MCQs on Nepal and the world. Draft set — where a figure disagrees with a
            chapter, trust the chapter. The book was checked on {bookBuilt}.
          </p>
          <div className="mt-4 grid gap-2 sm:grid-cols-2">
            <Link
              to="/quiz"
              search={quizSearch({ bank: "geo", mode: "practice", n: 20 })}
              className="flex min-h-12 items-center justify-center rounded-xl bg-crimson font-semibold text-on-crimson"
            >
              Practice 20
            </Link>
            <Link
              to="/bank/$id"
              params={{ id: "geo" }}
              className="flex min-h-12 items-center justify-center rounded-xl border border-line font-semibold"
            >
              Open the bank
            </Link>
          </div>
        </section>

        <Link
          to="/mock"
          className="flex min-h-16 items-center justify-between rounded-2xl border border-line bg-surface px-4"
        >
          <span>
            <span className="block font-semibold">Timed mock test</span>
            <span className="text-sm text-muted">Exam marking: +2 / −0.4</span>
          </span>
          <span className="text-gold">Start</span>
        </Link>

        <section>
          <h2 className="mb-2 font-display text-xl">Chapters</h2>
          <ul className="grid gap-2 sm:grid-cols-2">
            {chapters.map((chapter) => {
              const triedHere = hydrated
                ? chapter.questions.filter((q) => (records[q.key]?.tries ?? 0) > 0).length
                : 0;
              return (
                <li key={chapter.num}>
                  <Link
                    to="/bank/$id"
                    params={{ id: String(chapter.num) }}
                    className="flex h-full flex-col rounded-2xl border border-line bg-card px-4 py-3"
                  >
                    <span className="text-xs font-semibold text-gold">Chapter {chapter.num}</span>
                    <span className="mt-1 font-semibold leading-snug">{chapter.title}</span>
                    {chapter.nep ? <span className="text-sm text-muted">{chapter.nep}</span> : null}
                    <span className="mt-2 text-sm text-muted">
                      {chapter.questions.length} questions
                      {hydrated && triedHere ? ` · ${triedHere} tried` : ""}
                    </span>
                  </Link>
                </li>
              );
            })}
          </ul>
        </section>

        <section>
          <h2 className="mb-2 font-display text-xl">How to use the book</h2>
          <ul className="grid gap-2">
            {guides.map((guide) => (
              <li key={guide.slug}>
                <Link
                  to="/read/$slug"
                  params={{ slug: guide.slug }}
                  className="flex min-h-12 items-center rounded-xl border border-line bg-card px-4"
                >
                  {guide.title}
                </Link>
              </li>
            ))}
          </ul>
        </section>

        <section>
          <h2 className="mb-2 font-display text-xl">Search</h2>
          <input
            value={query}
            onChange={(e) => {
              setQuery(e.target.value);
              setOpenKey(null);
            }}
            placeholder="Search a place, a river, a fact"
            className="w-full rounded-xl border border-line bg-card px-4 py-3 outline-none"
            aria-label="Search questions"
          />
          {query.trim().length >= 2 ? (
            <ul className="mt-2 flex flex-col gap-2">
              {hits.length === 0 ? <li className="text-sm text-muted">Nothing matches.</li> : null}
              {hits.map((q) => (
                <li key={q.key} className="rounded-xl border border-line bg-card px-3 py-3">
                  <p className="text-xs text-gold">{q.source}</p>
                  <p className="mt-1 text-sm leading-snug">{plain(q.stem)}</p>
                  <button
                    type="button"
                    className="mt-2 text-sm font-semibold text-gold"
                    onClick={() => setOpenKey(openKey === q.key ? null : q.key)}
                  >
                    {openKey === q.key ? "Hide answer" : "Show answer"}
                  </button>
                  {openKey === q.key ? (
                    <p className="mt-2 text-sm leading-relaxed text-muted">
                      {LETTERS[q.answer]}. {q.options[q.answer]} — {q.explanation}
                    </p>
                  ) : null}
                </li>
              ))}
            </ul>
          ) : null}
        </section>

        <p className="text-xs leading-relaxed text-muted">
          Study book v{bookVersion}, built {bookBuilt}. No question here is a verified past question.
        </p>
      </main>
    </div>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-xl border border-line bg-surface px-3 py-3">
      <p className="font-display text-2xl leading-none">{value}</p>
      <p className="mt-1 text-xs text-muted">{label}</p>
    </div>
  );
}
