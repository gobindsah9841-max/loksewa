import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { Page } from "@/components/page";
import { chapters } from "@/lib/catalog";
import { useProgress } from "@/lib/progress";
import { quizSearch } from "@/lib/quiz-search";

export const Route = createFileRoute("/mock")({ component: MockPage });

const SIZES = [10, 25, 50];

function MockPage() {
  const navigate = useNavigate();
  const tests = useProgress((s) => s.tests);
  const [n, setN] = useState(25);
  const [timed, setTimed] = useState(true);
  const [picked, setPicked] = useState<string[]>(() => ["geo", ...chapters.map((c) => String(c.num))]);
  const [message, setMessage] = useState("");

  function toggle(id: string) {
    setPicked((prev) => (prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]));
  }

  return (
    <Page title="Timed test" back="/">
      <p className="text-sm leading-relaxed text-muted">
        A mixed paper from the sets you tick. Marking follows the examination: 2 for a right answer, 0.4 off for a wrong
        one, nothing for a blank. The real paper is 50 questions in 45 minutes.
      </p>

      <h2 className="mt-5 mb-2 text-sm font-semibold text-gold">Number of questions</h2>
      <div className="grid grid-cols-3 gap-2">
        {SIZES.map((size) => (
          <button
            key={size}
            type="button"
            onClick={() => setN(size)}
            className={
              "min-h-12 rounded-xl border font-semibold " +
              (n === size ? "border-gold bg-gold text-on-gold" : "border-line bg-card")
            }
          >
            {size}
          </button>
        ))}
      </div>

      <h2 className="mt-5 mb-2 text-sm font-semibold text-gold">Time limit</h2>
      <div className="grid grid-cols-2 gap-2">
        <button
          type="button"
          onClick={() => setTimed(true)}
          className={
            "min-h-12 rounded-xl border px-2 text-sm font-semibold " +
            (timed ? "border-gold bg-gold text-on-gold" : "border-line bg-card")
          }
        >
          54 seconds each
        </button>
        <button
          type="button"
          onClick={() => setTimed(false)}
          className={
            "min-h-12 rounded-xl border font-semibold " +
            (!timed ? "border-gold bg-gold text-on-gold" : "border-line bg-card")
          }
        >
          No limit
        </button>
      </div>

      <h2 className="mt-5 mb-2 text-sm font-semibold text-gold">Sets</h2>
      <ul className="flex flex-col gap-2">
        <li>
          <label className="flex min-h-12 items-center gap-3 rounded-xl border border-line bg-card px-3">
            <input
              type="checkbox"
              checked={picked.includes("geo")}
              onChange={() => toggle("geo")}
              className="size-5 accent-crimson"
            />
            Geography Master · 400 new
          </label>
        </li>
        {chapters.map((chapter) => (
          <li key={chapter.num}>
            <label className="flex min-h-12 items-center gap-3 rounded-xl border border-line bg-card px-3">
              <input
                type="checkbox"
                checked={picked.includes(String(chapter.num))}
                onChange={() => toggle(String(chapter.num))}
                className="size-5"
              />
              <span>
                Chapter {chapter.num} — {chapter.title}
              </span>
            </label>
          </li>
        ))}
      </ul>

      <button
        type="button"
        className="mt-4 min-h-12 w-full rounded-xl bg-crimson font-semibold text-on-crimson"
        onClick={() => {
          if (!picked.length) {
            setMessage("Tick at least one set.");
            return;
          }
          void navigate({
            to: "/quiz",
            search: quizSearch({
              bank: "mix",
              mode: "exam",
              n,
              timed: timed ? 1 : 0,
              chs: picked.join(","),
            }),
          });
        }}
      >
        Start the test
      </button>
      {message ? <p className="mt-2 text-sm text-bad">{message}</p> : null}

      {tests.length ? (
        <>
          <h2 className="mt-6 mb-2 font-display text-xl">Your last tests</h2>
          <div className="overflow-x-auto rounded-xl border border-line">
            <table className="w-full border-collapse text-sm">
              <thead>
                <tr className="text-left text-muted">
                  <th className="px-3 py-2 font-medium">When</th>
                  <th className="px-3 py-2 font-medium">Set</th>
                  <th className="px-3 py-2 font-medium">Right</th>
                  <th className="px-3 py-2 font-medium">Marks</th>
                </tr>
              </thead>
              <tbody>
                {[...tests].reverse().map((test, i) => (
                  <tr key={i} className="border-t border-line">
                    <td className="px-3 py-2">{test.at}</td>
                    <td className="px-3 py-2">{test.title}</td>
                    <td className="px-3 py-2">
                      {test.c}/{test.n}
                    </td>
                    <td className="px-3 py-2">
                      {Math.round((2 * test.c - 0.4 * test.w) * 10) / 10}/{test.n * 2}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </>
      ) : null}
    </Page>
  );
}
