import { create } from "zustand";
import { persist } from "zustand/middleware";

export type Rec = {
  tries: number;
  correct: number;
  lastCorrect: boolean;
  saved: boolean;
};

export type TestRow = {
  at: string;
  title: string;
  n: number;
  c: number;
  w: number;
  b: number;
};

type ProgressState = {
  records: Record<string, Rec>;
  tests: TestRow[];
  theme: "dark" | "light";
  record: (key: string, correct: boolean) => void;
  toggleSaved: (key: string) => void;
  addTest: (row: TestRow) => void;
  setTheme: (theme: "dark" | "light") => void;
};

const emptyRec = (): Rec => ({ tries: 0, correct: 0, lastCorrect: false, saved: false });

export const useProgress = create<ProgressState>()(
  persist(
    (set, get) => ({
      records: {},
      tests: [],
      theme: "dark",
      record: (key, correct) => {
        const prev = get().records[key] ?? emptyRec();
        set({
          records: {
            ...get().records,
            [key]: {
              tries: prev.tries + 1,
              correct: prev.correct + (correct ? 1 : 0),
              lastCorrect: correct,
              saved: prev.saved,
            },
          },
        });
      },
      toggleSaved: (key) => {
        const prev = get().records[key] ?? emptyRec();
        set({
          records: {
            ...get().records,
            [key]: { ...prev, saved: !prev.saved },
          },
        });
      },
      addTest: (row) => set({ tests: [...get().tests, row].slice(-12) }),
      setTheme: (theme) => set({ theme }),
    }),
    { name: "loksewa-progress-v1", skipHydration: true },
  ),
);
