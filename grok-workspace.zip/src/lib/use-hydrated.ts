import { useEffect, useState } from "react";
import { useProgress } from "@/lib/progress";

export function useHydrated(): boolean {
  const [ok, setOk] = useState(false);
  const theme = useProgress((s) => s.theme);

  useEffect(() => {
    let live = true;
    void Promise.resolve(useProgress.persist.rehydrate()).then(() => {
      if (live) setOk(true);
    });
    return () => {
      live = false;
    };
  }, []);

  useEffect(() => {
    if (!ok) return;
    document.documentElement.classList.toggle("light", theme === "light");
  }, [ok, theme]);

  return ok;
}
