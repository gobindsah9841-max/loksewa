export type QuizSearch = {
  bank: string;
  mode: "practice" | "exam";
  n: number;
  topic: string;
  batch: string;
  only: "" | "wrong" | "saved";
  chs: string;
  timed: number;
};

export function quizSearch(over: Partial<QuizSearch> = {}): QuizSearch {
  return {
    bank: "geo",
    mode: "practice",
    n: 20,
    topic: "",
    batch: "",
    only: "",
    chs: "",
    timed: 0,
    ...over,
  };
}

function asString(value: unknown): string {
  if (typeof value === "string") return value;
  if (typeof value === "number" && Number.isFinite(value)) return String(value);
  return "";
}

export function parseQuizSearch(raw: Record<string, unknown>): QuizSearch {
  const mode = raw.mode === "exam" ? "exam" : "practice";
  const only = raw.only === "wrong" || raw.only === "saved" ? raw.only : "";
  const n = Number(raw.n);
  const timed = Number(raw.timed) === 1 ? 1 : 0;
  return quizSearch({
    bank: asString(raw.bank) || "geo",
    mode,
    n: Number.isFinite(n) ? Math.max(0, Math.round(n)) : 20,
    topic: asString(raw.topic),
    batch: asString(raw.batch),
    only,
    chs: asString(raw.chs),
    timed,
  });
}
